#!/usr/bin/env node

/**
 * Script de test d'intégration pour machines de scan TechnoCorner
 * 
 * Usage: node test-integration-scanner.js
 * 
 * Ce script teste la connexion avec l'API TechnoCorner et valide
 * le système anti-fraude avec des billets de test.
 */

import https from 'https';
import http from 'http';
import { URL } from 'url';

// Configuration
const CONFIG = {
  baseUrl: process.env.TECHNOCORNER_API_URL || 'http://localhost:5000',
  scannerId: process.env.SCANNER_ID || 'test-scanner-001',
  location: process.env.LOCATION || 'Test Terminal',
  timeout: parseInt(process.env.TIMEOUT_SECONDS || '5') * 1000
};

// Codes de test fournis par TechnoCorner
const TICKETS_TEST = {
  valide: '{"ticketCode":"TECHNO-1749365479238-YQ9G5R04D","eventId":90,"buyerName":"Test Valide"}',
  utilise: '{"ticketCode":"TECHNO-1749364928912-QQU3AH8LZ","eventId":26,"buyerName":"Test Utilisé"}',
  invalide: '{"ticketCode":"TECHNO-INVALID-TEST","eventId":999,"buyerName":"Test Invalide"}'
};

/**
 * Effectue une requête HTTP/HTTPS
 */
function makeRequest(url, options, data) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const isHttps = urlObj.protocol === 'https:';
    const client = isHttps ? https : http;
    
    const reqOptions = {
      hostname: urlObj.hostname,
      port: urlObj.port || (isHttps ? 443 : 80),
      path: urlObj.pathname,
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      timeout: CONFIG.timeout
    };

    const req = client.request(reqOptions, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const jsonBody = JSON.parse(body);
          resolve({ status: res.statusCode, data: jsonBody });
        } catch (e) {
          resolve({ status: res.statusCode, data: body });
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Timeout'));
    });

    if (data) {
      req.write(JSON.stringify(data));
    }
    req.end();
  });
}

/**
 * Teste la validation d'un billet
 */
async function testerValidationBillet(qrData, description) {
  console.log(`\n📋 Test: ${description}`);
  console.log(`   QR: ${qrData.substring(0, 50)}...`);
  
  try {
    const response = await makeRequest(`${CONFIG.baseUrl}/api/validate-ticket`, {
      method: 'POST'
    }, {
      qrData: qrData,
      validatorId: CONFIG.scannerId,
      location: CONFIG.location
    });

    console.log(`   Status: ${response.status}`);
    console.log(`   Réponse: ${response.data.message || 'Pas de message'}`);
    
    if (response.status === 200 && response.data.valid && response.data.validated) {
      console.log(`   ✅ SUCCÈS - Billet validé`);
      return true;
    } else if (response.status === 400 && response.data.alreadyUsed) {
      console.log(`   ⚠️  ANTI-FRAUDE - Billet déjà utilisé (${response.data.usedAt})`);
      return true; // Comportement attendu pour test anti-fraude
    } else if (response.status === 404) {
      console.log(`   ❌ ÉCHEC - Billet non trouvé`);
      return false;
    } else {
      console.log(`   ❌ ÉCHEC - ${response.data.message || 'Erreur inconnue'}`);
      return false;
    }
  } catch (error) {
    console.log(`   💥 ERREUR CONNEXION - ${error.message}`);
    return false;
  }
}

/**
 * Teste la vérification (lecture seule)
 */
async function testerVerificationBillet(qrData, description) {
  console.log(`\n🔍 Vérification: ${description}`);
  
  try {
    const response = await makeRequest(`${CONFIG.baseUrl}/api/verify-ticket`, {
      method: 'POST'
    }, {
      qrData: qrData
    });

    console.log(`   Status: ${response.status}`);
    console.log(`   Réponse: ${response.data.message || 'Pas de message'}`);
    
    if (response.status === 200 && response.data.valid) {
      console.log(`   ✅ VALIDE - Billet authentique`);
      return true;
    } else {
      console.log(`   ❌ INVALIDE - ${response.data.message || 'Billet non valide'}`);
      return false;
    }
  } catch (error) {
    console.log(`   💥 ERREUR - ${error.message}`);
    return false;
  }
}

/**
 * Teste la connectivité de base
 */
async function testerConnectivite() {
  console.log(`\n🌐 Test de connectivité vers ${CONFIG.baseUrl}`);
  
  try {
    const response = await makeRequest(`${CONFIG.baseUrl}/api/stats`, {
      method: 'GET'
    });
    
    if (response.status === 200) {
      console.log(`   ✅ CONNEXION OK - Serveur accessible`);
      console.log(`   📊 Stats: ${JSON.stringify(response.data)}`);
      return true;
    } else {
      console.log(`   ⚠️  CONNEXION PARTIELLE - Status ${response.status}`);
      return false;
    }
  } catch (error) {
    console.log(`   ❌ CONNEXION ÉCHOUÉE - ${error.message}`);
    console.log(`   💡 Vérifiez l'URL: ${CONFIG.baseUrl}`);
    return false;
  }
}

/**
 * Fonction principale de test
 */
async function executerTests() {
  console.log('🚀 TechnoCorner - Test d\'intégration scanner');
  console.log('=' .repeat(50));
  console.log(`Scanner ID: ${CONFIG.scannerId}`);
  console.log(`Location: ${CONFIG.location}`);
  console.log(`API URL: ${CONFIG.baseUrl}`);
  console.log(`Timeout: ${CONFIG.timeout}ms`);

  const resultats = [];

  // Test 1: Connectivité
  resultats.push(await testerConnectivite());

  // Test 2: Vérification d'un billet valide
  resultats.push(await testerVerificationBillet(
    TICKETS_TEST.valide, 
    "Billet valide (lecture seule)"
  ));

  // Test 3: Première validation (doit réussir)
  resultats.push(await testerValidationBillet(
    TICKETS_TEST.valide, 
    "Première validation d'un billet valide"
  ));

  // Test 4: Seconde validation du même billet (doit échouer - anti-fraude)
  resultats.push(await testerValidationBillet(
    TICKETS_TEST.valide, 
    "Seconde validation (test anti-fraude)"
  ));

  // Test 5: Billet déjà utilisé
  resultats.push(await testerValidationBillet(
    TICKETS_TEST.utilise, 
    "Billet déjà utilisé"
  ));

  // Test 6: Billet invalide
  resultats.push(await testerValidationBillet(
    TICKETS_TEST.invalide, 
    "Billet invalide"
  ));

  // Résultats finaux
  console.log('\n' + '=' .repeat(50));
  console.log('📊 RÉSULTATS DES TESTS');
  console.log('=' .repeat(50));
  
  const reussis = resultats.filter(r => r).length;
  const total = resultats.length;
  
  console.log(`Tests réussis: ${reussis}/${total}`);
  
  if (reussis === total) {
    console.log('✅ INTÉGRATION RÉUSSIE');
    console.log('Votre machine de scan est prête à utiliser l\'API TechnoCorner');
  } else if (reussis >= total - 1) {
    console.log('⚠️  INTÉGRATION PARTIELLE');
    console.log('La plupart des fonctionnalités marchent, vérifiez les erreurs ci-dessus');
  } else {
    console.log('❌ INTÉGRATION ÉCHOUÉE');
    console.log('Plusieurs problèmes détectés, contactez le support TechnoCorner');
  }

  console.log('\n💡 AIDE:');
  console.log('- Configurez les variables d\'environnement pour personnaliser les tests');
  console.log('- TECHNOCORNER_API_URL: URL de votre instance TechnoCorner');
  console.log('- SCANNER_ID: Identifiant unique de votre scanner');
  console.log('- LOCATION: Nom de l\'emplacement du scanner');
  console.log('- Pour le support: consultez GUIDE_INTEGRATION_MACHINES_SCAN.md');
}

// Gestion des erreurs non capturées
process.on('unhandledRejection', (reason, promise) => {
  console.error('💥 Erreur non gérée:', reason);
  process.exit(1);
});

// Exécution
if (require.main === module) {
  executerTests().catch(console.error);
}

module.exports = { testerValidationBillet, testerVerificationBillet, CONFIG };