// Simple test to debug the API response structure
const http = require('http');

async function testAuthAndEvents() {
  console.log('=== Testing Authentication ===');
  
  // Test current user
  const authOptions = {
    hostname: 'localhost',
    port: 5000,
    path: '/api/auth/current',
    method: 'GET'
  };

  const authReq = http.request(authOptions, (res) => {
    let data = '';
    res.on('data', (chunk) => {
      data += chunk;
    });
    res.on('end', () => {
      console.log('Auth Response Status:', res.statusCode);
      console.log('Auth Response Data:', data);
      
      if (res.statusCode === 200) {
        const user = JSON.parse(data);
        const userEmail = user.email || `${user.username}@technocorner.local`;
        console.log('User Email for filtering:', userEmail);
        
        // Now test events
        testEvents(userEmail);
      }
    });
  });

  authReq.on('error', (err) => {
    console.error('Auth Error:', err);
  });

  authReq.end();
}

function testEvents(userEmail) {
  console.log('\n=== Testing Events ===');
  
  const eventsOptions = {
    hostname: 'localhost',
    port: 5000,
    path: '/api/events',
    method: 'GET'
  };

  const eventsReq = http.request(eventsOptions, (res) => {
    let data = '';
    res.on('data', (chunk) => {
      data += chunk;
    });
    res.on('end', () => {
      console.log('Events Response Status:', res.statusCode);
      
      if (res.statusCode === 200) {
        const events = JSON.parse(data);
        console.log('Total events:', events.length);
        
        // Check the structure of the first few events
        events.slice(0, 3).forEach((event, index) => {
          console.log(`\nEvent ${index + 1}:`);
          console.log('- ID:', event.id);
          console.log('- Title:', event.title);
          console.log('- organizerEmail:', event.organizerEmail);
          console.log('- organizer_email:', event.organizer_email);
        });
        
        // Filter events for the current user
        const userEvents = events.filter(event => 
          event.organizerEmail === userEmail || event.organizer_email === userEmail
        );
        
        console.log(`\nFiltering results for "${userEmail}":`);
        console.log('Matching events:', userEvents.length);
        userEvents.forEach(event => {
          console.log(`- Event ID ${event.id}: "${event.title}" (organizer: ${event.organizerEmail || event.organizer_email})`);
        });
      }
    });
  });

  eventsReq.on('error', (err) => {
    console.error('Events Error:', err);
  });

  eventsReq.end();
}

testAuthAndEvents();