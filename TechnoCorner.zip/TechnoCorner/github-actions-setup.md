# Solutions App Store sans Xcode local

## Option 1 : GitHub Actions + Xcode Cloud

### Configuration GitHub Actions
```yaml
# .github/workflows/ios-build.yml
name: Build iOS App

on:
  push:
    branches: [ main ]

jobs:
  build:
    runs-on: macos-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        
    - name: Install dependencies
      run: npm install
      
    - name: Build web app
      run: npm run build
      
    - name: Setup Capacitor
      run: |
        npx cap add ios
        npx cap sync ios
        
    - name: Build iOS
      run: |
        cd ios/App
        xcodebuild -workspace App.xcworkspace -scheme App -destination generic/platform=iOS -archivePath App.xcarchive archive
        
    - name: Export IPA
      run: |
        cd ios/App
        xcodebuild -exportArchive -archivePath App.xcarchive -exportPath . -exportOptionsPlist exportOptions.plist
```

### Setup du projet
```bash
cd ~/technocorner

# Créer repository GitHub
git init
git add .
git commit -m "Initial commit"

# Pousser vers GitHub
# GitHub va builder automatiquement l'app iOS
```

## Option 2 : Codemagic (Service Cloud)

### Configuration .codemagic.yaml
```yaml
workflows:
  ios-workflow:
    name: iOS Workflow
    max_build_duration: 120
    instance_type: mac_mini_m1
    environment:
      groups:
        - app_store_credentials
      vars:
        BUNDLE_ID: "com.technocorner.app"
        XCODE_WORKSPACE: "ios/App/App.xcworkspace"
        XCODE_SCHEME: "App"
      node: latest
    scripts:
      - name: Install npm dependencies
        script: |
          npm install
      - name: Capacitor update
        script: |
          npx cap sync ios
      - name: Set up provisioning profiles
        script: |
          keychain initialize
      - name: Build ipa for distribution
        script: |
          xcode-project build-ipa \
            --workspace "$XCODE_WORKSPACE" \
            --scheme "$XCODE_SCHEME"
    artifacts:
      - build/ios/ipa/*.ipa
    publishing:
      app_store_connect:
        auth: integration
        submit_to_app_store: true
```

### Étapes Codemagic
1. **Inscription :** codemagic.io
2. **Connecter GitHub :** Autoriser accès au repository
3. **Ajouter certificats :** Apple Developer certificates
4. **Build automatique :** Push = build iOS
5. **Publication auto :** Direct vers App Store

## Option 3 : Bitrise (Alternative)

```yaml
# bitrise.yml
format_version: '11'
default_step_lib_source: https://github.com/bitrise-io/bitrise-steplib.git

workflows:
  primary:
    description: |
      Builds project and deploys to App Store Connect
    steps:
    - activate-ssh-key@4: {}
    - git-clone@8: {}
    - npm@1:
        inputs:
        - command: install
    - npm@1:
        inputs:
        - command: run build
    - script@1:
        title: Capacitor sync
        inputs:
        - content: |
            #!/usr/bin/env bash
            npx cap sync ios
    - certificate-and-profile-installer@1: {}
    - xcode-archive@4:
        inputs:
        - project_path: ios/App/App.xcworkspace
        - scheme: App
        - export_method: app-store
    - deploy-to-itunesconnect-application-loader@1:
        inputs:
        - password: $APPLE_PASSWORD
        - app_password: $APPLE_APP_PASSWORD
```

## Option 4 : Fastlane + Match

### Installation Fastlane
```bash
cd ~/technocorner

# Installer Fastlane
sudo gem install fastlane

# Initialiser
cd ios/App
fastlane init

# Configuration automatique certificates
fastlane match init
```

### Fastfile configuration
```ruby
# ios/App/fastlane/Fastfile
default_platform(:ios)

platform :ios do
  desc "Build and upload to App Store"
  lane :release do
    # Sync certificates
    match(type: "appstore")
    
    # Build app
    gym(
      workspace: "App.xcworkspace",
      scheme: "App",
      export_method: "app-store"
    )
    
    # Upload to App Store
    upload_to_app_store(
      skip_metadata: true,
      skip_screenshots: true
    )
  end
end
```

### Commandes de déploiement
```bash
# Build et upload automatique
fastlane release
```

## Option 5 : Expo Application Services (EAS)

### Conversion vers Expo
```bash
cd ~/technocorner

# Créer nouveau projet Expo
npx create-expo-app technocorner-expo
cd technocorner-expo

# Copier votre code React
cp -r ../src ./

# Configuration EAS
npx eas build:configure

# Build iOS dans le cloud
npx eas build --platform ios

# Submit vers App Store
npx eas submit --platform ios
```

### Configuration eas.json
```json
{
  "cli": {
    "version": ">= 5.2.0"
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "production": {
      "distribution": "store"
    }
  },
  "submit": {
    "production": {
      "ios": {
        "appleId": "your-apple-id@email.com",
        "ascAppId": "1234567890",
        "appleTeamId": "XXXXXXXXXX"
      }
    }
  }
}
```

## Recommandation pour App Store

**Option 2 (Codemagic)** est la plus simple :

1. **Push code vers GitHub**
2. **Connecter Codemagic**
3. **Ajouter certificats Apple**
4. **Build et publication automatiques**

**Avantages :**
- Pas besoin de Mac local pour build
- Pipeline CI/CD automatique
- Publication directe vers App Store
- Support technique inclus

**Étapes rapides :**
1. Créer compte sur codemagic.io
2. Connecter votre repository GitHub
3. Ajouter certificats Apple Developer
4. Configurer le workflow
5. Push = publication automatique

Cette solution contourne complètement les problèmes locaux et publie directement sur l'App Store.

Voulez-vous que je configure l'une de ces solutions ?