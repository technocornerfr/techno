# Guide d'Intégration - Machines de Scan Anti-Fraude

## Solutions d'intégration disponibles

### 1. Intégration API directe (Recommandée)

Les machines de scan peuvent appeler directement nos endpoints de validation :

**Endpoint de validation :**
```
POST https://votre-domaine.com/api/validate-ticket
Content-Type: application/json

{
  "qrData": "{\"ticketCode\":\"TECHNO-123...\",\"eventId\":1,\"buyerName\":\"John Doe\"}",
  "validatorId": "scanner-entree-01",
  "location": "Entrée principale"
}
```

**Réponse succès :**
```json
{
  "valid": true,
  "validated": true,
  "message": "Billet validé avec succès",
  "ticket": {
    "buyerName": "John Doe",
    "status": "used",
    "usedAt": "2025-06-08T18:30:00Z"
  },
  "event": {
    "title": "Techno Night 2025",
    "date": "2025-12-31"
  }
}
```

**Réponse échec (billet déjà utilisé) :**
```json
{
  "valid": false,
  "alreadyUsed": true,
  "message": "Billet déjà utilisé le 08/06/2025 à 18:25",
  "usedAt": "2025-06-08T18:25:00Z"
}
```

### 2. Code d'intégration pour machines existantes

#### Python (pour scanners compatibles)
```python
import requests
import json

def valider_billet_technocorner(contenu_qr, id_scanner="scanner-01"):
    """
    Valide un billet via l'API TechnoCorner
    Retourne True si accès autorisé, False sinon
    """
    url = "https://votre-domaine.com/api/validate-ticket"
    
    payload = {
        "qrData": contenu_qr,
        "validatorId": id_scanner,
        "location": "Entrée"
    }
    
    try:
        response = requests.post(
            url, 
            json=payload, 
            timeout=5,
            headers={'Content-Type': 'application/json'}
        )
        result = response.json()
        
        if result.get("valid") and result.get("validated"):
            print(f"✅ ACCÈS AUTORISÉ - {result.get('message')}")
            return True
        else:
            print(f"❌ ACCÈS REFUSÉ - {result.get('message')}")
            if result.get("alreadyUsed"):
                print(f"⚠️  FRAUDE DÉTECTÉE: Billet utilisé le {result.get('usedAt')}")
            return False
            
    except Exception as e:
        print(f"🔧 ERREUR CONNEXION: {e}")
        # Mode dégradé - à définir selon vos besoins
        return False

# Exemple d'utilisation
if __name__ == "__main__":
    # Simulation d'un scan QR
    qr_content = '{"ticketCode":"TECHNO-1749365479238-YQ9G5R04D","eventId":90,"buyerName":"Test User"}'
    
    if valider_billet_technocorner(qr_content, "scanner-entree-vip"):
        # Autoriser l'accès, ouvrir barrière, etc.
        pass
    else:
        # Refuser l'accès, alerter sécurité
        pass
```

#### JavaScript/Node.js (pour terminaux web)
```javascript
class ValidateurBilletTechnoCorner {
    constructor(baseUrl = 'https://votre-domaine.com', scannerId = 'scanner-web-01') {
        this.baseUrl = baseUrl;
        this.scannerId = scannerId;
    }
    
    async validerBillet(contenuQR) {
        try {
            const response = await fetch(`${this.baseUrl}/api/validate-ticket`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    qrData: contenuQR,
                    validatorId: this.scannerId,
                    location: 'Terminal web'
                })
            });
            
            const result = await response.json();
            
            if (result.valid && result.validated) {
                this.afficherSucces(result.message);
                return true;
            } else {
                this.afficherErreur(result.message);
                if (result.alreadyUsed) {
                    this.alerteFraude(result.usedAt);
                }
                return false;
            }
            
        } catch (error) {
            this.afficherErreur(`Erreur de connexion: ${error.message}`);
            return false;
        }
    }
    
    afficherSucces(message) {
        console.log(`✅ ${message}`);
        // Affichage visuel pour l'opérateur
    }
    
    afficherErreur(message) {
        console.log(`❌ ${message}`);
        // Affichage d'erreur pour l'opérateur
    }
    
    alerteFraude(dateUtilisation) {
        console.log(`🚨 FRAUDE DÉTECTÉE: Billet utilisé le ${dateUtilisation}`);
        // Alerte sécurité
    }
}

// Utilisation
const validateur = new ValidateurBilletTechnoCorner();
validateur.validerBillet(contenuQRCode);
```

### 3. Configuration machine de scan

#### Variables d'environnement recommandées
```bash
# Configuration TechnoCorner
TECHNOCORNER_API_URL=https://votre-domaine.com
SCANNER_ID=scanner-entree-principale
LOCATION=Entrée principale
TIMEOUT_SECONDS=5
RETRY_ATTEMPTS=3

# Mode hors ligne (optionnel)
OFFLINE_MODE=false
CACHE_VALIDATIONS=true
```

#### Gestion des erreurs réseau
```python
def valider_avec_retry(contenu_qr, max_tentatives=3):
    for tentative in range(max_tentatives):
        try:
            return valider_billet_technocorner(contenu_qr)
        except requests.exceptions.Timeout:
            if tentative < max_tentatives - 1:
                time.sleep(1)  # Attendre 1 seconde avant retry
                continue
            else:
                # Mode dégradé après échec des tentatives
                return mode_degrade(contenu_qr)
        except requests.exceptions.ConnectionError:
            # Pas de connexion - mode hors ligne
            return mode_hors_ligne(contenu_qr)

def mode_degrade(contenu_qr):
    """Mode de secours sans validation serveur"""
    # Validation basique côté client
    # À adapter selon vos besoins sécuritaires
    return True

def mode_hors_ligne(contenu_qr):
    """Mode hors ligne avec cache local"""
    # Vérifier cache local des billets déjà validés
    # Synchroniser plus tard avec le serveur
    return True
```

### 4. Codes de test

Pour tester votre intégration, utilisez ces codes QR de test :

```json
// Billet valide
{"ticketCode":"TECHNO-1749365479238-YQ9G5R04D","eventId":90,"buyerName":"Test Valide"}

// Billet déjà utilisé (pour tester anti-fraude)
{"ticketCode":"TECHNO-1749364928912-QQU3AH8LZ","eventId":26,"buyerName":"Test Utilisé"}
```

### 5. Types de machines compatibles

#### Scanners QR autonomes
- Configuration via API REST
- Écran de retour simple (vert/rouge)
- Connexion WiFi/Ethernet requise

#### Tablettes/terminaux Android
- Application web responsive
- Scanner via caméra intégrée
- Interface tactile optimisée

#### Systèmes de contrôle d'accès existants
- Intégration via webhook
- API compatible avec la plupart des systèmes
- Logs centralisés automatiques

#### Tourniquets électroniques
- Signal d'ouverture via API
- Intégration possible avec relais
- Traçabilité complète des passages

### 6. Sécurité et conformité

#### Protection anti-fraude intégrée
- ✅ Détection de billets dupliqués
- ✅ Horodatage précis des validations
- ✅ Traçabilité complète par scanner
- ✅ Logs d'audit automatiques
- ✅ Alertes fraude en temps réel

#### Recommandations sécuritaires
- Utiliser HTTPS exclusivement
- Configurer des timeouts appropriés
- Implémenter un mode dégradé sécurisé
- Surveiller les tentatives de fraude
- Synchroniser régulièrement avec le serveur

### 7. Support et assistance

#### Tests d'intégration
- Environnement de test disponible
- Codes de test fournis
- Documentation d'API complète

#### Assistance technique
- Support par email pour l'intégration
- Documentation technique détaillée
- Exemples de code pour langages courants

Cette intégration garantit qu'aucun billet ne peut être utilisé deux fois, même avec des machines de scan distribuées, tout en restant simple à implémenter sur vos équipements existants.