export interface EventFilters {
  category: string;
  search: string;
  sortBy: string;
}

export interface EventStats {
  events: number;
  djs: number;
  venues: number;
}
