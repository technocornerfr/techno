import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { QrCode, CheckCircle, XCircle, ScanLine, User, Mail, CalendarDays, MapPin, Smartphone } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

interface VerificationResult {
  valid: boolean;
  message: string;
  ticket?: any;
  event?: any;
  validated?: boolean;
  alreadyUsed?: boolean;
  usedAt?: string;
}

export default function VerifyTicket() {
  const [qrData, setQrData] = useState("");
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);
  const [validatorId, setValidatorId] = useState("");

  const verifyMutation = useMutation({
    mutationFn: async (qrData: string) => {
      const response = await apiRequest("POST", "/api/verify-ticket", { qrData });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur de vérification");
      }
      return response.json();
    },
    onSuccess: (data: VerificationResult) => {
      setVerificationResult(data);
    },
    onError: (error: Error) => {
      setVerificationResult({
        valid: false,
        message: error.message
      });
    }
  });

  const validateMutation = useMutation({
    mutationFn: async ({ qrData, validatorId }: { qrData: string; validatorId: string }) => {
      const response = await apiRequest("POST", "/api/validate-ticket", { qrData, validatorId });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur de validation");
      }
      return response.json();
    },
    onSuccess: (data: VerificationResult) => {
      setVerificationResult(data);
    },
    onError: (error: Error) => {
      setVerificationResult({
        valid: false,
        message: error.message
      });
    }
  });

  const handleVerify = () => {
    if (!qrData.trim()) return;
    verifyMutation.mutate(qrData.trim());
  };

  const handleValidate = () => {
    if (!qrData.trim()) return;
    validateMutation.mutate({ qrData: qrData.trim(), validatorId: validatorId || 'scanner' });
  };

  const handleScanAnother = () => {
    setQrData("");
    setVerificationResult(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black p-6">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-4">
            🔍 Vérification de Billets
          </h1>
          <p className="text-gray-400 mb-4">
            Scanner ou coller les données QR code pour vérifier l'authenticité des billets
          </p>
          <Link href="/mobile-scanner">
            <Button className="bg-purple-600 hover:bg-purple-700 text-white">
              <Smartphone className="h-4 w-4 mr-2" />
              Scanner mobile
            </Button>
          </Link>
        </div>

        <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <ScanLine className="h-5 w-5 text-purple-400" />
              <span>Scanner un billet</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="qrData" className="text-gray-300">
                Données du QR code
              </Label>
              <Input
                id="qrData"
                value={qrData}
                onChange={(e) => setQrData(e.target.value)}
                placeholder='{"ticketCode":"TECHNO-1749...","eventId":1,"buyerName":"..."}'
                className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                disabled={verifyMutation.isPending || validateMutation.isPending}
              />
              <p className="text-xs text-gray-400 mt-1">
                Collez ici le contenu JSON du QR code scanné
              </p>
            </div>

            <div>
              <Label htmlFor="validatorId" className="text-gray-300">
                ID Validateur (optionnel)
              </Label>
              <Input
                id="validatorId"
                value={validatorId}
                onChange={(e) => setValidatorId(e.target.value)}
                placeholder="scanner-1, agent-001, etc."
                className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                disabled={verifyMutation.isPending || validateMutation.isPending}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button 
                onClick={handleVerify}
                disabled={!qrData.trim() || verifyMutation.isPending || validateMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {verifyMutation.isPending ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Vérification...
                  </>
                ) : (
                  <>
                    <QrCode className="h-4 w-4 mr-2" />
                    Vérifier
                  </>
                )}
              </Button>

              <Button 
                onClick={handleValidate}
                disabled={!qrData.trim() || verifyMutation.isPending || validateMutation.isPending}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                {validateMutation.isPending ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Validation...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Valider à l'entrée
                  </>
                )}
              </Button>
            </div>

            <div className="text-xs text-gray-400 space-y-1">
              <p><strong>Vérifier :</strong> Contrôle la validité sans marquer comme utilisé</p>
              <p><strong>Valider :</strong> Marque le billet comme utilisé (entrée définitive)</p>
            </div>
          </CardContent>
        </Card>

        {/* Résultat de la vérification */}
        {verificationResult && (
          <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                {verificationResult.valid ? (
                  <CheckCircle className="h-5 w-5 text-green-400" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-400" />
                )}
                <span>Résultat de la vérification</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className={verificationResult.valid 
                ? "border-green-500/50 bg-green-900/20" 
                : "border-red-500/50 bg-red-900/20"
              }>
                <AlertDescription className={verificationResult.valid ? "text-green-200" : "text-red-200"}>
                  {verificationResult.message}
                  {verificationResult.alreadyUsed && verificationResult.usedAt && (
                    <div className="mt-2 text-xs">
                      Utilisé le : {new Date(verificationResult.usedAt).toLocaleString('fr-FR')}
                    </div>
                  )}
                </AlertDescription>
              </Alert>

              {verificationResult.valid && verificationResult.ticket && verificationResult.event && (
                <div className="space-y-4 border-t border-purple-500/20 pt-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-white">Détails du billet</h3>
                    <div className="flex space-x-2">
                      {verificationResult.validated ? (
                        <Badge className="bg-green-600 text-white">
                          ✓ Validé à l'entrée
                        </Badge>
                      ) : (
                        <Badge className="bg-blue-600 text-white">
                          ✓ Valide
                        </Badge>
                      )}
                      {verificationResult.ticket.status === "used" && (
                        <Badge className="bg-red-600 text-white">
                          Déjà utilisé
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Informations de l'événement */}
                  <div className="bg-gray-700/30 rounded-lg p-4 space-y-3">
                    <h4 className="font-semibold text-white">{verificationResult.event.title}</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2 text-gray-300">
                        <CalendarDays className="h-4 w-4 text-purple-400" />
                        <span>
                          {verificationResult.event.date 
                            ? format(new Date(verificationResult.event.date), "EEEE d MMMM yyyy", { locale: fr })
                            : "Date à confirmer"
                          }
                        </span>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-300">
                        <MapPin className="h-4 w-4 text-purple-400" />
                        <span>{verificationResult.event.venue || "Lieu à confirmer"}</span>
                      </div>
                    </div>
                  </div>

                  {/* Informations du détenteur */}
                  <div className="bg-gray-700/30 rounded-lg p-4 space-y-3">
                    <h4 className="font-semibold text-white">Détenteur du billet</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2 text-gray-300">
                        <User className="h-4 w-4 text-purple-400" />
                        <span>{verificationResult.ticket.buyerName}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-300">
                        <Mail className="h-4 w-4 text-purple-400" />
                        <span>{verificationResult.ticket.buyerEmail}</span>
                      </div>
                    </div>
                  </div>

                  {/* Métadonnées du billet */}
                  <div className="text-xs text-gray-400 space-y-1">
                    <div className="flex justify-between">
                      <span>ID du billet:</span>
                      <span className="font-mono">#{verificationResult.ticket.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Date d'achat:</span>
                      <span>
                        {format(new Date(verificationResult.ticket.purchaseDate), "dd/MM/yyyy à HH:mm", { locale: fr })}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <Button 
                onClick={handleScanAnother}
                variant="outline"
                className="w-full border-purple-500/50 text-purple-300 hover:bg-purple-900/20"
              >
                Vérifier un autre billet
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-400">
            🛡️ Système de vérification sécurisé TechnoCorner
          </p>
        </div>
      </div>
    </div>
  );
}