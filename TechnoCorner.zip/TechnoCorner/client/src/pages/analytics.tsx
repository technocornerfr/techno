import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { 
  TrendingUp, 
  Users, 
  Calendar, 
  Euro, 
  BarChart3, 
  Clock,
  Eye,
  Target
} from "lucide-react";

interface AnalyticsData {
  globalKPIs: {
    totalRevenue: number;
    totalTicketsSold: number;
    totalEvents: number;
    upcomingEvents: number;
    pastEvents: number;
    averageTicketsPerEvent: number;
  };
  eventAnalytics: Array<{
    id: number;
    title: string;
    date: string;
    venue: string;
    ticketsSold: number;
    ticketsAvailable: number;
    revenue: number;
    conversionRate: number;
    status: 'upcoming' | 'past';
  }>;
  salesByMonth: Array<{
    month: string;
    ticketCount: number;
    revenue: number;
  }>;
}

export default function Analytics() {
  const { user, isAuthenticated } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState("12months");

  const { data: analytics, isLoading, error } = useQuery({
    queryKey: [`/api/analytics/organizer/${user?.email}`, selectedPeriod],
    enabled: !!user?.email && isAuthenticated,
    refetchInterval: 30000, // Rafraîchissement toutes les 30 secondes
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-3xl font-bold text-white mb-4">
              Accès restreint
            </h1>
            <p className="text-slate-400">
              Vous devez être connecté pour accéder au tableau de bord Analytics.
            </p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-3xl font-bold text-white mb-4">
              Erreur de chargement
            </h1>
            <p className="text-slate-400">
              Impossible de charger les données Analytics. Veuillez réessayer plus tard.
            </p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
                Analytics Dashboard
              </h1>
              <p className="text-slate-400">
                Suivi en temps réel de vos performances événementielles
              </p>
            </div>
            
            <div className="flex items-center gap-4 mt-4 lg:mt-0">
              <Badge variant="outline" className="border-primary/20 text-primary">
                <Clock className="w-3 h-3 mr-1" />
                Mis à jour il y a 30s
              </Badge>
              
              <select 
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary/50"
              >
                <option value="3months">3 derniers mois</option>
                <option value="6months">6 derniers mois</option>
                <option value="12months">12 derniers mois</option>
                <option value="all">Toute la période</option>
              </select>
            </div>
          </div>

          {/* KPIs Globaux */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-8">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <Euro className="h-4 w-4 text-green-400" />
                  Revenus Total
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {analytics?.globalKPIs?.totalRevenue ? `${analytics.globalKPIs.totalRevenue.toLocaleString()}€` : '0€'}
                </div>
                <p className="text-xs text-green-400 flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3" />
                  +12% ce mois
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <Users className="h-4 w-4 text-blue-400" />
                  Tickets Vendus
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {analytics?.globalKPIs?.totalTicketsSold || 0}
                </div>
                <p className="text-xs text-blue-400 flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3" />
                  +8% ce mois
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-purple-400" />
                  Événements Total
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {analytics?.globalKPIs?.totalEvents || 0}
                </div>
                <p className="text-xs text-purple-400 flex items-center gap-1 mt-1">
                  <Eye className="h-3 w-3" />
                  Tous statuts
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <Clock className="h-4 w-4 text-yellow-400" />
                  À Venir
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {analytics?.globalKPIs?.upcomingEvents || 0}
                </div>
                <p className="text-xs text-yellow-400 flex items-center gap-1 mt-1">
                  <Target className="h-3 w-3" />
                  Prochainement
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-slate-400" />
                  Passés
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {analytics?.globalKPIs?.pastEvents || 0}
                </div>
                <p className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                  <Eye className="h-3 w-3" />
                  Terminés
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400 flex items-center gap-2">
                  <Target className="h-4 w-4 text-pink-400" />
                  Moyenne Tickets
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {analytics?.globalKPIs?.averageTicketsPerEvent ? Math.round(analytics.globalKPIs.averageTicketsPerEvent) : 0}
                </div>
                <p className="text-xs text-pink-400 flex items-center gap-1 mt-1">
                  <Users className="h-3 w-3" />
                  Par événement
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Message si pas de données */}
          {(!analytics || !analytics.eventAnalytics || analytics.eventAnalytics.length === 0) && (
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardContent className="text-center py-12">
                <BarChart3 className="h-16 w-16 text-slate-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">
                  Aucune donnée disponible
                </h3>
                <p className="text-slate-400 mb-6">
                  Commencez par créer vos premiers événements pour voir apparaître vos analytics.
                </p>
                <a
                  href="/create"
                  className="inline-flex items-center px-6 py-3 bg-primary hover:bg-primary/90 text-white font-medium rounded-lg transition-colors"
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Créer un événement
                </a>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}