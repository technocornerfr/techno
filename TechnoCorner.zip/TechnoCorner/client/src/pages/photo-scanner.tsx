import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Camera, Upload, Scan, CheckCircle, XCircle, AlertTriangle, ImageIcon, Play, Square } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import QrScanner from "qr-scanner";

interface ScanResult {
  valid: boolean;
  validated?: boolean;
  message: string;
  alreadyUsed?: boolean;
  usedAt?: string;
  ticket?: any;
}

export default function PhotoScanner() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [scannerId, setScannerId] = useState('PHOTO-SCANNER-001');
  const [location, setLocation] = useState('Validation photo');
  const [scanResults, setScanResults] = useState<Array<{
    timestamp: string;
    filename: string;
    qrData: string;
    result: ScanResult;
  }>>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [cameraMode, setCameraMode] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [qrScanner, setQrScanner] = useState<QrScanner | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Cleanup function for camera resources
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
      if (qrScanner) {
        qrScanner.destroy();
      }
    };
  }, []);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const startCamera = async () => {
    try {
      setCameraMode(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      
      setCameraStream(stream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        
        // Initialize QR scanner on video element
        const scanner = new QrScanner(
          videoRef.current,
          (result) => handleQRDetected(result.data),
          {
            highlightScanRegion: true,
            highlightCodeOutline: true,
            preferredCamera: 'environment'
          }
        );
        
        setQrScanner(scanner);
        await scanner.start();
      }
    } catch (error) {
      console.error('Erreur d\'accès à la caméra:', error);
      setCameraMode(false);
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    
    if (qrScanner) {
      qrScanner.destroy();
      setQrScanner(null);
    }
    
    setCameraMode(false);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext('2d');
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      if (context) {
        context.drawImage(video, 0, 0);
        
        // Convert canvas to blob and process as file
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], 'camera-capture.jpg', { type: 'image/jpeg' });
            setSelectedFile(file);
            const url = URL.createObjectURL(file);
            setPreviewUrl(url);
            stopCamera();
          }
        }, 'image/jpeg', 0.9);
      }
    }
  };

  const handleQRDetected = async (qrData: string) => {
    if (isScanning) return; // Prevent multiple scans
    
    setIsScanning(true);
    stopCamera();
    
    try {
      const response = await apiRequest("POST", "/api/scanner/validate", {
        qrData,
        scannerId,
        location
      });
      
      if (response.ok) {
        const result: ScanResult = await response.json();
        
        // Add to scan results
        setScanResults(prev => [{
          timestamp: new Date().toLocaleString('fr-FR'),
          filename: 'Scan caméra',
          qrData,
          result
        }, ...prev]);
        
      } else {
        console.error('Erreur de validation:', response.statusText);
      }
    } catch (error) {
      console.error('Erreur lors de la validation:', error);
    } finally {
      setIsScanning(false);
    }
  };

  const scanPhotoForQR = async () => {
    if (!selectedFile) return;

    setIsScanning(true);
    try {
      // Utiliser QrScanner pour lire le QR code depuis l'image
      const qrData = await QrScanner.scanImage(selectedFile);

      if (qrData) {
        // Valider le billet avec les données du QR code
        const response = await apiRequest("POST", "/api/validate-ticket", {
          qrData: qrData,
          validatorId: scannerId,
          location: location
        });
        
        const result = await response.json();
        
        setScanResults(prev => [...prev, {
          timestamp: new Date().toLocaleString('fr-FR'),
          filename: selectedFile.name,
          qrData: qrData.substring(0, 100) + '...',
          result
        }]);

        // Nettoyer la sélection
        setSelectedFile(null);
        setPreviewUrl('');
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      } else {
        // Aucun QR code trouvé
        setScanResults(prev => [...prev, {
          timestamp: new Date().toLocaleString('fr-FR'),
          filename: selectedFile.name,
          qrData: 'Aucun QR code détecté',
          result: {
            valid: false,
            message: 'Aucun QR code trouvé dans l\'image'
          }
        }]);
      }
    } catch (error) {
      console.error('Erreur scan photo:', error);
      setScanResults(prev => [...prev, {
        timestamp: new Date().toLocaleString('fr-FR'),
        filename: selectedFile?.name || 'Fichier inconnu',
        qrData: 'Erreur de scan',
        result: {
          valid: false,
          message: 'Erreur lors de la lecture du QR code'
        }
      }]);
    } finally {
      setIsScanning(false);
    }
  };

  const getStatusIcon = (result: ScanResult) => {
    if (result.validated) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    } else if (result.alreadyUsed) {
      return <AlertTriangle className="h-4 w-4 text-orange-500" />;
    } else {
      return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusColor = (result: ScanResult) => {
    if (result.validated) {
      return 'bg-green-600';
    } else if (result.alreadyUsed) {
      return 'bg-orange-600';
    } else {
      return 'bg-red-600';
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-4">
            <Camera className="inline h-8 w-8 mr-3 text-purple-400" />
            Scanner Photo QR Code
          </h1>
          <p className="text-gray-400">
            Validation de billets par photo pour organisateurs
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Interface de scan photo */}
          <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <ImageIcon className="h-5 w-5 text-blue-400" />
                <span>Sélection d'Image</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="scannerId" className="text-gray-300">
                  Identifiant Scanner
                </Label>
                <Input
                  id="scannerId"
                  value={scannerId}
                  onChange={(e) => setScannerId(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="location" className="text-gray-300">
                  Emplacement
                </Label>
                <Input
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              {/* Camera / File selection mode toggle */}
              <div className="flex space-x-2 mb-4">
                <Button
                  onClick={() => {
                    if (cameraMode) {
                      stopCamera();
                    } else {
                      startCamera();
                    }
                  }}
                  className={`flex-1 ${cameraMode ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'}`}
                >
                  {cameraMode ? (
                    <>
                      <Square className="h-4 w-4 mr-2" />
                      Arrêter caméra
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Démarrer caméra
                    </>
                  )}
                </Button>
                
                <Button
                  onClick={triggerFileSelect}
                  variant="outline"
                  className="flex-1 border-gray-600 text-gray-300"
                  disabled={cameraMode}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Sélectionner fichier
                </Button>
              </div>

              {/* Camera view */}
              {cameraMode && (
                <div className="space-y-4">
                  <Label className="text-gray-300">Caméra en direct</Label>
                  <div className="relative bg-black rounded-lg overflow-hidden">
                    <video
                      ref={videoRef}
                      className="w-full h-64 object-cover"
                      playsInline
                      muted
                    />
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                      <Button
                        onClick={capturePhoto}
                        className="bg-white/20 hover:bg-white/30 text-white border border-white/30"
                      >
                        <Camera className="h-4 w-4 mr-2" />
                        Capturer
                      </Button>
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-400">
                      Pointez la caméra vers un QR code ou capturez une photo
                    </p>
                    <p className="text-xs text-gray-500">
                      Détection automatique des QR codes activée
                    </p>
                  </div>
                </div>
              )}

              {/* File selection area (only shown when camera is off) */}
              {!cameraMode && (
                <div className="space-y-4">
                  <Label className="text-gray-300">Photo du QR Code</Label>
                  
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />

                  <div 
                    onClick={triggerFileSelect}
                    className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center hover:border-purple-500 cursor-pointer transition-colors"
                  >
                    {previewUrl ? (
                      <div className="space-y-2">
                        <img 
                          src={previewUrl} 
                          alt="Aperçu" 
                          className="max-w-full max-h-48 mx-auto rounded-lg"
                        />
                        <p className="text-sm text-gray-400">{selectedFile?.name}</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Upload className="h-12 w-12 text-gray-500 mx-auto" />
                        <p className="text-gray-400">Cliquez pour sélectionner une photo</p>
                        <p className="text-xs text-gray-500">JPG, PNG, WebP acceptés</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Hidden canvas for photo capture */}
              <canvas ref={canvasRef} style={{ display: 'none' }} />

              <Button
                onClick={scanPhotoForQR}
                disabled={!selectedFile || isScanning}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              >
                {isScanning ? (
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                ) : (
                  <Scan className="h-4 w-4 mr-2" />
                )}
                Scanner QR Code
              </Button>

              <Alert className="border-blue-500/50 bg-blue-900/20">
                <Camera className="h-4 w-4" />
                <AlertDescription className="text-blue-200">
                  <strong>Comment utiliser:</strong>
                  <br/>1. Prenez une photo nette du QR code
                  <br/>2. Sélectionnez l'image depuis votre appareil
                  <br/>3. Cliquez sur "Scanner QR Code" pour valider
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* Historique des scans */}
          <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Scan className="h-5 w-5 text-green-400" />
                <span>Historique des Scans Photo</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {scanResults.length === 0 ? (
                <div className="text-center py-8">
                  <ImageIcon className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Aucun scan photo effectué</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {scanResults.slice().reverse().map((entry, index) => (
                    <div key={index} className="bg-gray-700/50 p-3 rounded-lg border border-gray-600">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(entry.result)}
                          <Badge className={getStatusColor(entry.result)}>
                            PHOTO SCAN
                          </Badge>
                        </div>
                        <span className="text-xs text-gray-400">{entry.timestamp}</span>
                      </div>
                      
                      <div className="text-sm space-y-1">
                        <div className="text-gray-300">
                          <strong>Fichier:</strong> {entry.filename}
                        </div>
                        <div className="text-gray-300">
                          <strong>Résultat:</strong> {entry.result.message}
                        </div>
                        {entry.qrData !== 'Aucun QR code détecté' && entry.qrData !== 'Erreur de scan' && (
                          <div className="text-gray-400 font-mono text-xs">
                            QR: {entry.qrData}
                          </div>
                        )}
                        {entry.result.usedAt && (
                          <div className="text-orange-300 text-xs">
                            Utilisé le: {new Date(entry.result.usedAt).toLocaleString('fr-FR')}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Guide d'utilisation */}
        <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm mt-6">
          <CardHeader>
            <CardTitle className="text-white">Guide d'Utilisation Photo Scanner</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 text-sm">
              <div>
                <h4 className="font-semibold text-white mb-3">1. Prise de Photo</h4>
                <div className="space-y-2 text-gray-300">
                  <div>• Assurez-vous que le QR code est net et visible</div>
                  <div>• Évitez les reflets et les ombres</div>
                  <div>• Centrez le QR code dans l'image</div>
                  <div>• Utilisez un bon éclairage</div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-3">2. Formats Supportés</h4>
                <div className="space-y-1 text-gray-300">
                  <div>• JPEG / JPG</div>
                  <div>• PNG</div>
                  <div>• WebP</div>
                  <div>• Résolution recommandée: 1080p+</div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-3">3. Cas d'Usage</h4>
                <div className="space-y-1 text-gray-300">
                  <div>• Validation hors ligne</div>
                  <div>• Contrôle manuel de billets</div>
                  <div>• Backup du scanner principal</div>
                  <div>• Support technique</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}