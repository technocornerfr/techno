import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Heart, MessageCircle, Share2, RefreshCw } from "lucide-react";
import { Header } from "@/components/layout/header";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, getQueryFn } from "@/lib/queryClient";

export default function Community() {
  const [feedMode, setFeedMode] = useState<"recommended" | "recent">("recommended");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user: currentUser, isAuthenticated } = useAuth();

  const { data: posts, isLoading, error, refetch } = useQuery({
    queryKey: feedMode === "recommended" ? ["/api/posts/recommended"] : ["/api/posts"],
    queryFn: async () => {
      const endpoint = feedMode === "recommended" ? "/api/posts/recommended" : "/api/posts";
      console.log("Making request to:", endpoint);
      const response = await fetch(endpoint, {
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });
      console.log("Response status:", response.status);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      console.log("Received data:", data);
      console.log("Data length:", data?.length);
      console.log("Is array:", Array.isArray(data));
      return Array.isArray(data) ? data : [];
    },
    enabled: true,
    staleTime: 0,
    gcTime: 0,
    retry: 3,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });

  const displayedPosts = Array.isArray(posts) ? posts : [];
  
  // Force re-render when posts change
  useEffect(() => {
    console.log("Posts updated:", { posts, displayedPosts: displayedPosts.length });
  }, [posts, displayedPosts.length]);
  
  // Debug logging
  console.log("Feed mode:", feedMode);
  console.log("Raw posts data:", posts);
  console.log("Displayed posts:", displayedPosts);
  console.log("Is loading:", isLoading);
  console.log("Error:", error);

  const formatPostDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "À l'instant";
    if (diffInMinutes < 60) return `${diffInMinutes}min`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h`;
    return `${Math.floor(diffInMinutes / 1440)}j`;
  };

  const likeMutation = useMutation({
    mutationFn: async ({ postId, isLiked }: { postId: number; isLiked: boolean }) => {
      const endpoint = isLiked ? `/api/posts/${postId}/unlike` : `/api/posts/${postId}/like`;
      return apiRequest("POST", endpoint);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [feedMode === "recommended" ? "/api/posts/recommended" : "/api/posts"] });
    },
  });

  const handleLike = (postId: number, isCurrentlyLiked: boolean) => {
    if (!isAuthenticated) {
      toast({
        title: "Connexion requise",
        description: "Vous devez être connecté pour aimer un post",
        variant: "destructive",
      });
      return;
    }
    likeMutation.mutate({ postId, isLiked: isCurrentlyLiked });
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              Communauté TechnoCorner
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Partagez vos moments techno, découvrez de nouveaux artistes et connectez-vous avec la communauté
            </p>
          </div>

          {/* Sélecteur de mode de feed */}
          <div className="flex justify-center mb-8">
            <div className="bg-slate-900/50 backdrop-blur-sm border border-primary/20 rounded-lg p-1 flex items-center">
              <Button
                variant={feedMode === "recommended" ? "default" : "ghost"}
                onClick={() => {
                  console.log("Switching to recommended mode");
                  setFeedMode("recommended");
                }}
                className={`px-6 py-2 rounded-md transition-all duration-300 ${
                  feedMode === "recommended" 
                    ? "bg-gradient-to-r from-primary to-secondary text-white shadow-lg" 
                    : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                }`}
              >
                Recommandés
              </Button>
              <Button
                variant={feedMode === "recent" ? "default" : "ghost"}
                onClick={() => {
                  console.log("Switching to recent mode");
                  setFeedMode("recent");
                }}
                className={`px-6 py-2 rounded-md transition-all duration-300 ${
                  feedMode === "recent" 
                    ? "bg-gradient-to-r from-primary to-secondary text-white shadow-lg" 
                    : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                }`}
              >
                Chronologique
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  console.log("Refreshing posts manually");
                  refetch();
                }}
                className="ml-2 text-slate-400 hover:text-white"
                disabled={isLoading}
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>

          <div className="space-y-6">
            {!isAuthenticated && (
              <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">Rejoignez la conversation !</h3>
                      <p className="text-slate-300 text-sm">
                        Connectez-vous pour partager vos expériences techno avec la communauté
                      </p>
                    </div>
                    <Button 
                      onClick={() => window.location.href = '/login'}
                      className="bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300"
                    >
                      Se connecter
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {isLoading ? (
              <div className="space-y-6">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="bg-slate-900/50 backdrop-blur-sm border-primary/20 animate-pulse">
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="w-10 h-10 bg-slate-700 rounded-full"></div>
                        <div className="space-y-2">
                          <div className="h-4 bg-slate-700 rounded w-24"></div>
                          <div className="h-3 bg-slate-700 rounded w-16"></div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="h-4 bg-slate-700 rounded"></div>
                        <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : error ? (
              <Card className="bg-red-900/20 border-red-500/20">
                <CardContent className="p-6 text-center">
                  <p className="text-red-400">Erreur lors du chargement des posts</p>
                </CardContent>
              </Card>
            ) : displayedPosts.length === 0 ? (
              <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                <CardContent className="p-6 text-center">
                  <p className="text-slate-400">Aucun post disponible</p>
                  <p className="text-xs text-slate-500 mt-2">Posts: {posts ? `${displayedPosts.length} trouvés` : 'données manquantes'}</p>
                </CardContent>
              </Card>
            ) : (
              displayedPosts.map((post: any) => (
                <Card key={post.id} className="bg-slate-900/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={post.author?.profileImageUrl || undefined} />
                        <AvatarFallback className="bg-gradient-to-r from-primary to-secondary text-white">
                          {post.author?.username?.[0]?.toUpperCase() || "U"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h4 className="font-semibold text-white">{post.author?.username || "Utilisateur"}</h4>
                        <p className="text-sm text-slate-400">{formatPostDate(post.createdAt)}</p>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-slate-200 leading-relaxed whitespace-pre-wrap">
                        {post.content}
                      </p>
                      
                      {post.imageUrl && (
                        <div className="mt-4 relative">
                          {post.type === 'video' && (
                            <div className="relative">
                              <video
                                src={post.imageUrl}
                                controls
                                className="w-full rounded-lg max-h-96 object-cover"
                              />
                              <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                                🎥 Vidéo
                              </div>
                            </div>
                          )}
                          {post.type === 'image' && (
                            <div className="relative">
                              <img
                                src={post.imageUrl}
                                alt="Post image"
                                className="w-full rounded-lg max-h-96 object-cover"
                              />
                              <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                                🖼️ Image
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    <Separator className="bg-slate-700 mb-4" />

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-6">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleLike(post.id, post.isLiked)}
                          className={`text-slate-400 hover:text-red-400 ${post.isLiked ? 'text-red-400' : ''}`}
                        >
                          <Heart className={`w-4 h-4 mr-2 ${post.isLiked ? 'fill-current' : ''}`} />
                          {post.likesCount || 0}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-slate-400 hover:text-blue-400 transition-colors"
                        >
                          <MessageCircle className="w-4 h-4 mr-2" />
                          {(post.comments?.length || 0)} commentaire{((post.comments?.length || 0) !== 1) ? 's' : ''}
                        </Button>
                        <Button variant="ghost" size="sm" className="text-slate-400 hover:text-green-400">
                          <Share2 className="w-4 h-4 mr-2" />
                          Partager
                        </Button>
                      </div>
                    </div>

                    {/* Commentaires - Affichage simple et direct */}
                    {post.comments && post.comments.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-slate-700">
                        <div className="space-y-3">
                          {post.comments.map((comment: any) => (
                            <div key={comment.id} className="flex items-start space-x-3">
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={comment.author?.profileImageUrl || undefined} />
                                <AvatarFallback className="bg-accent text-white text-xs">
                                  {comment.author?.username?.[0]?.toUpperCase() || "U"}
                                </AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <div className="bg-slate-800/50 rounded-lg p-3">
                                  <div className="flex items-center space-x-2 mb-1">
                                    <span className="font-semibold text-white text-sm">
                                      {comment.author?.username || "Utilisateur"}
                                    </span>
                                    <span className="text-xs text-slate-400">
                                      {formatPostDate(comment.createdAt)}
                                    </span>
                                  </div>
                                  <p className="text-slate-300 text-sm">{comment.content}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}