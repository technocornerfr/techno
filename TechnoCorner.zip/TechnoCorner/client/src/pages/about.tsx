import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Music, Users, Ticket, Globe, Heart, Zap } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              À propos de TechnoCorner
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 max-w-4xl mx-auto leading-relaxed">
              La plateforme qui unit la communauté techno mondiale autour de sa passion commune pour la musique électronique underground.
            </p>
          </div>

          {/* Vision Section */}
          <div className="mb-20">
            <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-all duration-300">
              <CardContent className="p-8 md:p-12 text-center">
                <div className="flex items-center justify-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mr-4">
                    <Zap className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold text-white">Notre Vision</h2>
                </div>
                <p className="text-slate-300 leading-relaxed text-xl mb-6 max-w-4xl mx-auto">
                  Bienvenue sur TechnoCorner. Nous sommes une communauté dédiée à la musique techno et à l'organisation d'événements. Notre objectif est de rassembler les passionnés autour de soirées, festivals et expériences uniques.
                </p>
                <p className="text-slate-300 leading-relaxed text-xl max-w-4xl mx-auto">
                  Ici, vous pouvez découvrir des événements près de chez vous, créer les vôtres et partager vos moments avec d'autres membres. Que vous soyez DJ, organisateur ou simplement amateur de techno, cet espace est fait pour vous.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Features Grid */}
          <div className="mb-20">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-white">
              Ce que nous offrons
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-all duration-300 hover:scale-105">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Music className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-3">Événements</h3>
                  <p className="text-slate-300">
                    Découvrez et créez des événements techno dans le monde entier
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 backdrop-blur-sm border-secondary/20 hover:border-secondary/40 transition-all duration-300 hover:scale-105">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-secondary to-accent rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-3">Communauté</h3>
                  <p className="text-slate-300">
                    Connectez-vous avec des passionnés de techno du monde entier
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 backdrop-blur-sm border-accent/20 hover:border-accent/40 transition-all duration-300 hover:scale-105">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-accent to-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Ticket className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-3">Billeterie</h3>
                  <p className="text-slate-300">
                    Achetez vos billets en toute sécurité avec notre système intégré
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-all duration-300 hover:scale-105">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-4">
                    <Globe className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-3">Global</h3>
                  <p className="text-slate-300">
                    Une plateforme mondiale pour la scène techno underground
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>





          {/* Call to Action */}
          <div className="text-center">
            <Card className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 backdrop-blur-sm border-primary/30">
              <CardContent className="p-12">
                <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
                  Rejoignez la Révolution Techno
                </h2>
                <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
                  Que vous soyez DJ, organisateur d'événements ou simple passionné, TechnoCorner est votre plateforme pour explorer, créer et partager votre passion pour la techno.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/register">
                    <Button className="bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow px-8 py-3 text-lg">
                      Créer un compte
                    </Button>
                  </Link>
                  <Link href="/create">
                    <Button variant="outline" className="border-accent text-accent hover:bg-accent hover:text-white transition-all duration-300 px-8 py-3 text-lg">
                      Créer un événement
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}