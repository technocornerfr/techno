import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { MessageCircle, ArrowLeft, Send } from "lucide-react";

export default function MessagesWorking() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const [messages, setMessages] = useState<any[]>([]);
  const [conversations, setConversations] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [loadingConversations, setLoadingConversations] = useState(false);
  const [sendingMessage, setSendingMessage] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Extraire l'ID de l'autre utilisateur depuis l'URL
  const pathParts = location.split('/');
  const otherUserId = pathParts[2] ? parseInt(pathParts[2]) : null;

  const fetchConversations = async () => {
    setLoadingConversations(true);
    console.log("Récupération des conversations");
    
    try {
      const response = await fetch("/api/messages/conversations", {
        credentials: "include"
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log("Conversations récupérées:", data.length);
        setConversations(data);
      } else {
        console.log("Erreur lors de la récupération des conversations");
        setConversations([]);
      }
    } catch (error) {
      console.error("Erreur de récupération des conversations:", error);
      setConversations([]);
    } finally {
      setLoadingConversations(false);
    }
  };

  const fetchMessages = async () => {
    if (!otherUserId) return;
    
    setLoadingMessages(true);
    console.log("Récupération des messages pour l'utilisateur:", otherUserId);
    
    try {
      const response = await fetch(`/api/messages/conversation/${otherUserId}`, {
        credentials: "include"
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log("Messages récupérés:", data.length);
        setMessages(data);
      } else {
        console.log("Erreur lors de la récupération des messages");
        setMessages([]);
      }
    } catch (error) {
      console.error("Erreur de récupération:", error);
      setMessages([]);
    } finally {
      setLoadingMessages(false);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !otherUserId) return;

    setSendingMessage(true);
    
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({
          receiverId: otherUserId,
          content: newMessage.trim()
        })
      });

      if (response.ok) {
        toast({
          title: "Message envoyé !",
          description: "Votre message a été envoyé avec succès."
        });
        setNewMessage("");
        if (textareaRef.current) {
          textareaRef.current.style.height = 'auto';
          textareaRef.current.style.height = '48px';
        }
        fetchMessages(); // Recharger les messages
      } else {
        toast({
          title: "Erreur",
          description: "Impossible d'envoyer le message",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Erreur d'envoi:", error);
      toast({
        title: "Erreur",
        description: "Erreur lors de l'envoi du message",
        variant: "destructive"
      });
    } finally {
      setSendingMessage(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(scrollToBottom, 100);
    }
  }, [messages]);

  useEffect(() => {
    if (currentUser) {
      if (otherUserId) {
        fetchMessages();
      } else {
        fetchConversations();
      }
    }
  }, [otherUserId, currentUser]);

  // Vérifier l'authentification
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <Card className="bg-slate-800 border-slate-700 p-8 max-w-md">
            <CardContent className="text-center">
              <MessageCircle className="h-16 w-16 text-cyan-400 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-white mb-2">
                Connexion requise
              </h2>
              <p className="text-slate-400 mb-6">
                Vous devez être connecté pour accéder aux messages
              </p>
              <Button 
                onClick={() => setLocation("/login")}
                className="bg-cyan-600 hover:bg-cyan-700"
              >
                Se connecter
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  if (!otherUserId) {
    // Afficher la liste des conversations
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col">
        <Header />
        
        <div className="flex-1 max-w-4xl mx-auto w-full flex flex-col p-4">
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-white mb-2">
              Mes conversations
            </h1>
            <p className="text-slate-400">
              Choisissez une conversation ou visitez un profil utilisateur pour envoyer un nouveau message
            </p>
          </div>

          <Card className="flex-1 bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              {loadingConversations ? (
                <div className="text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400 mx-auto mb-2"></div>
                  <p className="text-slate-400">Chargement des conversations...</p>
                </div>
              ) : conversations.length > 0 ? (
                <div className="space-y-4">
                  {conversations.map((conversation: any) => (
                    <div
                      key={conversation.otherUserId}
                      onClick={() => setLocation(`/messages/${conversation.otherUserId}`)}
                      className="p-4 bg-slate-700/50 rounded-lg border border-slate-600 hover:border-cyan-400/50 cursor-pointer transition-all duration-200"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-purple-500 rounded-full flex items-center justify-center">
                            <span className="text-white font-semibold text-sm">
                              {conversation.otherUsername?.charAt(0).toUpperCase() || '?'}
                            </span>
                          </div>
                          <div>
                            <h3 className="text-white font-medium">
                              {conversation.otherUsername || `Utilisateur ${conversation.otherUserId}`}
                            </h3>
                            <p className="text-slate-400 text-sm truncate max-w-xs">
                              {conversation.lastMessage || "Aucun message"}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-slate-500 text-xs">
                            {conversation.lastMessageTime ? 
                              new Date(conversation.lastMessageTime).toLocaleDateString() : 
                              ""
                            }
                          </p>
                          {conversation.unreadCount > 0 && (
                            <span className="inline-flex items-center justify-center w-5 h-5 bg-cyan-600 text-white text-xs rounded-full mt-1">
                              {conversation.unreadCount}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center">
                  <MessageCircle className="h-16 w-16 text-cyan-400 mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-semibold text-white mb-2">
                    Aucune conversation active
                  </h3>
                  <p className="text-slate-400 mb-6">
                    Pour commencer une conversation, visitez le profil d'un utilisateur depuis la communauté et cliquez sur "Envoyer un message"
                  </p>
                  <Button 
                    onClick={() => setLocation("/community")}
                    className="bg-cyan-600 hover:bg-cyan-700"
                  >
                    Aller à la communauté
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      <Header />
      
      <div className="flex-1 max-w-4xl mx-auto w-full flex flex-col">
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/community")}
              className="text-slate-400 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour
            </Button>
            <h1 className="text-xl font-semibold text-white">
              Conversation
            </h1>
          </div>
        </div>

        <Card className="flex-1 bg-slate-800 border-slate-700 rounded-none border-x-0 border-b-0">
          <CardContent className="p-0 h-full flex flex-col">
            {loadingMessages ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400 mx-auto mb-2"></div>
                  <p className="text-slate-400">Chargement des messages...</p>
                </div>
              </div>
            ) : (
              <div className="flex-1 p-4 space-y-2 overflow-y-auto bg-gradient-to-b from-slate-900/50 to-slate-800/30">
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center animate-fade-in">
                      <div className="relative mb-6">
                        <MessageCircle className="h-16 w-16 text-cyan-400 mx-auto opacity-60 animate-pulse" />
                        <div className="absolute inset-0 bg-cyan-400/20 blur-xl rounded-full"></div>
                      </div>
                      <p className="text-slate-300 text-lg font-medium">Aucun message dans cette conversation</p>
                      <p className="text-slate-500 text-sm mt-2">Commencez la discussion en envoyant le premier message !</p>
                    </div>
                  </div>
                ) : (
                  <>
                    {messages.map((message: any, index: number) => {
                      const isOwn = message.senderId === currentUser?.id;
                      const prevMessage = index > 0 ? messages[index - 1] : null;
                      const nextMessage = index < messages.length - 1 ? messages[index + 1] : null;
                      const isConsecutive = prevMessage && prevMessage.senderId === message.senderId;
                      const isLastInGroup = !nextMessage || nextMessage.senderId !== message.senderId;
                      
                      return (
                        <div
                          key={message.id}
                          className={`flex ${isOwn ? "justify-end" : "justify-start"} animate-message-appear ${
                            isConsecutive ? "mb-1" : "mb-3"
                          } ${isLastInGroup ? "mb-4" : ""}`}
                        >
                          <div className={`flex max-w-[80%] sm:max-w-[70%] md:max-w-[60%] ${isOwn ? "flex-row-reverse" : "flex-row"} items-end`}>
                            {/* Avatar */}
                            {!isConsecutive && (
                              <div className={`flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br shadow-lg transform transition-all duration-300 hover:scale-110 ${
                                isOwn 
                                  ? "from-cyan-400 via-cyan-500 to-cyan-600 ring-2 ring-cyan-400/30" 
                                  : "from-purple-400 via-purple-500 to-pink-500 ring-2 ring-purple-400/30"
                              } flex items-center justify-center text-white text-xs font-bold ${
                                isOwn ? "ml-3" : "mr-3"
                              }`}>
                                {isOwn ? currentUser?.username?.[0]?.toUpperCase() || "M" : "U"}
                              </div>
                            )}
                            
                            {/* Bulle de message */}
                            <div className={`relative group ${isConsecutive ? (isOwn ? "mr-12" : "ml-12") : ""}`}>
                              <div
                                className={`relative px-4 py-3 shadow-lg backdrop-blur-sm transition-all duration-300 hover:shadow-xl group-hover:scale-[1.02] ${
                                  isOwn
                                    ? "bg-gradient-to-br from-cyan-500 via-cyan-600 to-blue-600 text-white"
                                    : "bg-slate-700/90 text-slate-50 border border-slate-600/50 hover:border-slate-500/70"
                                } ${
                                  !isConsecutive && isLastInGroup
                                    ? isOwn
                                      ? "rounded-3xl rounded-br-lg"
                                      : "rounded-3xl rounded-bl-lg"
                                    : isConsecutive && isLastInGroup
                                    ? isOwn
                                      ? "rounded-3xl rounded-br-lg"
                                      : "rounded-3xl rounded-bl-lg"
                                    : isConsecutive
                                    ? "rounded-3xl"
                                    : "rounded-3xl"
                                }`}
                              >
                                {/* Queue de la bulle */}
                                {!isConsecutive && (
                                  <div
                                    className={`absolute w-3 h-3 transform rotate-45 transition-all duration-300 ${
                                      isOwn
                                        ? "bg-gradient-to-br from-cyan-500 to-blue-600 -right-1 bottom-2"
                                        : "bg-slate-700/90 border-r border-b border-slate-600/50 -left-1 bottom-2"
                                    }`}
                                  />
                                )}
                                
                                {/* Nom d'utilisateur */}
                                {!isConsecutive && (
                                  <div className={`text-xs font-semibold mb-1 ${
                                    isOwn ? "text-cyan-200" : "text-slate-300"
                                  }`}>
                                    {isOwn ? currentUser?.username || "Moi" : "Utilisateur"}
                                  </div>
                                )}
                                
                                <p className="text-sm leading-relaxed break-words whitespace-pre-wrap selection:bg-white/20">
                                  {message.content}
                                </p>
                                
                                <div className={`flex items-center justify-end mt-2 text-xs opacity-75 hover:opacity-100 transition-opacity ${
                                  isOwn ? "text-cyan-100" : "text-slate-400"
                                }`}>
                                  <span className="font-medium">
                                    {new Date(message.createdAt || message.sentAt).toLocaleTimeString('fr-FR', {
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    })}
                                  </span>
                                  {isOwn && (
                                    <div className="ml-2 flex space-x-1">
                                      <div className="w-1 h-1 rounded-full bg-cyan-200 animate-pulse"></div>
                                      <div className="w-1 h-1 rounded-full bg-cyan-200 animate-pulse delay-75"></div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} className="h-1" />
                  </>
                )}
              </div>
            )}

            <div className="p-4 border-t border-slate-700/50 bg-slate-800/50 backdrop-blur-sm">
              <div className="flex items-end gap-3 max-w-4xl">
                <div className="flex-1 relative">
                  <textarea
                    ref={textareaRef}
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Écrivez votre message..."
                    disabled={sendingMessage}
                    rows={1}
                    className="w-full resize-none bg-slate-700/80 border border-slate-600/60 text-white rounded-2xl px-4 py-3 pr-12 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 transition-all duration-200 max-h-32 overflow-y-auto backdrop-blur-sm"
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        sendMessage();
                      }
                    }}
                    style={{
                      height: 'auto',
                      minHeight: '48px'
                    }}
                    onInput={(e) => {
                      const target = e.target as HTMLTextAreaElement;
                      target.style.height = 'auto';
                      target.style.height = Math.min(target.scrollHeight, 128) + 'px';
                    }}
                  />
                  
                  {/* Bouton d'envoi intégré */}
                  <Button
                    onClick={sendMessage}
                    disabled={sendingMessage || !newMessage.trim()}
                    size="sm"
                    className="absolute right-2 bottom-2 h-8 w-8 p-0 bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 disabled:cursor-not-allowed rounded-full transition-all duration-200 shadow-lg hover:shadow-xl disabled:hover:bg-cyan-500"
                  >
                    {sendingMessage ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <svg 
                        className="w-4 h-4 text-white" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                      >
                        <path 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          strokeWidth={2} 
                          d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" 
                        />
                      </svg>
                    )}
                  </Button>
                </div>
                
                {/* Indicateur de frappe */}
                <div className="text-xs text-slate-500 hidden sm:block">
                  Entrée pour envoyer
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Footer />
    </div>
  );
}