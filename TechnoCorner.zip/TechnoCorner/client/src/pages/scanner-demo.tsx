import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Scan, Shield, CheckCircle, XCircle, Clock, AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ValidationResult {
  valid: boolean;
  validated?: boolean;
  message: string;
  alreadyUsed?: boolean;
  usedAt?: string;
  ticket?: any;
}

export default function ScannerDemo() {
  const [qrInput, setQrInput] = useState('');
  const [scannerId, setScannerId] = useState('DEMO-SCANNER-001');
  const [location, setLocation] = useState('Entrée principale');
  const [validationHistory, setValidationHistory] = useState<Array<{
    timestamp: string;
    qrData: string;
    result: ValidationResult;
    action: 'validate' | 'verify';
  }>>([]);
  const [isLoading, setIsLoading] = useState(false);

  const validateTicket = async () => {
    if (!qrInput.trim()) return;
    
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/validate-ticket", {
        qrData: qrInput,
        validatorId: scannerId,
        location: location
      });
      
      const result = await response.json();
      
      setValidationHistory(prev => [...prev, {
        timestamp: new Date().toLocaleString('fr-FR'),
        qrData: qrInput.substring(0, 50) + '...',
        result,
        action: 'validate'
      }]);
      
      setQrInput('');
    } catch (error) {
      console.error('Erreur validation:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const verifyTicket = async () => {
    if (!qrInput.trim()) return;
    
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/verify-ticket", {
        qrData: qrInput
      });
      
      const result = await response.json();
      
      setValidationHistory(prev => [...prev, {
        timestamp: new Date().toLocaleString('fr-FR'),
        qrData: qrInput.substring(0, 50) + '...',
        result,
        action: 'verify'
      }]);
      
      setQrInput('');
    } catch (error) {
      console.error('Erreur vérification:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadTestTicket = () => {
    setQrInput('{"ticketCode":"TECHNO-1749365069205-8K8RUWUBZ","eventId":26,"buyerName":"Demo User Interface"}');
  };

  const getStatusIcon = (result: ValidationResult, action: string) => {
    if (action === 'verify') {
      return result.valid ? 
        <CheckCircle className="h-4 w-4 text-green-500" /> : 
        <XCircle className="h-4 w-4 text-red-500" />;
    }
    
    if (result.validated) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    } else if (result.alreadyUsed) {
      return <AlertTriangle className="h-4 w-4 text-orange-500" />;
    } else {
      return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusColor = (result: ValidationResult, action: string) => {
    if (action === 'verify') {
      return result.valid ? 'bg-green-600' : 'bg-red-600';
    }
    
    if (result.validated) {
      return 'bg-green-600';
    } else if (result.alreadyUsed) {
      return 'bg-orange-600';
    } else {
      return 'bg-red-600';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-4">
            <Scan className="inline h-8 w-8 mr-3 text-purple-400" />
            Démo Scanner Anti-Fraude
          </h1>
          <p className="text-gray-400">
            Système de validation de billets pour organisateurs
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Interface de scan */}
          <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Shield className="h-5 w-5 text-green-400" />
                <span>Terminal de Validation</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="scannerId" className="text-gray-300">
                  Identifiant Scanner
                </Label>
                <Input
                  id="scannerId"
                  value={scannerId}
                  onChange={(e) => setScannerId(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="location" className="text-gray-300">
                  Emplacement
                </Label>
                <Input
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="qrInput" className="text-gray-300">
                  Données QR Code
                </Label>
                <textarea
                  id="qrInput"
                  value={qrInput}
                  onChange={(e) => setQrInput(e.target.value)}
                  placeholder='{"ticketCode":"TECHNO-XXX","eventId":1,"buyerName":"John Doe"}'
                  className="w-full h-20 bg-gray-700 border-gray-600 text-white rounded-md p-2 text-sm font-mono resize-none"
                />
              </div>

              <div className="flex space-x-2">
                <Button
                  onClick={loadTestTicket}
                  variant="outline"
                  className="flex-1 border-blue-600 text-blue-300"
                >
                  Charger Test
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={validateTicket}
                  disabled={isLoading || !qrInput.trim()}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  {isLoading ? (
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                  ) : (
                    <CheckCircle className="h-4 w-4 mr-2" />
                  )}
                  Valider Entrée
                </Button>

                <Button
                  onClick={verifyTicket}
                  disabled={isLoading || !qrInput.trim()}
                  variant="outline"
                  className="border-purple-600 text-purple-300"
                >
                  {isLoading ? (
                    <div className="animate-spin w-4 h-4 border-2 border-purple-400 border-t-transparent rounded-full mr-2" />
                  ) : (
                    <Scan className="h-4 w-4 mr-2" />
                  )}
                  Vérifier Seul.
                </Button>
              </div>

              <Alert className="border-blue-500/50 bg-blue-900/20">
                <Shield className="h-4 w-4" />
                <AlertDescription className="text-blue-200">
                  <strong>Validation:</strong> Marque le billet comme utilisé (validation d'entrée)<br/>
                  <strong>Vérification:</strong> Lecture seule, n'affecte pas le statut
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* Historique des validations */}
          <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Clock className="h-5 w-5 text-blue-400" />
                <span>Historique des Scans</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {validationHistory.length === 0 ? (
                <div className="text-center py-8">
                  <Scan className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Aucun scan effectué</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {validationHistory.slice().reverse().map((entry, index) => (
                    <div key={index} className="bg-gray-700/50 p-3 rounded-lg border border-gray-600">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(entry.result, entry.action)}
                          <Badge className={getStatusColor(entry.result, entry.action)}>
                            {entry.action === 'validate' ? 'VALIDATION' : 'VÉRIFICATION'}
                          </Badge>
                        </div>
                        <span className="text-xs text-gray-400">{entry.timestamp}</span>
                      </div>
                      
                      <div className="text-sm space-y-1">
                        <div className="text-gray-300">
                          <strong>Message:</strong> {entry.result.message}
                        </div>
                        <div className="text-gray-400 font-mono text-xs">
                          QR: {entry.qrData}
                        </div>
                        {entry.result.usedAt && (
                          <div className="text-orange-300 text-xs">
                            Utilisé le: {new Date(entry.result.usedAt).toLocaleString('fr-FR')}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Guide d'intégration rapide */}
        <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm mt-6">
          <CardHeader>
            <CardTitle className="text-white">Guide d'Intégration Rapide</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6 text-sm">
              <div>
                <h4 className="font-semibold text-white mb-3">API Endpoints</h4>
                <div className="space-y-2 font-mono text-xs">
                  <div className="bg-gray-900 p-2 rounded">
                    <div className="text-green-400">POST /api/validate-ticket</div>
                    <div className="text-gray-400">Valide et marque comme utilisé</div>
                  </div>
                  <div className="bg-gray-900 p-2 rounded">
                    <div className="text-blue-400">POST /api/verify-ticket</div>
                    <div className="text-gray-400">Vérification lecture seule</div>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-3">Codes de Réponse</h4>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-green-400">200 + validated:true</span>
                    <span className="text-gray-300">Accès autorisé</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-orange-400">400 + alreadyUsed:true</span>
                    <span className="text-gray-300">Fraude détectée</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-400">404</span>
                    <span className="text-gray-300">Billet invalide</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}