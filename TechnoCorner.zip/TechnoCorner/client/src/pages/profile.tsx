import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useRoute } from "wouter";
import { ArrowLeft, Edit, Save, X, User as UserIcon, Heart, MessageCircle, Share2, Trash2, ChevronDown, Send, Mail, UserPlus, UserMinus, Users, Camera, Upload, Image } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { type User as UserType } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";

export default function Profile() {
  const [match, params] = useRoute("/profile/:id?");
  const profileUserId = params?.id ? parseInt(params.id) : null;
  const [isEditing, setIsEditing] = useState(false);
  const [expandedPost, setExpandedPost] = useState<number | null>(null);
  const [newComment, setNewComment] = useState("");
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const { toast } = useToast();

  // Get current authenticated user
  const { data: currentUser } = useQuery<UserType>({
    queryKey: ["/api/auth/current"],
    queryFn: async () => {
      const response = await fetch('/api/auth/current', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
        credentials: 'include'
      });
      
      if (!response.ok) {
        return null;
      }
      
      return response.json();
    },
    staleTime: 0,
    gcTime: 0,
  });

  // Get follow status and counts for the profile user
  const { data: followStatus } = useQuery({
    queryKey: ["/api/users", profileUserId || currentUser?.id, "follow-status"],
    queryFn: async () => {
      const userId = profileUserId || currentUser?.id;
      if (!userId) return null;
      
      const response = await fetch(`/api/users/${userId}/follow-status`);
      if (!response.ok) return null;
      return response.json();
    },
    enabled: !!(profileUserId || currentUser?.id),
  });

  // Get profile user (either current user or public profile)
  const { data: user, isLoading, error } = useQuery<UserType>({
    queryKey: ["/api/user", profileUserId || currentUser?.id],
    queryFn: async () => {
      const userId = profileUserId || currentUser?.id;
      if (!userId) return null;
      
      const response = await fetch(`/api/user/${userId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`Utilisateur non trouvé`);
      }
      
      return response.json();
    },
    enabled: !!(profileUserId || currentUser?.id),
  });

  const isOwnProfile = currentUser && user && currentUser.id === user.id;

  // Query pour récupérer les posts de l'utilisateur
  const { data: userPosts, isLoading: postsLoading } = useQuery({
    queryKey: ["/api/posts/user", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      console.log("🚀 Fetching user posts for ID:", user.id);
      const response = await apiRequest("GET", `/api/posts/user/${user.id}`);
      console.log("📦 Raw response object:", response);
      
      // Extract JSON data from the Response object
      const data = await response.json();
      console.log("📦 Parsed JSON data:", data);
      console.log("📦 Data type:", typeof data);
      console.log("📦 Is array:", Array.isArray(data));
      console.log("📦 Data length:", data?.length);
      
      const result = Array.isArray(data) ? data : [];
      console.log("✅ Final result:", result);
      return result;
    },
    enabled: !!user?.id,
  });

  // Query pour récupérer les commentaires d'un post spécifique
  const { data: postComments } = useQuery({
    queryKey: ["/api/posts", expandedPost, "comments"],
    queryFn: async () => {
      if (!expandedPost) return [];
      const response = await apiRequest("GET", `/api/posts/${expandedPost}/comments`);
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
    enabled: !!expandedPost,
  });

  // Mutation pour supprimer un post
  const deletePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      console.log("Début de la suppression du post:", postId);
      try {
        const response = await apiRequest("DELETE", `/api/posts/${postId}`);
        console.log("Réponse suppression:", response.status, response.statusText);
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error("Erreur response:", errorText);
          throw new Error(`Erreur ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        console.log("Post supprimé avec succès:", result);
        return result;
      } catch (error) {
        console.error("Erreur dans mutationFn:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log("onSuccess appelé avec:", data);
      queryClient.invalidateQueries({ queryKey: ["/api/posts/user", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Post supprimé !",
        description: "Votre post a été supprimé avec succès.",
      });
    },
    onError: (error) => {
      console.error("onError appelé avec:", error);
      toast({
        title: "Erreur",
        description: `Impossible de supprimer le post: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Mutation pour ajouter un commentaire
  const addCommentMutation = useMutation({
    mutationFn: async ({ postId, content }: { postId: number; content: string }) => {
      const response = await apiRequest("POST", `/api/posts/${postId}/comments`, { content });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts", expandedPost, "comments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/user", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setNewComment("");
      toast({
        title: "Commentaire ajouté !",
        description: "Votre commentaire a été ajouté avec succès.",
      });
    },
  });

  // Mutation pour supprimer un commentaire
  const deleteCommentMutation = useMutation({
    mutationFn: async (commentId: number) => {
      const response = await apiRequest("DELETE", `/api/comments/${commentId}`);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts", expandedPost, "comments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/user", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Commentaire supprimé !",
        description: "Le commentaire a été supprimé avec succès.",
      });
    },
  });

  // Mutation pour suivre un utilisateur
  const followMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest("POST", `/api/users/${userId}/follow`);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", profileUserId || currentUser?.id, "follow-status"] });
      toast({
        title: "Utilisateur suivi !",
        description: "Vous suivez maintenant cet utilisateur.",
      });
    },
  });

  // Mutation pour ne plus suivre un utilisateur
  const unfollowMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest("DELETE", `/api/users/${userId}/follow`);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", profileUserId || currentUser?.id, "follow-status"] });
      toast({
        title: "Utilisateur non suivi !",
        description: "Vous ne suivez plus cet utilisateur.",
      });
    },
  });

  // Simple state for form fields
  const [formData, setFormData] = useState({
    email: "",
    firstName: "",
    lastName: "",
    bio: "",
    city: "",
    country: "",
    website: "",
    profileImageUrl: "",
  });

  // Reset form when user data loads
  useEffect(() => {
    if (user) {
      setFormData({
        email: user.email || "",
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        bio: user.bio || "",
        city: user.city || "",
        country: user.country || "",
        website: user.website || "",
        profileImageUrl: user.profileImageUrl || "",
      });
      // Reset image preview when user data changes
      setImagePreview(null);
    }
  }, [user]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      if (!user?.id) throw new Error('Utilisateur non connecté');
      
      console.log('🚀 Sending data to server:', data);
      console.log('🌐 URL:', `/api/user/${user.id}`);
      
      const response = await fetch(`/api/user/${user.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      console.log('📡 Response status:', response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Server error:', errorText);
        throw new Error(`Erreur ${response.status}: ${errorText}`);
      }
      
      const result = await response.json();
      console.log('✅ Success response:', result);
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/current"] });
      setIsEditing(false);
      toast({
        title: "Profil mis à jour",
        description: "Vos informations ont été sauvegardées avec succès.",
      });
    },
    onError: (error) => {
      console.error('💥 Mutation error:', error);
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour le profil.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async () => {
    if (!currentUser?.id) {
      toast({
        title: "Erreur",
        description: "Vous devez être connecté pour modifier votre profil",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch(`/api/user/${currentUser.id}`, {
        method: "PUT",
        headers: { 
          "Content-Type": "application/json",
          "Cache-Control": "no-cache"
        },
        credentials: 'include',
        body: JSON.stringify(formData),
      });
      
      if (response.ok) {
        const result = await response.json();
        queryClient.invalidateQueries({ queryKey: ["/api/auth/current"] });
        queryClient.invalidateQueries({ queryKey: ["/api/user", currentUser.id] });
        setIsEditing(false);
        setImagePreview(null);
        toast({
          title: "Profil mis à jour",
          description: "Vos informations ont été sauvegardées avec succès.",
        });
      } else {
        const errorData = await response.json();
        toast({
          title: "Erreur",
          description: errorData.message || "Impossible de mettre à jour le profil",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      toast({
        title: "Erreur",
        description: "Erreur de connexion",
        variant: "destructive",
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Handle image file upload
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Fichier invalide",
        description: "Veuillez sélectionner une image (JPG, PNG, GIF, etc.)",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Fichier trop volumineux",
        description: "L'image ne peut pas dépasser 5MB",
        variant: "destructive",
      });
      return;
    }

    setUploadingImage(true);
    
    try {
      // Convert to base64 for preview and storage
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64String = e.target?.result as string;
        setImagePreview(base64String);
        setFormData(prev => ({
          ...prev,
          profileImageUrl: base64String
        }));
        setUploadingImage(false);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading image:', error);
      setUploadingImage(false);
      toast({
        title: "Erreur",
        description: "Impossible de charger l'image",
        variant: "destructive",
      });
    }
  };

  // Remove profile image
  const removeImage = () => {
    setImagePreview(null);
    setFormData(prev => ({
      ...prev,
      profileImageUrl: ""
    }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-cyan-400 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user || !user.id) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-center max-w-md mx-auto">
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-lg p-8">
            <UserIcon className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-4">
              {profileUserId ? "Utilisateur non trouvé" : "Connexion requise"}
            </h2>
            <p className="text-slate-300 mb-6">
              {profileUserId 
                ? "Ce profil n'existe pas ou n'est pas accessible."
                : "Vous devez être connecté pour accéder à votre profil."
              }
            </p>
            <div className="flex gap-3 justify-center">
              {!profileUserId && (
                <Link href="/login">
                  <Button className="bg-gradient-to-r from-primary to-secondary">
                    Se connecter
                  </Button>
                </Link>
              )}
              <Link href="/">
                <Button variant="outline">
                  Retour à l'accueil
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header avec navigation */}
          <div className="flex items-center gap-4 mb-8">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-white">Profil utilisateur</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Colonne de gauche - Photo et infos de base */}
            <div className="lg:col-span-1">
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700 hover:border-slate-600/50 transition-all duration-300">
                <CardContent className="p-6 text-center">
                  <div className="relative inline-block mb-6">
                    {user.profileImageUrl ? (
                      <img
                        src={user.profileImageUrl}
                        alt="Photo de profil"
                        className="w-32 h-32 rounded-full object-cover border-4 border-cyan-400/30 shadow-xl"
                      />
                    ) : (
                      <div className="w-32 h-32 rounded-full bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center border-4 border-cyan-400/30 shadow-xl">
                        <UserIcon className="w-16 h-16 text-white" />
                      </div>
                    )}
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full border-4 border-slate-800 flex items-center justify-center">
                      <div className="w-3 h-3 bg-white rounded-full"></div>
                    </div>
                  </div>
                  
                  <h2 className="text-2xl font-bold text-white mb-2">
                    @{user.username}
                  </h2>
                  
                  {user.firstName || user.lastName ? (
                    <p className="text-slate-300 text-lg mb-4">
                      {user.firstName} {user.lastName}
                    </p>
                  ) : null}

                  {/* Compteurs d'abonnés/abonnements */}
                  <div className="flex justify-center gap-6 mb-4">
                    <div className="text-center">
                      <div className="text-xl font-bold text-white">
                        {followStatus?.followersCount || 0}
                      </div>
                      <div className="text-xs text-slate-400 uppercase tracking-wide">
                        Abonnés
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-bold text-white">
                        {followStatus?.followingCount || 0}
                      </div>
                      <div className="text-xs text-slate-400 uppercase tracking-wide">
                        Abonnements
                      </div>
                    </div>
                  </div>

                  {/* Bouton Follow/Unfollow (seulement si ce n'est pas le profil de l'utilisateur connecté) */}
                  {profileUserId && currentUser && profileUserId !== currentUser.id && (
                    <div className="mb-4">
                      {followStatus?.isFollowing ? (
                        <Button
                          onClick={() => unfollowMutation.mutate(profileUserId)}
                          disabled={unfollowMutation.isPending}
                          variant="outline"
                          className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10"
                        >
                          <UserMinus className="w-4 h-4 mr-2" />
                          {unfollowMutation.isPending ? "..." : "Ne plus suivre"}
                        </Button>
                      ) : (
                        <Button
                          onClick={() => followMutation.mutate(profileUserId)}
                          disabled={followMutation.isPending}
                          className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
                        >
                          <UserPlus className="w-4 h-4 mr-2" />
                          {followMutation.isPending ? "..." : "Suivre"}
                        </Button>
                      )}
                    </div>
                  )}
                  
                  <div className="space-y-2 mb-4">
                    {user.city && (
                      <p className="text-slate-400 text-sm flex items-center justify-center">
                        <span className="w-2 h-2 bg-cyan-400 rounded-full mr-2"></span>
                        {user.city}{user.country && `, ${user.country}`}
                      </p>
                    )}
                    
                    {user.website && (
                      <a 
                        href={user.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-cyan-400 hover:text-cyan-300 text-sm inline-flex items-center transition-colors"
                      >
                        <span className="w-2 h-2 bg-purple-400 rounded-full mr-2"></span>
                        {user.website}
                      </a>
                    )}
                  </div>

                  {/* Boutons d'action pour tous les utilisateurs connectés */}
                  {currentUser && profileUserId && (
                    <div className="mt-6 pt-4 border-t border-slate-700 space-y-3">
                      {/* Bouton pour envoyer un message */}
                      <Button 
                        onClick={() => {
                          window.location.href = `/conversation/${profileUserId}`;
                        }}
                        className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Envoyer un message
                      </Button>
                      
                      {/* Bouton pour poster sur le canal publique (seulement pour les autres profils) */}
                      {currentUser.id !== parseInt(profileUserId.toString()) && (
                        <Button 
                          onClick={() => {
                            // Rediriger vers la page de conversation avec l'ID de l'utilisateur
                            window.location.href = `/conversation/${profileUserId}`;
                          }}
                          className="w-full bg-cyan-600 hover:bg-cyan-700 text-white"
                        >
                          <Mail className="w-4 h-4 mr-2" />
                          Poster sur le canal publique
                        </Button>
                      )}
                    </div>
                  )}

                  {/* Statistiques utilisateur */}
                  <div className="grid grid-cols-1 gap-3 mt-6 pt-4 border-t border-slate-700">
                    <div className="text-center">
                      <div className="text-xl font-bold text-white">{Array.isArray(userPosts) ? userPosts.length : 0}</div>
                      <div className="text-xs text-slate-400">Posts publiés</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Colonne de droite - Informations détaillées */}
            <div className="lg:col-span-2">
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardHeader className="border-b border-slate-700">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-white text-xl">
                      Informations personnelles
                    </CardTitle>
                    <Button
                      onClick={() => setIsEditing(!isEditing)}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 text-slate-300 hover:text-white"
                    >
                      {isEditing ? (
                        <>
                          <X className="w-4 h-4 mr-2" />
                          Annuler
                        </>
                      ) : (
                        <>
                          <Edit className="w-4 h-4 mr-2" />
                          Modifier
                        </>
                      )}
                    </Button>
                  </div>
                </CardHeader>

                <CardContent className="p-6">
                  {isEditing ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-slate-300 text-sm font-medium mb-2 block">Prénom</label>
                          <Input
                            placeholder="Votre prénom"
                            className="bg-slate-700/50 border-slate-600 text-white"
                            value={formData.firstName}
                            onChange={(e) => handleInputChange('firstName', e.target.value)}
                          />
                        </div>

                        <div>
                          <label className="text-slate-300 text-sm font-medium mb-2 block">Nom</label>
                          <Input
                            placeholder="Votre nom"
                            className="bg-slate-700/50 border-slate-600 text-white"
                            value={formData.lastName}
                            onChange={(e) => handleInputChange('lastName', e.target.value)}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-slate-300 text-sm font-medium mb-2 block">Email</label>
                        <Input
                          type="email"
                          placeholder="votre@email.com"
                          className="bg-slate-700/50 border-slate-600 text-white"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                        />
                      </div>

                      {/* Photo de profil avec upload */}
                      <div className="space-y-4">
                        <label className="text-slate-300 text-sm font-medium mb-2 block">Photo de profil</label>
                        
                        {/* Image preview */}
                        <div className="flex items-center space-x-4">
                          <div className="relative">
                            <Avatar className="w-20 h-20">
                              <AvatarImage 
                                src={(imagePreview || formData.profileImageUrl || user.profileImageUrl) || undefined} 
                                alt="Aperçu photo de profil" 
                              />
                              <AvatarFallback className="bg-gradient-to-r from-primary to-secondary text-white text-lg">
                                {user.username?.[0]?.toUpperCase() || <UserIcon className="w-8 h-8" />}
                              </AvatarFallback>
                            </Avatar>
                            {(imagePreview || formData.profileImageUrl) && (
                              <Button
                                type="button"
                                variant="destructive"
                                size="sm"
                                className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0"
                                onClick={removeImage}
                              >
                                <X className="w-3 h-3" />
                              </Button>
                            )}
                          </div>
                          
                          <div className="flex flex-col space-y-2">
                            <label className="cursor-pointer">
                              <input
                                type="file"
                                accept="image/*"
                                onChange={handleImageUpload}
                                className="hidden"
                                disabled={uploadingImage}
                              />
                              <Button
                                type="button"
                                variant="outline"
                                className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50"
                                disabled={uploadingImage}
                                asChild
                              >
                                <span>
                                  {uploadingImage ? (
                                    <>
                                      <Upload className="w-4 h-4 mr-2 animate-spin" />
                                      Upload...
                                    </>
                                  ) : (
                                    <>
                                      <Camera className="w-4 h-4 mr-2" />
                                      Choisir une image
                                    </>
                                  )}
                                </span>
                              </Button>
                            </label>
                            <p className="text-xs text-slate-400">
                              JPG, PNG, GIF jusqu'à 5MB
                            </p>
                          </div>
                        </div>

                        {/* URL alternative */}
                        <div>
                          <label className="text-slate-300 text-xs font-medium mb-1 block">Ou URL d'image</label>
                          <Input
                            placeholder="https://exemple.com/photo.jpg"
                            className="bg-slate-700/50 border-slate-600 text-white text-sm"
                            value={formData.profileImageUrl}
                            onChange={(e) => {
                              handleInputChange('profileImageUrl', e.target.value);
                              setImagePreview(null); // Clear preview when typing URL
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-slate-300 text-sm font-medium mb-2 block">Bio</label>
                        <Textarea
                          placeholder="Parlez-nous de vous..."
                          className="bg-slate-700/50 border-slate-600 text-white"
                          value={formData.bio}
                          onChange={(e) => handleInputChange('bio', e.target.value)}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-slate-300 text-sm font-medium mb-2 block">Ville</label>
                          <Input
                            placeholder="Paris"
                            className="bg-slate-700/50 border-slate-600 text-white"
                            value={formData.city}
                            onChange={(e) => handleInputChange('city', e.target.value)}
                          />
                        </div>

                        <div>
                          <label className="text-slate-300 text-sm font-medium mb-2 block">Pays</label>
                          <Input
                            placeholder="France"
                            className="bg-slate-700/50 border-slate-600 text-white"
                            value={formData.country}
                            onChange={(e) => handleInputChange('country', e.target.value)}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-slate-300 text-sm font-medium mb-2 block">Site web</label>
                        <Input
                          placeholder="https://monsite.com"
                          className="bg-slate-700/50 border-slate-600 text-white"
                          value={formData.website}
                          onChange={(e) => handleInputChange('website', e.target.value)}
                        />
                      </div>

                      <div className="flex gap-3 pt-4">
                        <Button
                          onClick={handleSubmit}
                          disabled={updateProfileMutation.isPending}
                          className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700"
                        >
                          <Save className="w-4 h-4 mr-2" />
                          {updateProfileMutation.isPending ? "Sauvegarde..." : "Sauvegarder"}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {user.bio && (
                        <div>
                          <h3 className="text-slate-300 text-sm font-medium mb-2">Bio</h3>
                          <p className="text-white whitespace-pre-wrap">{user.bio}</p>
                        </div>
                      )}
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {user.email && (
                          <div>
                            <h3 className="text-slate-300 text-sm font-medium mb-2">Email</h3>
                            <p className="text-white">{user.email}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Section Mes Posts */}
          <div className="mt-8">
            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700 hover:border-slate-600/50 transition-all duration-300">
              <CardHeader className="bg-gradient-to-r from-slate-800/60 to-slate-700/60">
                <CardTitle className="text-white text-xl flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full mr-3"></div>
                    Mes Posts
                    <span className="ml-3 px-2 py-1 bg-cyan-500/20 text-cyan-300 text-sm rounded-full">
                      {Array.isArray(userPosts) ? userPosts.length : 0}
                    </span>
                  </div>
                  <Link href="/community">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="border-cyan-500/30 text-cyan-300 hover:text-white hover:border-cyan-400 hover:bg-cyan-500/10 transition-all duration-300"
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Nouveau post
                    </Button>
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {postsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="flex items-center space-x-3 mb-4">
                          <div className="w-10 h-10 bg-slate-700 rounded-full"></div>
                          <div className="space-y-2">
                            <div className="h-4 bg-slate-700 rounded w-24"></div>
                            <div className="h-3 bg-slate-700 rounded w-16"></div>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="h-4 bg-slate-700 rounded"></div>
                          <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : !userPosts || (Array.isArray(userPosts) && userPosts.length === 0) ? (
                  <div className="text-center py-16">
                    <div className="relative">
                      <div className="w-24 h-24 bg-gradient-to-br from-cyan-400/20 to-purple-500/20 rounded-full mx-auto mb-6 flex items-center justify-center">
                        <MessageCircle className="w-12 h-12 text-slate-500" />
                      </div>
                      <div className="absolute top-2 right-1/2 translate-x-8 w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
                      <div className="absolute bottom-4 left-1/2 -translate-x-6 w-2 h-2 bg-purple-400 rounded-full animate-pulse delay-300"></div>
                    </div>
                    <h3 className="text-xl font-semibold text-slate-300 mb-3">Votre espace créatif vous attend !</h3>
                    <p className="text-slate-400 mb-8 max-w-md mx-auto leading-relaxed">
                      Partagez vos moments techno, vos découvertes musicales et connectez-vous avec la communauté électro !
                    </p>
                    <Link href="/community">
                      <Button className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-300 shadow-lg">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Créer mon premier post
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array.isArray(userPosts) && userPosts.map((post: any) => (
                      <div key={post.id} className="bg-slate-700/40 rounded-xl overflow-hidden border border-slate-600/50 hover:border-cyan-400/30 hover:shadow-lg hover:shadow-cyan-500/10 transition-all duration-300 transform hover:-translate-y-1">
                        {/* Header du post */}
                        <div className="p-4 pb-2 bg-gradient-to-r from-slate-800/30 to-slate-700/30">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <div className="relative">
                                <Avatar className="w-9 h-9 ring-2 ring-cyan-400/20">
                                  <AvatarImage src={user.profileImageUrl || undefined} />
                                  <AvatarFallback className="bg-gradient-to-br from-cyan-500 to-purple-600 text-white text-xs font-semibold">
                                    {user.username?.[0]?.toUpperCase() || "U"}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-slate-800"></div>
                              </div>
                              <div>
                                <p className="font-semibold text-white text-sm">@{user.username}</p>
                                <p className="text-xs text-slate-400 flex items-center">
                                  <span className="w-1 h-1 bg-cyan-400 rounded-full mr-2"></span>
                                  {new Date(post.createdAt).toLocaleDateString('fr-FR', {
                                    day: 'numeric',
                                    month: 'short',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })}
                                </p>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                console.log("Tentative de suppression du post:", post.id);
                                if (window.confirm("Êtes-vous sûr de vouloir supprimer ce post ?")) {
                                  deletePostMutation.mutate(post.id);
                                }
                              }}
                              disabled={deletePostMutation.isPending}
                              className="text-red-400 hover:text-red-300 hover:bg-red-500/20 p-2 h-auto rounded-lg transition-all duration-300"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>

                        {/* Contenu du post - cliquable */}
                        <div 
                          className="px-4 pb-3 cursor-pointer"
                          onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
                        >
                          {post.content && (
                            <p className="text-white text-sm leading-relaxed whitespace-pre-wrap mb-3 line-clamp-3">{post.content}</p>
                          )}
                          {post.imageUrl && (
                            <div className="relative">
                              {post.type === 'video' ? (
                                <video 
                                  src={post.imageUrl} 
                                  controls
                                  className="w-full h-48 object-contain bg-black rounded-lg"
                                  style={{ maxHeight: '200px' }}
                                >
                                  Votre navigateur ne supporte pas la lecture vidéo.
                                </video>
                              ) : (
                                <img 
                                  src={post.imageUrl} 
                                  alt="Post image" 
                                  className="w-full h-40 object-cover rounded-lg"
                                />
                              )}
                            </div>
                          )}
                        </div>

                        {/* Footer du post */}
                        <div className="px-4 py-3 bg-slate-800/50 border-t border-slate-600/30">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <div className="flex items-center text-slate-400 hover:text-red-400 transition-colors p-1 rounded">
                                <Heart className="w-4 h-4 mr-2" />
                                <span className="text-sm font-medium">{post.likesCount || 0}</span>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
                                className="flex items-center text-slate-400 hover:text-cyan-400 p-2 h-auto rounded-lg bg-slate-700/30 hover:bg-cyan-500/10 transition-all duration-300"
                              >
                                <MessageCircle className="w-4 h-4 mr-2" />
                                <span className="text-sm font-medium">{post.commentsCount || 0}</span>
                                <ChevronDown className={`w-4 h-4 ml-2 transition-transform duration-300 ${expandedPost === post.id ? 'rotate-180 text-cyan-400' : ''}`} />
                              </Button>
                            </div>
                            <Link href="/community">
                              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-purple-400 p-2 h-auto rounded-lg bg-slate-700/30 hover:bg-purple-500/10 transition-all duration-300">
                                <Share2 className="w-4 h-4" />
                              </Button>
                            </Link>
                          </div>
                        </div>

                        {/* Section commentaires expandable */}
                        {expandedPost === post.id && (
                          <div className="px-4 pb-4 bg-slate-800/20 border-t border-slate-600/30">
                            <div className="space-y-3 mb-4">
                              {postComments && postComments.length > 0 ? (
                                postComments.map((comment: any) => (
                                  <div key={comment.id} className="flex space-x-2 group">
                                    <Avatar className="w-6 h-6 ring-1 ring-purple-400/20">
                                      <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-600 text-white text-xs font-semibold">
                                        {comment.author?.username?.[0]?.toUpperCase() || "U"}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1">
                                      <div className="bg-slate-700/50 rounded-lg p-2 hover:bg-slate-700/70 transition-colors">
                                        <div className="flex items-center justify-between mb-1">
                                          <p className="font-semibold text-white text-xs">@{comment.author?.username || 'Utilisateur'}</p>
                                          {/* Bouton supprimer - visible uniquement pour l'auteur du commentaire */}
                                          {user && comment.author?.id === user.id && (
                                            <Button
                                              variant="ghost"
                                              size="sm"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                console.log("Tentative de suppression du commentaire:", comment.id);
                                                if (window.confirm("Êtes-vous sûr de vouloir supprimer ce commentaire ?")) {
                                                  deleteCommentMutation.mutate(comment.id);
                                                }
                                              }}
                                              disabled={deleteCommentMutation.isPending}
                                              className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-300 hover:bg-red-500/20 p-1 h-auto w-auto transition-all duration-300"
                                            >
                                              <Trash2 className="w-2.5 h-2.5" />
                                            </Button>
                                          )}
                                        </div>
                                        <p className="text-slate-300 text-xs leading-relaxed">{comment.content}</p>
                                      </div>
                                      <p className="text-xs text-slate-500 mt-1 flex items-center">
                                        <span className="w-1 h-1 bg-purple-400 rounded-full mr-1"></span>
                                        {comment.createdAt ? new Date(comment.createdAt).toLocaleDateString('fr-FR', {
                                          day: 'numeric',
                                          month: 'short',
                                          hour: '2-digit',
                                          minute: '2-digit'
                                        }) : 'Il y a quelques instants'}
                                      </p>
                                    </div>
                                  </div>
                                ))
                              ) : (
                                <div className="text-center py-4">
                                  <MessageCircle className="w-6 h-6 text-slate-500 mx-auto mb-2" />
                                  <p className="text-slate-500 text-xs">Aucun commentaire encore.</p>
                                  <p className="text-slate-600 text-xs mt-1">Soyez le premier à commenter !</p>
                                </div>
                              )}
                            </div>

                            {/* Formulaire d'ajout de commentaire */}
                            <div className="flex space-x-2">
                              <Input
                                placeholder="Ajouter un commentaire..."
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                                className="flex-1 bg-slate-700/50 border-slate-600 text-white text-xs"
                                onKeyPress={(e) => {
                                  if (e.key === 'Enter' && newComment.trim()) {
                                    addCommentMutation.mutate({ postId: post.id, content: newComment.trim() });
                                  }
                                }}
                              />
                              <Button
                                size="sm"
                                onClick={() => {
                                  if (newComment.trim()) {
                                    addCommentMutation.mutate({ postId: post.id, content: newComment.trim() });
                                  }
                                }}
                                disabled={!newComment.trim() || addCommentMutation.isPending}
                                className="bg-cyan-600 hover:bg-cyan-700 p-2 h-auto"
                              >
                                <Send className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}