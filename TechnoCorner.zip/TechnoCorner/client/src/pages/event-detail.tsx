import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Calendar, MapPin, Headphones, Mail, Phone, User, ArrowLeft, Share2, Heart, Ticket, ShoppingCart, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Event, User as UserType } from "@shared/schema";

const categoryColors = {
  underground: "bg-accent text-white",
  festival: "bg-secondary text-white", 
  club: "bg-primary text-white",
  workshop: "bg-secondary text-white",
  outdoor: "bg-accent text-white"
};

const categoryLabels = {
  underground: "UNDERGROUND",
  festival: "FESTIVAL",
  club: "CLUB", 
  workshop: "WORKSHOP",
  outdoor: "OUTDOOR"
};

export default function EventDetail() {
  const [match, params] = useRoute("/event/:id");
  const [, setLocation] = useLocation();
  const eventId = params?.id ? parseInt(params.id) : null;
  const { toast } = useToast();

  const { data: event, isLoading, error } = useQuery<Event>({
    queryKey: ["/api/events", eventId],
    queryFn: () => fetch(`/api/events/${eventId}`).then(res => {
      if (!res.ok) throw new Error("Event not found");
      return res.json();
    }),
    enabled: !!eventId,
  });

  // Get current user to check if they can delete the event
  const { data: currentUser } = useQuery<UserType>({
    queryKey: ["/api/auth/current"],
    queryFn: () => fetch("/api/auth/current").then(res => {
      if (!res.ok) return null;
      return res.json();
    }),
  });

  // Delete event mutation
  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: number) => {
      const response = await apiRequest("DELETE", `/api/events/${eventId}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la suppression");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Événement supprimé",
        description: "L'événement a été supprimé avec succès.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      setLocation("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const canDeleteEvent = currentUser && event && currentUser.email === event.organizerEmail;

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="animate-pulse">
              <div className="h-64 bg-slate-800 rounded-2xl mb-8"></div>
              <div className="h-8 bg-slate-800 rounded w-3/4 mb-4"></div>
              <div className="h-4 bg-slate-800 rounded w-1/2 mb-8"></div>
              <div className="space-y-4">
                <div className="h-4 bg-slate-800 rounded"></div>
                <div className="h-4 bg-slate-800 rounded"></div>
                <div className="h-4 bg-slate-800 rounded w-3/4"></div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !event) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-2xl font-bold text-white mb-4">Événement non trouvé</h1>
            <p className="text-slate-400 mb-8">L'événement que vous cherchez n'existe pas ou a été supprimé.</p>
            <Link href="/">
              <Button className="bg-gradient-to-r from-primary to-secondary neon-glow">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour aux événements
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <Link href="/">
            <Button variant="ghost" className="mb-6 text-slate-300 hover:text-primary">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour aux événements
            </Button>
          </Link>

          {/* Event Header */}
          <div className="relative mb-8">
            <div className="h-64 md:h-80 rounded-2xl overflow-hidden relative">
              <img 
                src={event.imageUrl || "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600"} 
                alt={event.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              <div className="absolute top-6 left-6">
                <Badge className={categoryColors[event.category as keyof typeof categoryColors]}>
                  {categoryLabels[event.category as keyof typeof categoryLabels]}
                </Badge>
              </div>
              <div className="absolute top-6 right-6 flex gap-2">
                <Button size="icon" variant="ghost" className="bg-black/50 backdrop-blur-sm text-white hover:bg-black/70">
                  <Heart className="w-4 h-4" />
                </Button>
                <Button size="icon" variant="ghost" className="bg-black/50 backdrop-blur-sm text-white hover:bg-black/70">
                  <Share2 className="w-4 h-4" />
                </Button>
                {canDeleteEvent && (
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    className="bg-red-500/50 backdrop-blur-sm text-white hover:bg-red-600/70"
                    onClick={() => {
                      if (window.confirm("Êtes-vous sûr de vouloir supprimer cet événement ? Cette action est irréversible.")) {
                        deleteEventMutation.mutate(event.id);
                      }
                    }}
                    disabled={deleteEventMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">{event.title}</h1>
                <div className="flex flex-wrap gap-4 text-slate-300 mb-6">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-primary" />
                    <span>{new Date(event.date).toLocaleDateString('fr-FR', { 
                      weekday: 'long',
                      day: 'numeric', 
                      month: 'long', 
                      year: 'numeric' 
                    })}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" />
                    <span>{event.venue}, {event.location}</span>
                  </div>
                </div>
              </div>

              <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-white mb-4">Description</h2>
                  <p className="text-slate-300 leading-relaxed">{event.description}</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 backdrop-blur-sm border-secondary/20">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                    <Headphones className="w-5 h-5 text-secondary" />
                    Line-up
                  </h2>
                  <div className="flex flex-wrap gap-2">
                    {event.djs.map((dj, index) => (
                      <Badge key={index} variant="outline" className="border-secondary/50 text-secondary">
                        {dj}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Price & Action */}
              <Card className="bg-slate-900/50 backdrop-blur-sm border-accent/20">
                <CardContent className="p-6 text-center">
                  {(() => {
                    // Nettoyer le prix et vérifier s'il est à 0
                    const cleanPrice = event.price?.toString().replace(/[^\d.,]/g, '') || '0';
                    const numericPrice = parseFloat(cleanPrice.replace(',', '.'));
                    const isFree = numericPrice === 0;
                    
                    return (
                      <div>
                        <div className="text-3xl font-bold text-accent mb-4">
                          {event.enableTicketing === "false" || isFree ? "Gratuit" : event.price}
                        </div>
                        
                        {/* Billetterie activée */}
                        {event.enableTicketing === "true" ? (
                          <div className="space-y-3">
                            {/* Affichage du stock de billets */}
                            {event.ticketsAvailable && (
                              <div className="text-sm text-slate-400">
                                {(event.ticketsAvailable - (event.ticketsSold || 0))} billets restants sur {event.ticketsAvailable}
                              </div>
                            )}
                            
                            {/* Bouton d'achat ou complet */}
                            {event.ticketsAvailable && (event.ticketsSold || 0) >= event.ticketsAvailable ? (
                              <Button disabled className="w-full bg-slate-600 text-slate-400 mb-4">
                                <Ticket className="w-4 h-4 mr-2" />
                                Événement complet
                              </Button>
                            ) : (
                              <Button 
                                onClick={() => {
                                  setLocation(`/checkout?eventId=${event.id}`);
                                }}
                                className={`w-full hover:scale-105 transition-all duration-300 neon-glow mb-4 ${
                                  isFree 
                                    ? "bg-gradient-to-r from-green-500 to-green-600"
                                    : "bg-gradient-to-r from-primary to-secondary"
                                }`}
                              >
                                {isFree ? (
                                  <>
                                    <Ticket className="w-4 h-4 mr-2" />
                                    Réserver gratuitement
                                  </>
                                ) : (
                                  <>
                                    <ShoppingCart className="w-4 h-4 mr-2" />
                                    Acheter un billet
                                  </>
                                )}
                              </Button>
                            )}
                            
                            <p className="text-xs text-slate-400">
                              {isFree 
                                ? "Réservation gratuite avec QR code d'entrée" 
                                : "Paiement sécurisé via Stripe"
                              }
                            </p>
                          </div>
                        ) : (
                          /* Billetterie non activée - redirection vers site organisateur */
                          <div>
                            <Button 
                              onClick={() => {
                                if (event.organizerWebsite) {
                                  // S'assurer que l'URL a un protocole
                                  let url = event.organizerWebsite;
                                  if (!url.startsWith('http://') && !url.startsWith('https://')) {
                                    url = 'https://' + url;
                                  }
                                  window.open(url, '_blank');
                                } else {
                                  alert("Contactez l'organisateur pour plus d'informations sur la réservation !");
                                }
                              }}
                              className="w-full bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow mb-4"
                            >
                              Réserver maintenant
                            </Button>
                            <p className="text-xs text-slate-400">
                              {event.organizerWebsite ? "Redirection vers le site de l'organisateur" : "Contactez l'organisateur directement"}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </CardContent>
              </Card>

              {/* Event Details */}
              <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-white mb-4">Détails de l'événement</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Calendar className="w-4 h-4 text-primary" />
                      <span>{new Date(event.date).toLocaleDateString('fr-FR')}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <MapPin className="w-4 h-4 text-primary" />
                      <span>{event.venue}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <span className="w-4 h-4 flex items-center justify-center">📍</span>
                      <span>{event.location}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Organizer Info */}
              <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-white mb-4">Organisateur</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center gap-2 text-slate-300">
                      <User className="w-4 h-4 text-primary" />
                      <span>{event.organizerName}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <Mail className="w-4 h-4 text-primary" />
                      <a href={`mailto:${event.organizerEmail}`} className="hover:text-primary transition-colors">
                        {event.organizerEmail}
                      </a>
                    </div>
                    {event.organizerPhone && (
                      <div className="flex items-center gap-2 text-slate-300">
                        <Phone className="w-4 h-4 text-primary" />
                        <a href={`tel:${event.organizerPhone}`} className="hover:text-primary transition-colors">
                          {event.organizerPhone}
                        </a>
                      </div>
                    )}
                    {event.organizerWebsite && (
                      <div className="flex items-center gap-2 text-slate-300">
                        <svg className="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M4.083 9h1.946c.089-1.546.383-2.97.837-4.118C6.004 2.508 4.509 1 2.699 1 1.207 1 0 2.207 0 3.699c0 .513.195 1.011.57 1.384C.77 5.478 2.04 7.158 3.3 8.618c.244.28.58.372.783.382zM10 5a5 5 0 00-4.546 2.916A5.986 5.986 0 0010 16a5.986 5.986 0 004.546-8.084A5 5 0 0010 5zM7.272 3.333A6.986 6.986 0 0110 2a6.986 6.986 0 012.728 1.333c-.542.958-1.186 2.148-1.854 3.458-.325.638-.632 1.2-.874 1.643-.242-.443-.549-1.005-.874-1.643-.668-1.31-1.312-2.5-1.854-3.458z" clipRule="evenodd" />
                        </svg>
                        <a href={event.organizerWebsite} target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                          Site web
                        </a>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
