import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { MessageCircle, ArrowLeft, Send, User } from "lucide-react";

export default function MessagesFinal() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeConversation, setActiveConversation] = useState<number | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [messages, setMessages] = useState<any[]>([]);

  // Récupérer les conversations existantes
  const { data: conversations = [], isLoading: loadingConversations } = useQuery({
    queryKey: ["/api/messages/conversations"],
    enabled: !!user
  });

  // Vérifier si un utilisateur a été sélectionné depuis un profil
  useEffect(() => {
    const savedUserId = localStorage.getItem('selectedUserId');
    if (savedUserId && user) {
      setActiveConversation(parseInt(savedUserId));
      // Nettoyer le localStorage après utilisation
      localStorage.removeItem('selectedUserId');
      localStorage.removeItem('selectedUsername');
    }
  }, [user]);

  // Récupérer les messages pour la conversation active
  useEffect(() => {
    if (activeConversation && user) {
      fetchMessages();
    }
  }, [activeConversation, user]);

  const fetchMessages = async () => {
    if (!activeConversation) return;
    
    try {
      const response = await fetch(`/api/messages/conversation/${activeConversation}`, {
        credentials: "include"
      });
      
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (error) {
      console.error("Erreur récupération messages:", error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !activeConversation) return;

    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({
          receiverId: activeConversation,
          content: newMessage.trim()
        })
      });

      if (response.ok) {
        setNewMessage("");
        fetchMessages(); // Recharger les messages
        toast({
          title: "Message envoyé",
          description: "Votre message a été envoyé avec succès."
        });
      } else {
        toast({
          title: "Erreur",
          description: "Impossible d'envoyer le message.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue.",
        variant: "destructive"
      });
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <Card className="bg-slate-800 border-slate-700 p-8">
            <CardContent className="text-center">
              <MessageCircle className="h-16 w-16 text-cyan-400 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-white mb-2">
                Connexion requise
              </h2>
              <p className="text-slate-400 mb-6">
                Connectez-vous pour accéder aux messages
              </p>
              <Link href="/login">
                <Button className="bg-cyan-600 hover:bg-cyan-700">
                  Se connecter
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      <Header />
      
      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-white">Messages privés</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
            {/* Liste des conversations */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Conversations actives</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="space-y-2 max-h-[500px] overflow-y-auto">
                  {loadingConversations ? (
                    <div className="p-4 text-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-cyan-400 mx-auto mb-2"></div>
                      <p className="text-slate-400 text-sm">Chargement...</p>
                    </div>
                  ) : conversations.length === 0 ? (
                    <div className="p-6 text-center">
                      <MessageCircle className="h-12 w-12 text-cyan-400 mx-auto mb-3 opacity-50" />
                      <p className="text-slate-400">Aucune conversation active</p>
                      <p className="text-slate-500 text-xs mt-2">
                        Pour commencer une conversation, visitez le profil d'un utilisateur depuis la communauté et cliquez sur "Envoyer un message"
                      </p>
                    </div>
                  ) : (
                    conversations.map((conversation: any) => (
                      <button
                        key={conversation.otherUserId}
                        onClick={() => setActiveConversation(conversation.otherUserId)}
                        className={`w-full p-3 text-left hover:bg-slate-700 transition-colors border-b border-slate-700 ${
                          activeConversation === conversation.otherUserId ? 'bg-slate-600' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <User className="w-8 h-8 text-cyan-400" />
                          <div className="flex-1">
                            <p className="text-white font-medium">{conversation.otherUsername}</p>
                            <p className="text-slate-400 text-sm truncate">
                              {conversation.lastMessage || "Commencer la conversation"}
                            </p>
                          </div>
                          {conversation.unreadCount > 0 && (
                            <div className="bg-cyan-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                              {conversation.unreadCount}
                            </div>
                          )}
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Zone de conversation */}
            <div className="lg:col-span-2">
              {activeConversation ? (
                <Card className="bg-slate-800 border-slate-700 h-full flex flex-col">
                  <CardHeader>
                    <CardTitle className="text-white">
                      Conversation avec {conversations.find((c: any) => c.otherUserId === activeConversation)?.otherUsername || 'Utilisateur'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col p-4">
                    {/* Messages */}
                    <div className="flex-1 space-y-4 overflow-y-auto mb-4 min-h-0">
                      {messages.length === 0 ? (
                        <div className="flex items-center justify-center h-full">
                          <div className="text-center">
                            <MessageCircle className="h-16 w-16 text-cyan-400 mx-auto mb-4 opacity-50" />
                            <p className="text-slate-400">Aucun message dans cette conversation</p>
                            <p className="text-slate-500 text-sm mt-2">Envoyez le premier message !</p>
                          </div>
                        </div>
                      ) : (
                        messages.map((message: any) => (
                          <div
                            key={message.id}
                            className={`flex ${
                              message.senderId === user.id ? "justify-end" : "justify-start"
                            }`}
                          >
                            <div
                              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                                message.senderId === user.id
                                  ? "bg-cyan-600 text-white"
                                  : "bg-slate-700 text-slate-100"
                              }`}
                            >
                              <p className="text-sm">{message.content}</p>
                              <p className="text-xs opacity-70 mt-1">
                                {new Date(message.sentAt).toLocaleTimeString()}
                              </p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Zone d'envoi */}
                    <div className="flex gap-2">
                      <Textarea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Tapez votre message..."
                        className="flex-1 bg-slate-700 border-slate-600 text-white resize-none"
                        rows={2}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault();
                            sendMessage();
                          }
                        }}
                      />
                      <Button
                        onClick={sendMessage}
                        disabled={!newMessage.trim()}
                        className="bg-cyan-600 hover:bg-cyan-700 self-end"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="bg-slate-800 border-slate-700 h-full">
                  <CardContent className="flex items-center justify-center h-full">
                    <div className="text-center">
                      <MessageCircle className="h-20 w-20 text-cyan-400 mx-auto mb-6 opacity-50" />
                      <h3 className="text-xl font-semibold text-white mb-4">
                        Sélectionnez une conversation
                      </h3>
                      <p className="text-slate-400">
                        Choisissez un utilisateur dans la liste pour commencer à discuter
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}