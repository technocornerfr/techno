import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, User, Ticket, Calendar, Mail, Phone } from "lucide-react";

export default function AdminSearch() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSearch, setActiveSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState<string | null>(null);

  // Recherche d'utilisateurs
  const { data: searchResults, isLoading: isSearching } = useQuery({
    queryKey: ["/api/search/users", activeSearch],
    enabled: activeSearch.length >= 2,
  }) as { data: any, isLoading: boolean };

  // Profil utilisateur détaillé
  const { data: userProfile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ["/api/user/profile", selectedUser],
    enabled: !!selectedUser,
  }) as { data: any, isLoading: boolean };

  // Recherche de billets
  const { data: ticketResults } = useQuery({
    queryKey: ["/api/search/tickets", { q: activeSearch }],
    enabled: activeSearch.length >= 2,
  }) as { data: any };

  const handleSearch = () => {
    if (searchQuery.trim().length >= 2) {
      setActiveSearch(searchQuery.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Recherche Administrative</h1>
        <p className="text-gray-600 mb-6">
          Recherchez des utilisateurs et leurs billets pour assistance client et gestion.
        </p>

        {/* Barre de recherche */}
        <div className="flex gap-2 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Rechercher par nom, email ou code billet..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              className="pl-10"
            />
          </div>
          <Button onClick={handleSearch} disabled={searchQuery.trim().length < 2}>
            Rechercher
          </Button>
        </div>
      </div>

      {activeSearch && (
        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="users">Utilisateurs</TabsTrigger>
            <TabsTrigger value="tickets">Billets</TabsTrigger>
            <TabsTrigger value="profile">Profil Détaillé</TabsTrigger>
          </TabsList>

          {/* Onglet Utilisateurs */}
          <TabsContent value="users" className="space-y-4">
            {isSearching ? (
              <div className="text-center py-8">Recherche en cours...</div>
            ) : searchResults?.results ? (
              <div className="grid gap-4">
                {/* Utilisateurs enregistrés */}
                {searchResults.results.registered_users?.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <User className="h-5 w-5" />
                        Utilisateurs Enregistrés ({searchResults.results.registered_users.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {searchResults.results.registered_users.map((user: any) => (
                          <div
                            key={user.id}
                            className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                            onClick={() => setSelectedUser(user.email)}
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                <User className="h-5 w-5 text-blue-600" />
                              </div>
                              <div>
                                <p className="font-medium">{user.full_name || user.username}</p>
                                <p className="text-sm text-gray-600">{user.email}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge variant="secondary">Inscrit</Badge>
                              <p className="text-xs text-gray-500 mt-1">
                                {formatDate(user.created_at)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Acheteurs de billets */}
                {searchResults.results.ticket_buyers?.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Ticket className="h-5 w-5" />
                        Acheteurs de Billets ({searchResults.results.ticket_buyers.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {searchResults.results.ticket_buyers.map((buyer: any, index: number) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                            onClick={() => setSelectedUser(buyer.buyer_email)}
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                                <Ticket className="h-5 w-5 text-green-600" />
                              </div>
                              <div>
                                <p className="font-medium">{buyer.buyer_name}</p>
                                <p className="text-sm text-gray-600">{buyer.buyer_email}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge variant="outline">{buyer.ticket_count} billets</Badge>
                              <p className="text-xs text-gray-500 mt-1">
                                Dernier: {formatDate(buyer.last_purchase)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {(!searchResults.results.registered_users?.length && 
                  !searchResults.results.ticket_buyers?.length) && (
                  <div className="text-center py-8 text-gray-500">
                    Aucun utilisateur trouvé pour "{activeSearch}"
                  </div>
                )}
              </div>
            ) : null}
          </TabsContent>

          {/* Onglet Billets */}
          <TabsContent value="tickets" className="space-y-4">
            {ticketResults?.tickets?.length > 0 ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Ticket className="h-5 w-5" />
                    Billets Trouvés ({ticketResults.tickets.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {ticketResults.tickets.map((ticket: any) => (
                      <div key={ticket.id} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">{ticket.event_title}</p>
                            <p className="text-sm text-gray-600">
                              {ticket.buyer_name} - {ticket.buyer_email}
                            </p>
                          </div>
                          <Badge 
                            variant={ticket.status === 'active' ? 'default' : 'secondary'}
                          >
                            {ticket.status}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                          <div>
                            <span className="text-gray-500">Code:</span>
                            <p className="font-mono">{ticket.ticket_code}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Date achat:</span>
                            <p>{formatDate(ticket.purchase_date)}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Événement:</span>
                            <p>{formatDate(ticket.event_date)}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Lieu:</span>
                            <p>{ticket.venue}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="text-center py-8 text-gray-500">
                Aucun billet trouvé
              </div>
            )}
          </TabsContent>

          {/* Onglet Profil Détaillé */}
          <TabsContent value="profile" className="space-y-4">
            {selectedUser ? (
              isLoadingProfile ? (
                <div className="text-center py-8">Chargement du profil...</div>
              ) : userProfile ? (
                <div className="grid gap-6">
                  {/* Informations utilisateur */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <User className="h-5 w-5" />
                        Informations Utilisateur
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-500">Email</p>
                          <p className="font-medium">{selectedUser}</p>
                        </div>
                        {userProfile.user && (
                          <>
                            <div>
                              <p className="text-sm text-gray-500">Nom complet</p>
                              <p className="font-medium">{userProfile.user.full_name || "Non renseigné"}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Nom d'utilisateur</p>
                              <p className="font-medium">{userProfile.user.username}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Inscription</p>
                              <p className="font-medium">{formatDate(userProfile.user.created_at)}</p>
                            </div>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Statistiques */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Statistiques</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-blue-600">{userProfile.stats.total_tickets}</p>
                          <p className="text-sm text-gray-600">Total billets</p>
                        </div>
                        <div className="text-center">
                          <p className="text-2xl font-bold text-green-600">{userProfile.stats.active_tickets}</p>
                          <p className="text-sm text-gray-600">Actifs</p>
                        </div>
                        <div className="text-center">
                          <p className="text-2xl font-bold text-gray-600">{userProfile.stats.used_tickets}</p>
                          <p className="text-sm text-gray-600">Utilisés</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-medium">Premier achat</p>
                          <p className="text-xs text-gray-600">
                            {userProfile.stats.first_purchase ? formatDate(userProfile.stats.first_purchase) : "N/A"}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-medium">Dernier achat</p>
                          <p className="text-xs text-gray-600">
                            {userProfile.stats.last_purchase ? formatDate(userProfile.stats.last_purchase) : "N/A"}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Billets récents */}
                  {userProfile.tickets?.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Ticket className="h-5 w-5" />
                          Billets ({userProfile.tickets.length})
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3 max-h-96 overflow-y-auto">
                          {userProfile.tickets.map((ticket: any) => (
                            <div key={ticket.id} className="p-3 border rounded-lg">
                              <div className="flex justify-between items-start mb-2">
                                <p className="font-medium">{ticket.event_title}</p>
                                <Badge variant={ticket.status === 'active' ? 'default' : 'secondary'}>
                                  {ticket.status}
                                </Badge>
                              </div>
                              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm text-gray-600">
                                <div>Code: {ticket.ticket_code}</div>
                                <div>Achat: {formatDate(ticket.purchase_date)}</div>
                                <div>Événement: {formatDate(ticket.event_date)}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  Profil non trouvé
                </div>
              )
            ) : (
              <div className="text-center py-8 text-gray-500">
                Sélectionnez un utilisateur pour voir son profil détaillé
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}