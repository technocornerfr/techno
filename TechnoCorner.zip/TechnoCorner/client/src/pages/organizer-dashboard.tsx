import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { 
  Calendar, 
  Euro, 
  Users, 
  TrendingUp, 
  Download, 
  Eye, 
  Plus,
  MapPin,
  Clock,
  QrCode,
  Mail,
  CheckCircle,
  AlertCircle,
  DollarSign,
  LogIn,
  Building,
  CreditCard,
  BarChart3,
  Trash2,
  RefreshCw
} from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

interface OrganizerEvent {
  id: number;
  title: string;
  description: string;
  date: string;
  venue: string;
  location: string;
  price: string;
  ticketsAvailable: number;
  organizerEmail: string;
  image?: string;
  ticketsSold: number;
  totalRevenue: number;
  status: 'upcoming' | 'past' | 'cancelled';
}

interface OrganizerTicket {
  id: number;
  code: string;
  eventId: number;
  eventTitle: string;
  buyerName: string;
  buyerEmail: string;
  purchaseDate: string;
  price: string;
  status: string;
  qrCode?: string;
}

interface OrganizerPayout {
  id: number;
  eventId: number;
  eventTitle: string;
  amount: string;
  stripeTransferId?: string;
  status: 'pending' | 'completed' | 'failed';
  createdAt: string;
  processedAt?: string;
}

export default function OrganizerDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Vérifier l'authentification
  const { data: currentUser, isLoading: authLoading } = useQuery({
    queryKey: ["/api/auth/current"],
    retry: false,
  });

  const organizerEmail = (currentUser as any)?.organizerEmail;

  // Requêtes pour les données de l'organisateur
  const { data: events, isLoading: eventsLoading } = useQuery({
    queryKey: [`/api/organizer/events/${organizerEmail}`],
    enabled: !!organizerEmail,
  });

  const { data: tickets, isLoading: ticketsLoading } = useQuery({
    queryKey: [`/api/organizer/tickets/${organizerEmail}`],
    enabled: !!organizerEmail,
  });

  const { data: payouts, isLoading: payoutsLoading } = useQuery({
    queryKey: [`/api/organizer/payouts/${organizerEmail}`],
    enabled: !!organizerEmail,
  });

  // Requête pour les analytics globaux
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: [`/api/organizer/analytics/${organizerEmail}`],
    enabled: !!organizerEmail,
  });

  // Mutation pour créer un événement de test
  const createDemoEventMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/events", {
        title: "Soirée Techno Demo",
        description: "Événement de démonstration pour tester le système",
        date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        venue: "Club Demo",
        location: "Paris, France",
        price: "15.00",
        ticketsAvailable: 100,
        organizerEmail: organizerEmail,
        image: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=400&h=300&fit=crop",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/organizer/events/${organizerEmail}`] });
      toast({
        title: "Événement créé",
        description: "Votre événement de démonstration a été créé avec succès",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Erreur lors de la création de l'événement",
        variant: "destructive",
      });
    },
  });

  // Mutation pour supprimer un événement
  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: number) => {
      return apiRequest("DELETE", `/api/events/${eventId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/organizer/events/${organizerEmail}`] });
      toast({
        title: "Événement supprimé",
        description: "L'événement a été supprimé avec succès",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Erreur lors de la suppression",
        variant: "destructive",
      });
    },
  });

  // Mutation pour synchroniser avec Eventbrite
  const syncEventbriteMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/eventbrite/sync", {
        location: "Paris, France"
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      queryClient.invalidateQueries({ queryKey: [`/api/organizer/events/${organizerEmail}`] });
      toast({
        title: "Synchronisation réussie",
        description: `${data.eventsImported} nouveaux événements importés depuis Eventbrite`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur de synchronisation",
        description: error.message || "Erreur lors de la synchronisation avec Eventbrite",
        variant: "destructive",
      });
    },
  });

  // Utiliser les analytics calculées côté serveur
  const totalRevenue = (analytics as any)?.totalRevenue || 0;
  const totalTicketsSold = (analytics as any)?.totalTicketsSold || 0;
  const upcomingEvents = (analytics as any)?.upcomingEvents || 0;
  const pendingPayouts = (analytics as any)?.pendingPayouts || 0;

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Si l'utilisateur n'est pas connecté, afficher la page de connexion pour organisateurs
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20">
        <div className="fixed inset-0 bg-gradient-to-br from-slate-900/50 via-transparent to-transparent pointer-events-none"></div>
        
        <div className="relative z-10 p-4 sm:p-6 lg:p-8">
          <div className="max-w-6xl mx-auto pt-8">
            {/* En-tête */}
            <div className="text-center mb-12">
              <h1 className="text-5xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent mb-4">
                Espace Organisateur
              </h1>
              <p className="text-xl text-slate-300 max-w-3xl mx-auto">
                Gérez vos événements électroniques avec des outils professionnels. 
                Créez, vendez et suivez vos soirées en temps réel.
              </p>
            </div>

            {/* Call to action principal */}
            <div className="text-center mb-16">
              <Button 
                onClick={() => setLocation("/login")}
                className="bg-primary hover:bg-primary/90 px-8 py-3 text-lg"
              >
                <LogIn className="w-5 h-5 mr-2" />
                Se connecter pour organiser
              </Button>
            </div>

            {/* Call to action final */}
            <div className="text-center mt-12">
              <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/30 max-w-2xl mx-auto">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-white mb-4">
                    Prêt à organiser votre prochain événement ?
                  </h3>
                  <p className="text-slate-300 mb-6">
                    Rejoignez la communauté des organisateurs TechnoCorner et bénéficiez d'outils professionnels pour vos événements électroniques.
                  </p>
                  <Button 
                    onClick={() => setLocation("/login")}
                    className="bg-primary hover:bg-primary/90 px-8 py-3 text-lg"
                  >
                    <LogIn className="w-5 h-5 mr-2" />
                    Commencer maintenant
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (eventsLoading || ticketsLoading || payoutsLoading || analyticsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-pink-900/20">
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900/50 via-transparent to-transparent pointer-events-none"></div>
      
      <div className="relative z-10 p-4 sm:p-6 lg:p-8">
        <div className="max-w-6xl mx-auto pt-8">
          {/* En-tête */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent mb-2">
                Dashboard Organisateur
              </h1>
              <p className="text-slate-300">
                Bienvenue {organizerEmail}
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 mt-4 sm:mt-0">
              <Button
                onClick={() => syncEventbriteMutation.mutate()}
                disabled={syncEventbriteMutation.isPending}
                variant="outline"
                className="border-secondary/50 text-secondary hover:bg-secondary/10"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${syncEventbriteMutation.isPending ? 'animate-spin' : ''}`} />
                {syncEventbriteMutation.isPending ? "Synchronisation..." : "Sync Eventbrite"}
              </Button>
              {(!events || !Array.isArray(events) || events.length === 0) && (
                <Button
                  onClick={() => createDemoEventMutation.mutate()}
                  disabled={createDemoEventMutation.isPending}
                  variant="outline"
                  className="border-accent/50 text-accent hover:bg-accent/10"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {createDemoEventMutation.isPending ? "Création..." : "Créer événement de test"}
                </Button>
              )}
              <Link href="/create">
                <Button className="bg-primary hover:bg-primary/80">
                  <Plus className="w-4 h-4 mr-2" />
                  Créer un événement
                </Button>
              </Link>
            </div>
          </div>

          {/* Statistiques générales */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm font-medium">Revenus totaux</p>
                    <p className="text-2xl font-bold text-white">
                      {totalRevenue.toFixed(2)} €
                    </p>
                  </div>
                  <Euro className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 backdrop-blur-sm border-secondary/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm font-medium">Billets vendus</p>
                    <p className="text-2xl font-bold text-white">{totalTicketsSold}</p>
                  </div>
                  <Users className="w-8 h-8 text-secondary" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 backdrop-blur-sm border-accent/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm font-medium">Événements à venir</p>
                    <p className="text-2xl font-bold text-white">{upcomingEvents}</p>
                  </div>
                  <Calendar className="w-8 h-8 text-accent" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900/50 backdrop-blur-sm border-yellow-500/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm font-medium">Paiements en attente</p>
                    <p className="text-2xl font-bold text-white">{pendingPayouts}</p>
                  </div>
                  <Clock className="w-8 h-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Section Vérification des billets */}
          <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-500/30 mb-8">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <QrCode className="h-6 w-6 text-purple-400" />
                <span>Scanner de Validation des Billets</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Avertissement important */}
              <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4 mb-6">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="h-5 w-5 text-red-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="text-red-300 font-semibold text-sm mb-2">⚠️ ATTENTION - Validation des billets</h4>
                    <p className="text-red-200 text-xs mb-2">
                      <strong>Ne validez JAMAIS un billet en dehors de l'entrée de votre événement.</strong>
                    </p>
                    <p className="text-red-200 text-xs">
                      Toute validation prématurée ou test de billet rendra le billet définitivement inutilisable. Le système anti-fraude marque immédiatement le billet comme "utilisé" dès le premier scan. Confiez cette responsabilité uniquement à votre équipe de sécurité à l'entrée de l'événement.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-1 gap-4 max-w-md">
                <Link href="/mobile-scanner">
                  <Card className="bg-gray-800/50 border-gray-600 hover:border-blue-500 transition-colors cursor-pointer">
                    <CardContent className="p-6 text-center">
                      <div className="text-4xl mb-3">📱</div>
                      <h4 className="font-semibold text-white text-lg mb-2">Scanner Mobile</h4>
                      <p className="text-sm text-gray-300 mb-2">Validation en temps réel par caméra</p>
                      <p className="text-xs text-gray-400">
                        Idéal pour la validation à l'entrée de vos événements
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Onglets pour les détails */}
          <Tabs defaultValue="events" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 lg:w-1/2">
              <TabsTrigger value="events">Mes Événements</TabsTrigger>
              <TabsTrigger value="tickets">Billets</TabsTrigger>
              <TabsTrigger value="payouts">Paiements</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="events" className="space-y-6">
              {Array.isArray(events) && events.length > 0 ? (
                <div className="grid gap-6">
                  {events.map((event: any) => (
                    <Card key={event.id} className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                      <CardContent className="p-6">
                        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-start gap-4">
                              {event.image && (
                                <img 
                                  src={event.image} 
                                  alt={event.title}
                                  className="w-16 h-16 rounded-lg object-cover bg-slate-800"
                                />
                              )}
                              <div className="flex-1">
                                <h3 className="text-xl font-bold text-white mb-2">{event.title}</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-slate-300">
                                  <div className="flex items-center space-x-2">
                                    <Calendar className="w-4 h-4" />
                                    <span>{format(new Date(event.date), "d MMMM yyyy 'à' HH:mm", { locale: fr })}</span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <MapPin className="w-4 h-4" />
                                    <span>{event.venue}</span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <Euro className="w-4 h-4" />
                                    <span>{event.price}</span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <Users className="w-4 h-4" />
                                    <span>{event.ticketsSold || 0} / {event.ticketsAvailable || 'Illimité'}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex flex-col sm:flex-row gap-2">
                            <Link href={`/event/${event.id}`}>
                              <Button variant="outline" size="sm" className="w-full sm:w-auto">
                                <Eye className="w-4 h-4 mr-2" />
                                Voir
                              </Button>
                            </Link>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => deleteEventMutation.mutate(event.id)}
                              disabled={deleteEventMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Supprimer
                            </Button>
                          </div>
                        </div>
                        
                        {/* Statistiques de l'événement */}
                        <div className="mt-4 pt-4 border-t border-slate-700">
                          <div className="grid grid-cols-3 gap-4 text-center">
                            <div>
                              <p className="text-2xl font-bold text-primary">{event.ticketsSold || 0}</p>
                              <p className="text-xs text-slate-400">Billets vendus</p>
                            </div>
                            <div>
                              <p className="text-2xl font-bold text-secondary">{(event.totalRevenue || 0).toFixed(2)}€</p>
                              <p className="text-xs text-slate-400">Revenus</p>
                            </div>
                            <div>
                              <p className="text-2xl font-bold text-accent">{event.ticketsAvailable - (event.ticketsSold || 0)}</p>
                              <p className="text-xs text-slate-400">Restants</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                  <CardContent className="p-8 text-center">
                    <Calendar className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Aucun événement créé</h3>
                    <p className="text-slate-400 mb-6">Commencez par créer votre premier événement pour voir vos statistiques ici.</p>
                    <Link href="/create">
                      <Button className="bg-primary hover:bg-primary/80">
                        <Plus className="w-4 h-4 mr-2" />
                        Créer mon premier événement
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="tickets" className="space-y-6">
              {Array.isArray(tickets) && tickets.length > 0 ? (
                <div className="grid gap-4">
                  {tickets.map((ticket: any) => (
                    <Card key={ticket.id} className="bg-slate-900/50 backdrop-blur-sm border-secondary/20">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold text-white">{ticket.buyerName}</h4>
                            <p className="text-sm text-slate-300">{ticket.buyerEmail}</p>
                            <p className="text-sm text-slate-400">Code: {ticket.code}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-secondary">{ticket.price}</p>
                            <Badge variant={ticket.status === 'valid' ? 'default' : ticket.status === 'used' ? 'secondary' : 'destructive'}>
                              {ticket.status === 'valid' ? 'Valide' : ticket.status === 'used' ? 'Utilisé' : 'Annulé'}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="bg-slate-900/50 backdrop-blur-sm border-secondary/20">
                  <CardContent className="p-8 text-center">
                    <QrCode className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Aucun billet vendu</h3>
                    <p className="text-slate-400">Les billets vendus pour vos événements apparaîtront ici.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="payouts" className="space-y-6">
              {Array.isArray(payouts) && payouts.length > 0 ? (
                <div className="grid gap-4">
                  {payouts.map((payout: any) => (
                    <Card key={payout.id} className="bg-slate-900/50 backdrop-blur-sm border-accent/20">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="font-semibold text-white">Paiement #{payout.id}</h4>
                            <p className="text-sm text-slate-300">{format(new Date(payout.createdAt), "d MMMM yyyy", { locale: fr })}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-accent">{payout.amount}€</p>
                            <Badge variant={payout.status === 'completed' ? 'default' : payout.status === 'pending' ? 'secondary' : 'destructive'}>
                              {payout.status === 'completed' ? 'Effectué' : payout.status === 'pending' ? 'En attente' : 'Échoué'}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="bg-slate-900/50 backdrop-blur-sm border-accent/20">
                  <CardContent className="p-8 text-center">
                    <DollarSign className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Aucun paiement</h3>
                    <p className="text-slate-400">Vos paiements d'organisateur apparaîtront ici.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
                  <CardHeader>
                    <CardTitle className="text-white">Revenus par mois</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <BarChart3 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                      <p className="text-slate-400">Graphiques disponibles bientôt</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-900/50 backdrop-blur-sm border-secondary/20">
                  <CardHeader>
                    <CardTitle className="text-white">Billets vendus</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <TrendingUp className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                      <p className="text-slate-400">Statistiques détaillées bientôt</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}