import { useState } from "react";
import { useQuery, useMutation, queryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Copy, Eye, EyeOff, Key, Shield, Settings, Plus, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ApiKey {
  id: string;
  keyId: string;
  organizerName: string;
  permissions: string[];
  status: string;
  createdAt: string;
  lastUsed?: string;
}

export default function ApiManagement() {
  const [showApiKey, setShowApiKey] = useState<string | null>(null);
  const [newApiKeyForm, setNewApiKeyForm] = useState({
    organizerName: "",
    organizerEmail: "",
    permissions: ["validate_tickets", "verify_tickets"]
  });
  const { toast } = useToast();

  const { data: apiKeys, isLoading } = useQuery({
    queryKey: ["/api/organizer/api-keys"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/organizer/api-keys");
      return response.json();
    }
  });

  const generateApiKeyMutation = useMutation({
    mutationFn: async (data: typeof newApiKeyForm) => {
      const response = await apiRequest("POST", "/api/organizers/generate-api-key", data);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erreur lors de la génération");
      }
      return response.json();
    },
    onSuccess: (data) => {
      setShowApiKey(data.apiKey);
      setNewApiKeyForm({
        organizerName: "",
        organizerEmail: "",
        permissions: ["validate_tickets", "verify_tickets"]
      });
      queryClient.invalidateQueries({ queryKey: ["/api/organizer/api-keys"] });
      toast({
        title: "Clé API générée",
        description: "Copiez la clé maintenant, elle ne sera plus affichée ensuite."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const revokeApiKeyMutation = useMutation({
    mutationFn: async (keyId: string) => {
      const response = await apiRequest("DELETE", `/api/organizer/api-keys/${keyId}`);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erreur lors de la révocation");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizer/api-keys"] });
      toast({
        title: "Clé API révoquée",
        description: "La clé a été désactivée avec succès."
      });
    }
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copié",
      description: "Clé API copiée dans le presse-papiers"
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-4">
            <Key className="inline h-8 w-8 mr-3 text-purple-400" />
            Gestion des Clés API
          </h1>
          <p className="text-gray-400">
            Intégrez vos machines de scan avec notre système anti-fraude
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Génération de nouvelle clé */}
          <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Plus className="h-5 w-5 text-green-400" />
                <span>Générer une nouvelle clé API</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="organizerName" className="text-gray-300">
                  Nom de l'organisation
                </Label>
                <Input
                  id="organizerName"
                  value={newApiKeyForm.organizerName}
                  onChange={(e) => setNewApiKeyForm(prev => ({ ...prev, organizerName: e.target.value }))}
                  placeholder="Mon Organisation"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="organizerEmail" className="text-gray-300">
                  Email de contact
                </Label>
                <Input
                  id="organizerEmail"
                  type="email"
                  value={newApiKeyForm.organizerEmail}
                  onChange={(e) => setNewApiKeyForm(prev => ({ ...prev, organizerEmail: e.target.value }))}
                  placeholder="contact@organisation.com"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-300">Permissions</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  <Badge className="bg-blue-600">Vérification billets</Badge>
                  <Badge className="bg-green-600">Validation entrée</Badge>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  Permissions par défaut pour l'intégration scanner
                </p>
              </div>

              <Button
                onClick={() => generateApiKeyMutation.mutate(newApiKeyForm)}
                disabled={!newApiKeyForm.organizerName || !newApiKeyForm.organizerEmail || generateApiKeyMutation.isPending}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                {generateApiKeyMutation.isPending ? (
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                ) : (
                  <Key className="h-4 w-4 mr-2" />
                )}
                Générer la clé API
              </Button>

              {showApiKey && (
                <Alert className="border-green-500/50 bg-green-900/20">
                  <Shield className="h-4 w-4" />
                  <AlertDescription className="text-green-200">
                    <div className="space-y-2">
                      <p className="font-semibold">Votre nouvelle clé API :</p>
                      <div className="flex items-center space-x-2 bg-gray-800 p-2 rounded">
                        <code className="flex-1 text-sm font-mono text-green-300 break-all">
                          {showApiKey}
                        </code>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(showApiKey)}
                          className="border-green-600 text-green-300"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                      <p className="text-xs">
                        ⚠️ Copiez cette clé maintenant. Elle ne sera plus affichée.
                      </p>
                    </div>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Documentation d'intégration */}
          <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Settings className="h-5 w-5 text-blue-400" />
                <span>Guide d'intégration</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3 text-sm">
                <div>
                  <h4 className="font-semibold text-white mb-2">1. Configuration machine de scan</h4>
                  <div className="bg-gray-900 p-3 rounded text-gray-300 font-mono text-xs">
                    <div>TECHNOCORNER_API_KEY=votre_cle_api</div>
                    <div>TECHNOCORNER_BASE_URL=https://votre-domaine.com</div>
                    <div>SCANNER_ID=scanner-entree-01</div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-white mb-2">2. Validation d'un billet</h4>
                  <div className="bg-gray-900 p-3 rounded text-gray-300 font-mono text-xs">
                    POST /api/validate-ticket<br/>
                    Authorization: Bearer VOTRE_CLE<br/>
                    {"{"}"qrData": "...", "validatorId": "scanner-01"{"}"}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-white mb-2">3. Codes de réponse</h4>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-green-400">200</span>
                      <span className="text-gray-300">Validation réussie</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-red-400">400</span>
                      <span className="text-gray-300">Billet déjà utilisé</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-yellow-400">404</span>
                      <span className="text-gray-300">Billet non trouvé</span>
                    </div>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full border-blue-600 text-blue-300"
                onClick={() => window.open('/INTEGRATION_SCANNER_API.md', '_blank')}
              >
                📖 Documentation complète
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Liste des clés existantes */}
        <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm mt-6">
          <CardHeader>
            <CardTitle className="text-white">Clés API existantes</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin w-6 h-6 border-2 border-purple-400 border-t-transparent rounded-full mx-auto mb-2" />
                <p className="text-gray-400">Chargement...</p>
              </div>
            ) : apiKeys?.length === 0 ? (
              <div className="text-center py-8">
                <Key className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">Aucune clé API générée</p>
              </div>
            ) : (
              <div className="space-y-3">
                {apiKeys?.map((key: ApiKey) => (
                  <div key={key.id} className="bg-gray-700/50 p-4 rounded-lg border border-gray-600">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h4 className="font-semibold text-white">{key.organizerName}</h4>
                          <Badge className={key.status === 'active' ? 'bg-green-600' : 'bg-red-600'}>
                            {key.status === 'active' ? 'Active' : 'Révoquée'}
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-400 space-y-1">
                          <div>Créée le : {new Date(key.createdAt).toLocaleDateString('fr-FR')}</div>
                          {key.lastUsed && (
                            <div>Dernière utilisation : {new Date(key.lastUsed).toLocaleDateString('fr-FR')}</div>
                          )}
                          <div className="flex space-x-1">
                            {key.permissions.map(perm => (
                              <Badge key={perm} variant="outline" className="text-xs">
                                {perm}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      {key.status === 'active' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => revokeApiKeyMutation.mutate(key.keyId)}
                          className="border-red-600 text-red-400 hover:bg-red-900/20"
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Révoquer
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}