import { Link } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { MessageCircle, ArrowLeft } from "lucide-react";

export default function Messages() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <Card className="bg-slate-800 border-slate-700 p-8">
            <CardContent className="text-center">
              <MessageCircle className="h-16 w-16 text-cyan-400 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-white mb-2">
                Connexion requise
              </h2>
              <p className="text-slate-400 mb-6">
                Connectez-vous pour accéder aux messages
              </p>
              <Link href="/login">
                <Button className="bg-cyan-600 hover:bg-cyan-700">
                  Se connecter
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      <Header />
      
      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-white">Messages</h1>
          </div>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="text-center py-16">
              <MessageCircle className="h-20 w-20 text-cyan-400 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-white mb-4">
                Messages privés
              </h3>
              <p className="text-slate-400 mb-8 max-w-md mx-auto">
                La messagerie privée est accessible ! Cette section vous permet 
                d'échanger des messages avec les autres membres.
              </p>
              
              <div className="space-y-4">
                <Link href="/community">
                  <Button className="bg-cyan-600 hover:bg-cyan-700">
                    Aller à la communauté
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}