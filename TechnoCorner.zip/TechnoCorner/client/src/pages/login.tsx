import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Music, LogIn } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(1, "Le nom d'utilisateur est requis"),
  password: z.string().min(1, "Le mot de passe est requis"),
});

type LoginFormData = z.infer<typeof loginSchema>;

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Vérifier si l'utilisateur est déjà connecté
  const { data: currentUser } = useQuery({
    queryKey: ["/api/auth/current"],
    queryFn: () => apiRequest("GET", "/api/auth/current"),
    retry: false,
  });

  // Rediriger si déjà connecté
  useEffect(() => {
    if (currentUser) {
      setLocation("/");
    }
  }, [currentUser, setLocation]);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginFormData) => {
      return apiRequest("POST", "/api/auth/login", data);
    },
    onSuccess: () => {
      // Invalider tout le cache pour forcer la mise à jour complète
      queryClient.invalidateQueries();
      toast({
        title: "Connexion réussie!",
        description: "Bienvenue sur TechnoCorner.",
      });
      // Petit délai pour s'assurer que l'état est mis à jour
      setTimeout(() => {
        setLocation("/");
      }, 100);
    },
    onError: (error: any) => {
      toast({
        title: "Erreur de connexion",
        description: error.message || "Nom d'utilisateur ou mot de passe incorrect.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: LoginFormData) => {
    loginMutation.mutate(data);
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto mb-4 neon-glow">
              <Music className="text-white text-2xl" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Connexion</h1>
            <p className="text-slate-300">Accédez à votre compte TechnoCorner</p>
          </div>

          <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-white text-center">
                Se connecter
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Nom d'utilisateur</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Votre nom d'utilisateur" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Mot de passe</FormLabel>
                        <FormControl>
                          <Input 
                            type="password"
                            placeholder="Votre mot de passe" 
                            {...field} 
                            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    disabled={loginMutation.isPending}
                    className="w-full bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow"
                  >
                    <LogIn className="w-4 h-4 mr-2" />
                    {loginMutation.isPending ? "Connexion..." : "Se connecter"}
                  </Button>
                </form>
              </Form>

              <div className="mt-6 text-center">
                <p className="text-slate-400">
                  Pas encore de compte ?{" "}
                  <Link href="/register">
                    <span className="text-primary hover:text-secondary transition-colors cursor-pointer">
                      Créer un compte
                    </span>
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}