import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Camera, CheckCircle, XCircle, ScanLine, RotateCcw } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import QrScanner from "qr-scanner";

interface ScanResult {
  valid: boolean;
  message: string;
  ticket?: any;
  event?: any;
  validated?: boolean;
  alreadyUsed?: boolean;
  usedAt?: string;
}

export default function MobileScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanResult, setLastScanResult] = useState<ScanResult | null>(null);
  const [qrScanner, setQrScanner] = useState<QrScanner | null>(null);
  const [manualInput, setManualInput] = useState("");
  const [showManualInput, setShowManualInput] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const validateMutation = useMutation({
    mutationFn: async ({ qrData }: { qrData: string }) => {
      const response = await apiRequest("POST", "/api/scanner/validate", {
        qrData,
        scannerId: "mobile-scanner",
        location: "Scanner mobile"
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur de validation");
      }
      return response.json();
    },
    onSuccess: (data: ScanResult) => {
      setLastScanResult(data);
      if (navigator.vibrate) {
        navigator.vibrate(data.valid ? [100] : [100, 100, 100]);
      }
    },
    onError: (error: Error) => {
      setLastScanResult({
        valid: false,
        message: error.message
      });
      if (navigator.vibrate) {
        navigator.vibrate([100, 100, 100]);
      }
    }
  });

  const startCamera = async () => {
    if (!videoRef.current) {
      console.error("videoRef non disponible");
      return;
    }

    try {
      setIsScanning(true);
      setLastScanResult(null);
      console.log("Début de l'activation de la caméra...");

      // Vérifier d'abord si les permissions caméra sont disponibles
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("API caméra non supportée sur cet appareil");
      }

      // Demander l'accès à la caméra en premier
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280, min: 640 },
          height: { ideal: 720, min: 480 }
        }
      });
      
      console.log("Accès caméra accordé, création du scanner...");
      
      // Arrêter le stream temporaire
      stream.getTracks().forEach(track => track.stop());

      // Créer le scanner QR
      const scanner = new QrScanner(
        videoRef.current,
        (result) => {
          console.log("QR Code détecté:", result.data);
          validateMutation.mutate({ 
            qrData: result.data
          });
          stopCamera();
        },
        {
          returnDetailedScanResult: true,
          highlightScanRegion: true,
          highlightCodeOutline: true,
          preferredCamera: 'environment'
        }
      );

      setQrScanner(scanner);
      console.log("Démarrage du scanner...");
      await scanner.start();
      console.log("Scanner démarré avec succès");
      
    } catch (error: any) {
      console.error("Erreur d'accès à la caméra:", error);
      console.error("Type d'erreur:", error?.name);
      console.error("Message d'erreur:", error?.message);
      setIsScanning(false);
      let errorMessage = "Impossible d'accéder à la caméra.";
      
      if (error?.name === 'NotAllowedError') {
        errorMessage = "Accès à la caméra refusé. Cliquez sur 'Autoriser' quand votre navigateur le demande.";
      } else if (error?.name === 'NotFoundError') {
        errorMessage = "Aucune caméra trouvée sur cet appareil.";
      } else if (error?.name === 'NotSupportedError') {
        errorMessage = "La caméra n'est pas supportée sur cet appareil.";
      } else if (error?.name === 'NotReadableError') {
        errorMessage = "La caméra est déjà utilisée par une autre application.";
      } else if (error?.message) {
        errorMessage = error.message;
      } else {
        errorMessage = "Erreur technique lors de l'accès à la caméra. Rechargez la page et réessayez.";
      }
      
      setLastScanResult({
        valid: false,
        message: errorMessage
      });
    }
  };

  const stopCamera = () => {
    if (qrScanner) {
      qrScanner.stop();
      qrScanner.destroy();
      setQrScanner(null);
    }
    setIsScanning(false);
  };

  const handleManualValidation = () => {
    if (manualInput.trim()) {
      validateMutation.mutate({ 
        qrData: manualInput.trim()
      });
      setManualInput("");
      setShowManualInput(false);
    }
  };

  useEffect(() => {
    return () => {
      if (qrScanner) {
        qrScanner.stop();
        qrScanner.destroy();
      }
    };
  }, [qrScanner]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-white mb-2">Scanner QR</h1>
          <p className="text-gray-300">Validation des billets TechnoCorner</p>
        </div>

        {/* Zone de scan principal */}
        <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm mb-4">
          <CardContent className="p-4">
            {!isScanning ? (
              <div className="text-center space-y-4">
                <div className="w-24 h-24 mx-auto bg-purple-600/20 rounded-full flex items-center justify-center">
                  <Camera className="h-12 w-12 text-purple-400" />
                </div>
                
                {/* Élément vidéo caché pour l'initialisation */}
                <video
                  ref={videoRef}
                  className="hidden"
                  playsInline
                  muted
                />
                
                <Button 
                  onClick={() => {
                    console.log("Bouton cliqué, démarrage de la caméra...");
                    console.log("videoRef.current:", videoRef.current);
                    startCamera();
                  }}
                  disabled={validateMutation.isPending || isScanning}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white disabled:opacity-50"
                  size="lg"
                >
                  <Camera className="h-5 w-5 mr-2" />
                  {isScanning ? "Activation..." : validateMutation.isPending ? "Validation..." : "Scanner un QR Code"}
                </Button>
                
                <div className="text-center">
                  <p className="text-xs text-gray-400 mb-2">
                    Pointez la caméra vers le QR code du billet
                  </p>
                  <Button
                    onClick={() => setShowManualInput(!showManualInput)}
                    variant="outline"
                    size="sm"
                    className="border-gray-600 text-gray-300"
                  >
                    {showManualInput ? "Masquer" : "Saisie manuelle"}
                  </Button>
                </div>

                {showManualInput && (
                  <div className="mt-4 p-4 bg-gray-900/50 rounded-lg border border-gray-600">
                    <Label htmlFor="manual-qr" className="text-gray-300 text-sm">
                      Code du billet
                    </Label>
                    <div className="flex space-x-2 mt-2">
                      <Input
                        id="manual-qr"
                        value={manualInput}
                        onChange={(e) => setManualInput(e.target.value)}
                        placeholder="Saisissez le code"
                        className="bg-gray-800 border-gray-600 text-white"
                        onKeyPress={(e) => e.key === 'Enter' && handleManualValidation()}
                      />
                      <Button
                        onClick={handleManualValidation}
                        disabled={!manualInput.trim() || validateMutation.isPending}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        Valider
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="relative rounded-lg overflow-hidden">
                  <video
                    ref={videoRef}
                    className="w-full aspect-video object-cover bg-black"
                    playsInline
                    muted
                    autoPlay
                  />
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-48 h-48 border-2 border-white/50 rounded-lg flex items-center justify-center">
                      <ScanLine className="h-8 w-8 text-white animate-pulse" />
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={stopCamera}
                    className="flex-1 bg-red-600 hover:bg-red-700"
                  >
                    Arrêter
                  </Button>
                  <Button
                    onClick={() => {
                      stopCamera();
                      setTimeout(startCamera, 100);
                    }}
                    variant="outline"
                    className="border-gray-600 text-gray-300"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Résultat du scan */}
        {lastScanResult && (
          <Card className={`border-2 ${
            lastScanResult.valid 
              ? "border-green-500 bg-green-900/20" 
              : "border-red-500 bg-red-900/20"
          }`}>
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-lg flex items-center space-x-2">
                {lastScanResult.valid ? (
                  <CheckCircle className="h-6 w-6 text-green-400" />
                ) : (
                  <XCircle className="h-6 w-6 text-red-400" />
                )}
                <span>{lastScanResult.valid ? "Billet Valide" : "Billet Invalide"}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-white mb-3">{lastScanResult.message}</p>
              
              {lastScanResult.ticket && (
                <div className="space-y-2 text-sm">
                  <div className="bg-gray-800/50 p-3 rounded-lg">
                    <p className="text-gray-300"><strong>Acheteur:</strong> {lastScanResult.ticket.buyerName}</p>
                    <p className="text-gray-300"><strong>Prix:</strong> {lastScanResult.ticket.price}</p>
                    <p className="text-gray-300"><strong>Code:</strong> {lastScanResult.ticket.ticketCode}</p>
                  </div>
                  
                  {lastScanResult.event && (
                    <div className="bg-gray-800/50 p-3 rounded-lg">
                      <p className="text-gray-300"><strong>Événement:</strong> {lastScanResult.event.title}</p>
                      <p className="text-gray-300"><strong>Date:</strong> {new Date(lastScanResult.event.date).toLocaleDateString('fr-FR')}</p>
                      <p className="text-gray-300"><strong>Lieu:</strong> {lastScanResult.event.venue}</p>
                    </div>
                  )}
                </div>
              )}

              {lastScanResult.alreadyUsed && lastScanResult.usedAt && (
                <Alert className="mt-3 border-orange-500 bg-orange-900/20">
                  <AlertDescription className="text-orange-200">
                    Billet déjà utilisé le {new Date(lastScanResult.usedAt).toLocaleString('fr-FR')}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}