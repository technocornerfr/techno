import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Trash2, Search, AlertTriangle } from "lucide-react";
import { Link } from "wouter";

export default function EventManagement() {
  const { toast } = useToast();
  const { user: currentUser, isAuthenticated } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");

  // Récupérer tous les événements et les filtrer côté client
  const { data: allEvents = [], isLoading } = useQuery({
    queryKey: ["/api/events"],
    enabled: !!(isAuthenticated && currentUser),
  });

  // Filtrer les événements pour ne montrer que ceux créés par l'utilisateur connecté
  const userEmail = currentUser?.email || `${currentUser?.username}@technocorner.local`;
  const events = allEvents.filter((event: any) => event.organizerEmail === userEmail);

  // Mutation pour supprimer un événement
  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: number) => {
      const response = await apiRequest("DELETE", `/api/events/${eventId}`, {
        organizerEmail: currentUser?.email || `${currentUser?.username}@technocorner.local`
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la suppression");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Événement supprimé",
        description: "L'événement a été supprimé avec succès.",
      });
      
      // Rafraîchir la liste des événements
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur de suppression",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Fonction pour gérer la suppression d'un événement
  const handleDeleteEvent = (event: any) => {
    const userEmail = currentUser?.email || `${currentUser?.username}@technocorner.local`;
    
    // Vérifier si l'utilisateur peut supprimer cet événement
    if (event.organizerEmail !== userEmail) {
      toast({
        title: "Action non autorisée",
        description: "Vous ne pouvez supprimer que vos propres événements.",
        variant: "destructive",
      });
      return;
    }

    if (window.confirm(`Êtes-vous sûr de vouloir supprimer l'événement "${event.title}" ? Cette action est irréversible et supprimera également tous les billets associés.`)) {
      deleteEventMutation.mutate(event.id);
    }
  };

  // Filtrer les événements par terme de recherche
  const filteredEvents = events.filter((event: any) =>
    event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.venue.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.organizerEmail.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <Card className="bg-slate-900/50 backdrop-blur-sm border-primary/20">
            <CardHeader>
              <CardTitle className="text-white text-2xl">
                🔒 Connexion requise
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-slate-300 text-lg">
                Vous devez être connecté pour accéder à la gestion des événements
              </p>
              <Link href="/login">
                <Button className="bg-gradient-to-r from-primary to-secondary">
                  Se connecter
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-4">Mes événements</h1>
          <p className="text-slate-400 mb-6">
            Gérez et annulez vos événements créés
          </p>
          
          <div className="flex gap-4 items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Rechercher un événement..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-900/50 border-slate-700 text-white"
              />
            </div>
            <Badge variant="secondary" className="bg-slate-700 text-white">
              {filteredEvents.length} événement{filteredEvents.length !== 1 ? 's' : ''}
            </Badge>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="bg-slate-900/50 backdrop-blur-sm border-slate-700">
                <CardContent className="p-6">
                  <div className="animate-pulse space-y-4">
                    <div className="h-6 bg-slate-700 rounded w-1/3"></div>
                    <div className="h-4 bg-slate-700 rounded w-1/2"></div>
                    <div className="h-4 bg-slate-700 rounded w-1/4"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredEvents.length === 0 ? (
          <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-700">
            <CardContent className="p-12 text-center">
              <AlertTriangle className="w-12 h-12 text-slate-500 mx-auto mb-4" />
              <h3 className="text-white text-xl font-semibold mb-2">Aucun événement trouvé</h3>
              <p className="text-slate-400 mb-4">
                {searchTerm ? "Aucun événement ne correspond à votre recherche." : "Aucun événement disponible."}
              </p>
              <Link href="/create">
                <Button className="bg-primary hover:bg-primary/80">
                  Créer un événement
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredEvents.map((event: any) => {
              const userEmail = currentUser?.email || `${currentUser?.username}@technocorner.local`;
              const canDelete = event.organizerEmail === userEmail;
              
              return (
                <Card key={event.id} className="bg-slate-900/50 backdrop-blur-sm border-slate-700">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-4 mb-2">
                          <h3 className="text-white text-xl font-semibold">
                            {event.title || "Sans titre"}
                          </h3>
                          <Badge 
                            variant={canDelete ? "default" : "secondary"}
                            className={canDelete ? "bg-green-600" : "bg-slate-600"}
                          >
                            {canDelete ? "Votre événement" : "Autre organisateur"}
                          </Badge>
                        </div>
                        
                        <div className="space-y-1 text-slate-300">
                          <p><strong>Date:</strong> {event.date || "Non définie"}</p>
                          <p><strong>Lieu:</strong> {event.venue || "Non défini"}</p>
                          <p><strong>Emplacement:</strong> {event.location || "Non défini"}</p>
                          <p><strong>Prix:</strong> {event.price || "Non défini"}</p>
                          <p><strong>Organisateur:</strong> {event.organizerEmail || "Non défini"}</p>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 ml-4">
                        <Link href={`/event/${event.id}`}>
                          <Button variant="outline" size="sm">
                            Voir
                          </Button>
                        </Link>
                        
                        {canDelete && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteEvent(event)}
                            disabled={deleteEventMutation.isPending}
                            className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:border-red-500/50"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            {deleteEventMutation.isPending ? "Suppression..." : "Supprimer"}
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}