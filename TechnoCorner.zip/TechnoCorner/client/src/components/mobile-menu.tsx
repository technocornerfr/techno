import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Music, X, LogOut, BarChart3, Building, Scan, Settings } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  if (!isOpen) return null;

  // Vérifier l'état de connexion
  const { data: currentUser } = useQuery({
    queryKey: ["/api/auth/current"],
    queryFn: () => apiRequest("GET", "/api/auth/current"),
    retry: false,
  });

  const handleLogout = async () => {
    // Nettoyer le cache immédiatement
    queryClient.clear();
    
    // Faire l'appel de déconnexion en arrière-plan
    try {
      await apiRequest("POST", "/api/auth/logout");
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error);
    }
    
    // Fermer le menu et forcer un rechargement complet de la page
    onClose();
    window.location.reload();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md">
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-between p-4 border-b border-primary/20">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center neon-glow">
              <Music className="text-white text-lg" />
            </div>
            <h1 className="font-mono font-bold text-xl text-white">TechnoCorner</h1>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-300 hover:text-primary">
            <X className="text-xl" />
          </Button>
        </div>
        
        <nav className="flex-1 p-4">
          <ul className="space-y-4">
            <li>
              <Link href="/" onClick={onClose}>
                <span className="block text-lg text-slate-300 hover:text-primary transition-colors py-2">
                  Événements
                </span>
              </Link>
            </li>

            <li>
              <Link href="/community" onClick={onClose}>
                <span className="block text-lg text-slate-300 hover:text-primary transition-colors py-2">
                  Communauté
                </span>
              </Link>
            </li>
            <li>
              <Link href="/about" onClick={onClose}>
                <span className="block text-lg text-slate-300 hover:text-primary transition-colors py-2">
                  À propos
                </span>
              </Link>
            </li>

            
            {currentUser && (
              <li>
                <Link href={`/profile/${currentUser.id}`} onClick={onClose}>
                  <span className="block text-lg text-slate-300 hover:text-primary transition-colors py-2">
                    Profil
                  </span>
                </Link>
              </li>
            )}

            <li>
              <Link href="/organizer" onClick={onClose}>
                <span className="block text-lg text-slate-300 hover:text-secondary transition-colors py-2">
                  <Building className="w-4 h-4 inline mr-2" />
                  Organisateur
                </span>
              </Link>
            </li>



            {currentUser && (
              <li>
                <Link href="/manage-events" onClick={onClose}>
                  <span className="block text-lg text-slate-300 hover:text-primary transition-colors py-2">
                    <Settings className="w-4 h-4 inline mr-2" />
                    Mes événements
                  </span>
                </Link>
              </li>
            )}
            
            {!currentUser && (
              <li>
                <Link href="/login" onClick={onClose}>
                  <span className="block text-lg text-slate-300 hover:text-primary transition-colors py-2">
                    Connexion
                  </span>
                </Link>
              </li>
            )}
            
            <li className="pt-4">
              {currentUser ? (
                <Button 
                  onClick={handleLogout}
                  className="w-full bg-gradient-to-r from-red-500 to-red-600 neon-glow"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Se déconnecter
                </Button>
              ) : (
                <Link href="/register" onClick={onClose}>
                  <Button className="w-full bg-gradient-to-r from-primary to-secondary neon-glow">
                    S'inscrire
                  </Button>
                </Link>
              )}
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
}
