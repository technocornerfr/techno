import { useState } from "react";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, MapPin, Headphones, Heart, Trash2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import type { Event } from "@shared/schema";

interface EventCardProps {
  event: Event;
}

const categoryColors = {
  underground: "bg-accent",
  festival: "bg-secondary", 
  club: "bg-primary",
  workshop: "bg-secondary",
  outdoor: "bg-accent"
};

const categoryLabels = {
  underground: "UNDERGROUND",
  festival: "FESTIVAL",
  club: "CLUB", 
  workshop: "WORKSHOP",
  outdoor: "OUTDOOR"
};

export function EventCard({ event }: EventCardProps) {
  const [isFavorited, setIsFavorited] = useState(false);
  const { user: currentUser, isAuthenticated } = useAuth();
  const { toast } = useToast();

  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsFavorited(!isFavorited);
  };

  // Check if current user owns this event
  const userEmail = currentUser?.email || `${currentUser?.username}@technocorner.local`;
  const isOwner = isAuthenticated && event.organizerEmail === userEmail;

  // Delete event mutation
  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: number) => {
      const response = await apiRequest("DELETE", `/api/events/${eventId}`, {
        organizerEmail: userEmail
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la suppression");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Événement supprimé",
        description: "L'événement a été supprimé avec succès.",
      });
      
      // Refresh events list
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur de suppression",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDeleteEvent = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer l'événement "${event.title}" ? Cette action est irréversible.`)) {
      deleteEventMutation.mutate(event.id);
    }
  };

  return (
    <Link href={`/event/${event.id}`}>
      <Card className="group bg-slate-900/50 backdrop-blur-sm rounded-2xl overflow-hidden border border-primary/20 hover:border-primary/50 transition-all duration-500 hover:scale-105 neon-glow cursor-pointer">
        <div className="relative h-48 overflow-hidden">
          <img 
            src={event.imageUrl || "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"} 
            alt={event.title} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
          <div className="absolute top-4 left-4">
            <span className={`${categoryColors[event.category as keyof typeof categoryColors]} px-3 py-1 rounded-full text-white text-sm font-medium`}>
              {categoryLabels[event.category as keyof typeof categoryLabels]}
            </span>
          </div>
          <div className="absolute top-4 right-4 flex gap-2">
            {isOwner && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleDeleteEvent}
                disabled={deleteEventMutation.isPending}
                className="w-10 h-10 bg-red-900/70 backdrop-blur-sm rounded-full text-red-300 hover:text-red-100 hover:bg-red-800/70 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleFavoriteToggle}
              className="w-10 h-10 bg-slate-900/70 backdrop-blur-sm rounded-full text-slate-300 hover:text-accent transition-colors"
            >
              <Heart className={`w-4 h-4 ${isFavorited ? 'fill-current text-accent' : ''}`} />
            </Button>
          </div>
        </div>
        
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-primary text-sm font-medium mb-2">
            <Calendar className="w-4 h-4" />
            <span>
              {new Date(event.date).toLocaleDateString('fr-FR', { 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric' 
              })}
              {event.time && (
                <span className="text-slate-300 ml-2">
                  à {event.time}
                  {event.endTime && ` - ${event.endTime}`}
                </span>
              )}
              {event.endDate && event.endDate !== event.date && (
                <span className="text-slate-400">
                  {' - '}
                  {new Date(event.endDate).toLocaleDateString('fr-FR', { 
                    day: 'numeric', 
                    month: 'long', 
                    year: 'numeric' 
                  })}
                </span>
              )}
            </span>
          </div>
          
          <h3 className="text-xl font-bold text-white mb-3">{event.title}</h3>
          
          <div className="flex items-center gap-2 text-slate-300 text-sm mb-3">
            <MapPin className="w-4 h-4" />
            <span>{event.venue} - {event.location}</span>
          </div>
          
          <div className="flex items-center gap-2 text-slate-300 text-sm mb-4">
            <Headphones className="w-4 h-4" />
            <span className="truncate">{event.djs.join(", ")}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              {(() => {
                // Nettoyer le prix et vérifier s'il est à 0
                const cleanPrice = event.price?.toString().replace(/[^\d.,]/g, '') || '0';
                const numericPrice = parseFloat(cleanPrice.replace(',', '.'));
                const isFree = numericPrice === 0;
                
                if (event.enableTicketing === "false" || isFree) {
                  return (
                    <div className="text-2xl font-bold text-accent">
                      {isFree ? "Gratuit" : "Gratuit"}
                    </div>
                  );
                } else {
                  return (
                    <>
                      <div className="text-2xl font-bold text-accent">{event.price}</div>
                      {event.pricingTiers && (() => {
                        try {
                          const tiers = JSON.parse(event.pricingTiers);
                          if (tiers.length > 0) {
                            return (
                              <div className="text-xs text-slate-400">
                                {tiers.map((tier: any, index: number) => (
                                  <span key={tier.type}>
                                    {tier.label}: {tier.price}
                                    {index < tiers.length - 1 ? " • " : ""}
                                  </span>
                                ))}
                              </div>
                            );
                          }
                        } catch (e) {
                          return null;
                        }
                        return null;
                      })()}
                    </>
                  );
                }
              })()}
            </div>
            <Button className="bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 neon-glow">
              Voir détails
            </Button>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
