import crypto from 'crypto';
import { storage } from './storage';
import QRCode from 'qrcode';
import type { 
  InsertExternalApiKey, 
  InsertExternalEvent, 
  InsertExternalTicket,
  InsertApiAuditLog,
  ExternalApiKey 
} from '@shared/schema';

// Service pour gérer l'API externe et les intégrations de billetterie
export class ExternalApiService {
  
  // Génère une nouvelle clé API pour un organisateur externe
  async generateApiKey(organizerData: {
    organizerName: string;
    organizerEmail: string;
    organizerWebsite?: string;
    webhookUrl?: string;
    permissions?: string[];
  }): Promise<{ keyId: string; keySecret: string }> {
    const keyId = `tk_${crypto.randomBytes(16).toString('hex')}`;
    const keySecret = crypto.randomBytes(32).toString('hex');
    const hashedSecret = crypto.createHash('sha256').update(keySecret).digest('hex');
    
    const apiKeyData: InsertExternalApiKey = {
      keyId,
      keySecret: hashedSecret,
      organizerName: organizerData.organizerName,
      organizerEmail: organizerData.organizerEmail,
      organizerWebsite: organizerData.organizerWebsite,
      webhookUrl: organizerData.webhookUrl,
      permissions: organizerData.permissions || ['events:create', 'tickets:generate', 'tickets:validate'],
      isActive: true,
      rateLimit: 1000, // 1000 requêtes par heure par défaut
    };
    
    await storage.createApiKey(apiKeyData);
    
    return { keyId, keySecret };
  }
  
  // Vérifie et authentifie une clé API
  async authenticateApiKey(keyId: string, keySecret: string): Promise<ExternalApiKey | null> {
    const apiKey = await storage.getApiKey(keyId);
    if (!apiKey || !apiKey.isActive) {
      return null;
    }
    
    const hashedSecret = crypto.createHash('sha256').update(keySecret).digest('hex');
    if (apiKey.keySecret !== hashedSecret) {
      return null;
    }
    
    // Vérifier la limite de taux
    const usageCount = await storage.getApiUsageStats(apiKey.id, 1); // dernière heure
    if (usageCount >= (apiKey.rateLimit || 1000)) {
      throw new Error('Rate limit exceeded');
    }
    
    // Mettre à jour la dernière utilisation
    await storage.updateApiKeyLastUsed(keyId);
    
    return apiKey;
  }
  
  // Génère un QR code unique pour un billet
  async generateTicketQRCode(ticketData: {
    eventId: string;
    ticketId: string;
    buyerEmail: string;
  }): Promise<string> {
    // Génère un code QR unique et sécurisé
    const timestamp = Date.now();
    const randomBytes = crypto.randomBytes(8).toString('hex');
    const qrData = `${ticketData.eventId}-${ticketData.ticketId}-${timestamp}-${randomBytes}`;
    
    // Hash pour créer un code plus court mais unique
    const qrCode = crypto.createHash('sha256').update(qrData).digest('hex').substring(0, 16).toUpperCase();
    
    return qrCode;
  }
  
  // Génère l'image QR code en base64
  async generateQRCodeImage(qrCode: string): Promise<string> {
    try {
      const qrCodeDataURL = await QRCode.toDataURL(qrCode, {
        errorCorrectionLevel: 'M',
        type: 'image/png',
        margin: 1,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        },
        width: 256
      });
      return qrCodeDataURL;
    } catch (error) {
      throw new Error('Failed to generate QR code image');
    }
  }
  
  // Log une requête API pour l'audit
  async logApiRequest(data: {
    apiKeyId?: number;
    endpoint: string;
    method: string;
    statusCode: number;
    responseTime?: number;
    ipAddress?: string;
    userAgent?: string;
    requestData?: string;
    errorMessage?: string;
  }): Promise<void> {
    const logData: InsertApiAuditLog = {
      apiKeyId: data.apiKeyId,
      endpoint: data.endpoint,
      method: data.method,
      statusCode: data.statusCode,
      responseTime: data.responseTime,
      ipAddress: data.ipAddress,
      userAgent: data.userAgent,
      requestData: data.requestData,
      errorMessage: data.errorMessage,
    };
    
    await storage.logApiRequest(logData);
  }
  
  // Envoie un webhook vers le système externe
  async sendWebhook(webhookUrl: string, eventType: string, data: any): Promise<boolean> {
    try {
      const webhookPayload = {
        event: eventType,
        timestamp: new Date().toISOString(),
        data: data
      };
      
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'TechnoCorner-Webhook/1.0'
        },
        body: JSON.stringify(webhookPayload)
      });
      
      return response.ok;
    } catch (error) {
      console.error('Webhook send error:', error);
      return false;
    }
  }
  
  // Valide les permissions d'une clé API
  hasPermission(apiKey: ExternalApiKey, permission: string): boolean {
    return (apiKey.permissions || []).includes(permission);
  }
}

export const externalApiService = new ExternalApiService();