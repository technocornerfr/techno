import { db } from "./db";
import { sql } from "drizzle-orm";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { posts, users, postLikes, postComments, userFollows, tickets, events } from "@shared/schema";

interface PostScore {
  postId: number;
  score: number;
  reasons: string[];
}

interface UserPreferences {
  preferredGenres: string[];
  preferredContentTypes: string[];
  followedUsers: number[];
  interactionHistory: {
    likedPosts: number[];
    commentedPosts: number[];
    viewedEvents: number[];
  };
}

export class RecommendationService {
  
  // Analyser les préférences utilisateur
  async analyzeUserPreferences(userId: number): Promise<UserPreferences> {
    try {
      // Récupérer les utilisateurs suivis
      const followedUsersResult = await db.execute(sql`
        SELECT following_id 
        FROM user_follows 
        WHERE follower_id = ${userId}
      `);
      
      // Récupérer les posts likés récents
      const likedPostsResult = await db.execute(sql`
        SELECT post_id 
        FROM post_likes 
        WHERE user_id = ${userId}
        LIMIT 50
      `);
      
      // Récupérer les posts commentés récents
      const commentedPostsResult = await db.execute(sql`
        SELECT post_id 
        FROM post_comments 
        WHERE user_id = ${userId}
        LIMIT 25
      `);

      return {
        preferredGenres: ['techno', 'house'], // Genres par défaut pour la musique électronique
        preferredContentTypes: ['text', 'image', 'video', 'music'],
        followedUsers: followedUsersResult.rows.map(row => row.following_id as number),
        interactionHistory: {
          likedPosts: likedPostsResult.rows.map(row => row.post_id as number),
          commentedPosts: commentedPostsResult.rows.map(row => row.post_id as number),
          viewedEvents: []
        }
      };
    } catch (error) {
      console.log("Error in analyzeUserPreferences:", error);
      // Retourner des préférences par défaut en cas d'erreur
      return {
        preferredGenres: ['techno', 'house'],
        preferredContentTypes: ['text', 'image', 'video'],
        followedUsers: [],
        interactionHistory: {
          likedPosts: [],
          commentedPosts: [],
          viewedEvents: []
        }
      };
    }
  }

  // Calculer le score de recommandation pour un post
  async calculatePostScore(postId: number, userId: number, userPreferences: UserPreferences): Promise<PostScore> {
    let score = 10; // Score de base pour que tous les posts aient une chance d'apparaître
    const reasons: string[] = ["Contenu de la communauté"];

    // Récupérer les détails du post
    const postResult = await db.execute(sql`
      SELECT p.*, u.username, u.id as author_id
      FROM posts p
      JOIN users u ON p.user_id = u.id
      WHERE p.id = ${postId}
    `);

    if (!postResult.rows.length) {
      return { postId, score: 0, reasons: [] };
    }

    const post = postResult.rows[0];

    // 1. Score basé sur l'auteur suivi (+30 points)
    if (userPreferences.followedUsers.includes(post.author_id as number)) {
      score += 30;
      reasons.push("Auteur suivi");
    }

    // 2. Score basé sur le type de contenu (+10-20 points)
    if (userPreferences.preferredContentTypes.includes(post.type as string)) {
      score += 15;
      reasons.push("Type de contenu préféré");
    }

    // 3. Score basé sur l'engagement récent (+5-25 points)
    const engagementResult = await db.execute(sql`
      SELECT 
        COUNT(DISTINCT pl.id) as likes_count,
        COUNT(DISTINCT pc.id) as comments_count,
        EXTRACT(EPOCH FROM (NOW() - p.created_at))/3600 as hours_ago
      FROM posts p
      LEFT JOIN post_likes pl ON p.id = pl.post_id
      LEFT JOIN post_comments pc ON p.id = pc.post_id
      WHERE p.id = ${postId}
      GROUP BY p.id, p.created_at
    `);

    if (engagementResult.rows.length) {
      const engagement = engagementResult.rows[0];
      const likesCount = engagement.likes_count as number;
      const commentsCount = engagement.comments_count as number;
      const hoursAgo = engagement.hours_ago as number;

      // Score d'engagement normalisé
      const engagementScore = Math.min(25, (likesCount * 2) + (commentsCount * 3));
      score += engagementScore;
      
      if (engagementScore > 10) {
        reasons.push("Contenu populaire");
      }

      // Bonus pour la fraîcheur (moins de 24h = bonus, plus de 7 jours = malus)
      if (hoursAgo < 24) {
        score += 10;
        reasons.push("Contenu récent");
      } else if (hoursAgo > 168) { // 7 jours
        score -= 5;
      }
    }

    // 4. Score basé sur la similarité avec les posts likés (+5-15 points)
    if (post.type === 'event_share' && post.event_id) {
      const eventSimilarityResult = await db.execute(sql`
        SELECT COUNT(*) as similar_events
        FROM posts p
        JOIN events e ON p.event_id = e.id
        JOIN events current_e ON current_e.id = ${post.event_id}
        WHERE p.id IN (${userPreferences.interactionHistory.likedPosts.length > 0 ? 
          userPreferences.interactionHistory.likedPosts.join(',') : '0'})
        AND e.genre = current_e.genre
      `);

      if (eventSimilarityResult.rows.length && (eventSimilarityResult.rows[0].similar_events as number) > 0) {
        score += 15;
        reasons.push("Genre musical similaire");
      }
    }

    // 5. Score basé sur les interactions passées avec l'auteur (+10 points)
    const authorInteractionResult = await db.execute(sql`
      SELECT COUNT(*) as interactions
      FROM (
        SELECT post_id FROM post_likes WHERE user_id = ${userId}
        UNION
        SELECT post_id FROM post_comments WHERE user_id = ${userId}
      ) user_interactions
      JOIN posts p ON user_interactions.post_id = p.id
      WHERE p.user_id = ${post.author_id}
    `);

    if (authorInteractionResult.rows.length && (authorInteractionResult.rows[0].interactions as number) > 0) {
      score += 10;
      reasons.push("Auteur apprécié");
    }

    // 6. Éviter les posts déjà vus (-20 points)
    if (userPreferences.interactionHistory.likedPosts.includes(postId) ||
        userPreferences.interactionHistory.commentedPosts.includes(postId)) {
      score -= 20;
      reasons.push("Déjà interagi");
    }

    // 7. Score basé sur la diversité du contenu (+5 points)
    // Favoriser légèrement les posts d'utilisateurs moins suivis pour la découverte
    const authorFollowersResult = await db.execute(sql`
      SELECT COUNT(*) as followers_count
      FROM user_follows
      WHERE following_id = ${post.author_id}
    `);

    const followersCount = authorFollowersResult.rows[0]?.followers_count as number || 0;
    if (followersCount < 50) { // Petits comptes = plus de diversité
      score += 5;
      reasons.push("Découverte de nouveau contenu");
    }

    return { postId, score: Math.max(0, score), reasons };
  }

  // Obtenir les recommandations pour un utilisateur
  async getRecommendations(userId: number, limit: number = 20): Promise<any[]> {
    try {
      // Analyser les préférences utilisateur
      const userPreferences = await this.analyzeUserPreferences(userId);

      // Récupérer tous les posts récents avec un algorithme simplifié
      const recommendedPostsResult = await db.execute(sql`
        SELECT 
          p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
          u.username, u.profile_image_url,
          COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked,
          (p.likes_count * 2 + p.comments_count * 3 + 
           CASE WHEN p.created_at >= NOW() - INTERVAL '24 hours' THEN 10 ELSE 0 END) as engagement_score
        FROM posts p 
        LEFT JOIN users u ON p.user_id = u.id 
        LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
        WHERE p.user_id != ${userId}
        ORDER BY engagement_score DESC, p.created_at DESC
        LIMIT ${limit}
      `);

      // Si pas assez de posts avec le scoring, récupérer plus de posts récents
      if (recommendedPostsResult.rows.length < limit) {
        const additionalPostsResult = await db.execute(sql`
          SELECT 
            p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
            u.username, u.profile_image_url,
            COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked
          FROM posts p 
          LEFT JOIN users u ON p.user_id = u.id 
          LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
          WHERE p.user_id != ${userId}
          AND p.id NOT IN (${recommendedPostsResult.rows.length > 0 ? 
            recommendedPostsResult.rows.map(r => r.id).join(',') : '0'})
          ORDER BY p.created_at DESC
          LIMIT ${limit - recommendedPostsResult.rows.length}
        `);
        
        recommendedPostsResult.rows = [...recommendedPostsResult.rows, ...additionalPostsResult.rows];
      }

      // Fallback ultime si aucun post n'est trouvé - inclure les posts de l'utilisateur actuel
      if (recommendedPostsResult.rows.length === 0) {
        const fallbackWithUserPosts = await db.execute(sql`
          SELECT 
            p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
            u.username, u.profile_image_url,
            COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked,
            CASE WHEN p.user_id = ${userId} THEN 5 ELSE 10 END as base_score
          FROM posts p 
          LEFT JOIN users u ON p.user_id = u.id 
          LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
          ORDER BY base_score DESC, p.created_at DESC
          LIMIT ${limit}
        `);
        
        recommendedPostsResult.rows = fallbackWithUserPosts.rows;
      }

      // Récupérer tous les commentaires pour les posts recommandés
      const postIds = recommendedPostsResult.rows.map(row => row.id);
      let commentsByPost: Record<number, any[]> = {};
      
      console.log("=== RECOMMENDATION SERVICE COMMENT FETCHING ===");
      console.log("Post IDs for recommendations:", postIds);
      console.log("Number of posts:", postIds.length);
      
      if (postIds.length > 0) {
        // Use a simple approach to get all comments for recommended posts
        const allCommentsResult = await db.execute(sql`
          SELECT 
            c.id, c.content, c.created_at, c.user_id, c.post_id,
            u.username, u.profile_image_url
          FROM post_comments c
          LEFT JOIN users u ON c.user_id = u.id
          ORDER BY c.created_at ASC
        `);
        
        console.log("Raw comments query result:", allCommentsResult.rows);
        
        // Grouper les commentaires par post
        console.log("All comments fetched:", allCommentsResult.rows.length);
        allCommentsResult.rows.forEach((comment: any) => {
          console.log(`Processing comment for post ${comment.post_id}:`, comment);
          if (!commentsByPost[comment.post_id]) {
            commentsByPost[comment.post_id] = [];
          }
          commentsByPost[comment.post_id].push({
            id: comment.id,
            content: comment.content,
            createdAt: comment.created_at,
            userId: comment.user_id,
            postId: comment.post_id,
            author: {
              id: comment.user_id,
              username: comment.username || "Utilisateur",
              profileImageUrl: comment.profile_image_url || null
            }
          });
        });
        console.log("Comments grouped by post:", commentsByPost);
      }

      // Formatter les résultats avec les commentaires
      const recommendations = recommendedPostsResult.rows.map((row: any) => ({
        id: row.id,
        content: row.content,
        imageUrl: row.image_url,
        type: row.type,
        likesCount: row.likes_count || 0,
        commentsCount: row.comments_count || 0,
        createdAt: row.created_at,
        userId: row.user_id,
        author: {
          id: row.user_id,
          username: row.username || "Utilisateur",
          profileImageUrl: row.profile_image_url
        },
        isLiked: row.is_liked,
        comments: commentsByPost[row.id] || [],
        recommendationScore: row.engagement_score || 10,
        recommendationReasons: ["Contenu populaire", "Algorithme de recommandation"]
      }));

      return recommendations;
    } catch (error) {
      console.error("Error in getRecommendations:", error);
      // En cas d'erreur, utiliser le fallback
      return await this.getFallbackRecommendations(userId, limit);
    }
  }

  // Recommandations de fallback si l'algorithme principal ne trouve rien
  async getFallbackRecommendations(userId: number, limit: number): Promise<any[]> {
    // Stratégie en cascade pour garantir qu'il y ait toujours du contenu
    
    // 1. D'abord essayer les posts populaires récents (excluant l'utilisateur actuel)
    let fallbackResult = await db.execute(sql`
      SELECT 
        p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
        u.username, u.profile_image_url,
        COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked,
        10 as recommendation_score
      FROM posts p 
      LEFT JOIN users u ON p.user_id = u.id 
      LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
      WHERE p.user_id != ${userId}
      AND p.created_at >= NOW() - INTERVAL '30 days'
      ORDER BY (p.likes_count * 2 + p.comments_count * 3) DESC, p.created_at DESC
      LIMIT ${limit}
    `);

    // 2. Si pas assez, ajouter tous les autres posts (excluant l'utilisateur)
    if (fallbackResult.rows.length < limit) {
      const additionalResult = await db.execute(sql`
        SELECT 
          p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
          u.username, u.profile_image_url,
          COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked,
          8 as recommendation_score
        FROM posts p 
        LEFT JOIN users u ON p.user_id = u.id 
        LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
        WHERE p.user_id != ${userId}
        AND p.id NOT IN (${fallbackResult.rows.length > 0 ? fallbackResult.rows.map(r => r.id).join(',') : '0'})
        ORDER BY p.created_at DESC
        LIMIT ${limit - fallbackResult.rows.length}
      `);
      
      fallbackResult.rows = [...fallbackResult.rows, ...additionalResult.rows];
    }

    // 3. Fallback ultime : inclure les posts de l'utilisateur actuel si nécessaire
    if (fallbackResult.rows.length < Math.min(limit, 5)) {
      const userPostsResult = await db.execute(sql`
        SELECT 
          p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
          u.username, u.profile_image_url,
          COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked,
          5 as recommendation_score
        FROM posts p 
        LEFT JOIN users u ON p.user_id = u.id 
        LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
        WHERE p.user_id = ${userId}
        AND p.id NOT IN (${fallbackResult.rows.length > 0 ? fallbackResult.rows.map(r => r.id).join(',') : '0'})
        ORDER BY p.created_at DESC
        LIMIT ${Math.min(limit, 5) - fallbackResult.rows.length}
      `);
      
      fallbackResult.rows = [...fallbackResult.rows, ...userPostsResult.rows];
    }

    // Récupérer les commentaires pour les posts de fallback
    const postIds = fallbackResult.rows.map(row => row.id);
    let commentsByPost: Record<number, any[]> = {};
    
    if (postIds.length > 0) {
      const allCommentsResult = await db.execute(sql`
        SELECT 
          c.id, c.content, c.created_at, c.user_id, c.post_id,
          u.username, u.profile_image_url
        FROM post_comments c
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.post_id IN (${sql.join(postIds.map(id => sql`${id}`), sql`, `)})
        ORDER BY c.created_at ASC
      `);
      
      // Grouper les commentaires par post
      allCommentsResult.rows.forEach((comment: any) => {
        if (!commentsByPost[comment.post_id]) {
          commentsByPost[comment.post_id] = [];
        }
        commentsByPost[comment.post_id].push({
          id: comment.id,
          content: comment.content,
          createdAt: comment.created_at,
          userId: comment.user_id,
          postId: comment.post_id,
          author: {
            id: comment.user_id,
            username: comment.username || "Utilisateur",
            profileImageUrl: comment.profile_image_url || null
          }
        });
      });
    }

    return fallbackResult.rows.map((row: any) => ({
      id: row.id,
      content: row.content,
      imageUrl: row.image_url,
      type: row.type,
      likesCount: row.likes_count || 0,
      commentsCount: row.comments_count || 0,
      createdAt: row.created_at,
      userId: row.user_id,
      author: {
        id: row.user_id,
        username: row.username || "Utilisateur",
        profileImageUrl: row.profile_image_url
      },
      isLiked: row.is_liked,
      comments: commentsByPost[row.id] || [],
      recommendationScore: row.recommendation_score || 5,
      recommendationReasons: row.user_id === userId ? ["Votre contenu"] : ["Contenu communauté"]
    }));
  }

  // Enregistrer une interaction utilisateur pour améliorer les recommandations futures
  async recordInteraction(userId: number, postId: number, interactionType: string, value: number = 1.0): Promise<void> {
    try {
      await db.execute(sql`
        INSERT INTO user_interactions (user_id, post_id, interaction_type, interaction_value)
        VALUES (${userId}, ${postId}, ${interactionType}, ${value})
        ON CONFLICT (user_id, post_id, interaction_type) 
        DO UPDATE SET 
          interaction_value = user_interactions.interaction_value + ${value},
          created_at = NOW()
      `);
    } catch (error) {
      console.log("Erreur lors de l'enregistrement de l'interaction:", error);
      // Ne pas faire échouer l'opération principale
    }
  }
}

export const recommendationService = new RecommendationService();