import { externalApiService } from './external-api-service';

// Utilitaire pour générer des clés API pour les organisateurs externes
// Usage: node -e "require('./server/admin-tools').generateApiKeyForOrganizer({...})"

export async function generateApiKeyForOrganizer(organizerData: {
  organizerName: string;
  organizerEmail: string;
  organizerWebsite?: string;
  webhookUrl?: string;
  permissions?: string[];
}) {
  try {
    console.log('🔑 Génération d\'une nouvelle clé API...');
    console.log('Organisateur:', organizerData.organizerName);
    console.log('Email:', organizerData.organizerEmail);
    
    const { keyId, keySecret } = await externalApiService.generateApiKey({
      organizerName: organizerData.organizerName,
      organizerEmail: organizerData.organizerEmail,
      organizerWebsite: organizerData.organizerWebsite,
      webhookUrl: organizerData.webhookUrl,
      permissions: organizerData.permissions || ['events:create', 'tickets:generate', 'tickets:validate']
    });
    
    console.log('\n✅ Clé API générée avec succès!');
    console.log('=================================');
    console.log('Key ID:', keyId);
    console.log('Key Secret:', keySecret);
    console.log('Token complet:', `${keyId}:${keySecret}`);
    console.log('=================================');
    console.log('\n📋 Headers d\'authentification:');
    console.log(`Authorization: Bearer ${keyId}:${keySecret}`);
    console.log('\n🔒 IMPORTANT: Sauvegardez ces informations en sécurité!');
    console.log('Le secret ne pourra plus être affiché après cette génération.');
    
    return { keyId, keySecret };
  } catch (error) {
    console.error('❌ Erreur lors de la génération de la clé API:', error);
    throw error;
  }
}

// Exemple d'utilisation
if (require.main === module) {
  // Exemple de génération de clé API pour un organisateur
  generateApiKeyForOrganizer({
    organizerName: "Billetterie Demo",
    organizerEmail: "demo@billetterie.com",
    organizerWebsite: "https://demo-billetterie.com",
    webhookUrl: "https://demo-billetterie.com/webhooks/technocorner",
    permissions: ['events:create', 'tickets:generate', 'tickets:validate']
  }).then(() => {
    process.exit(0);
  }).catch((error) => {
    console.error(error);
    process.exit(1);
  });
}