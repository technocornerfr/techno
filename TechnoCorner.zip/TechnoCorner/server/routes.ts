import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import { sql } from "drizzle-orm";
import { insertEventSchema, insertUserSchema, updateUserProfileSchema, insertTicketSchema, insertPostSchema, insertPostCommentSchema, insertPrivateMessageSchema, tickets, events } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { z } from "zod";
import Stripe from "stripe";
import QRCode from "qrcode";
import cookieParser from "cookie-parser";
import htmlPdf from "html-pdf-node";
import { authManager } from "./auth-manager";
import { sendTicketEmail } from "./email-service";
import { externalApiService } from "./external-api-service";
import { eventbriteService } from "./eventbrite-service";
import { recommendationService } from "./recommendation-service-fixed";
import path from "path";
import express from "express";
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Extend Request interface to include session
declare module 'express-serve-static-core' {
  interface Request {
    session?: any;
  }
}

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-05-28.basil",
});

// Variable globale pour stocker l'utilisateur connecté
let globalCurrentUserId: number | null = null;

// Fonction utilitaire pour normaliser l'email organisateur
function getOrganizerEmail(user: any): string {
  return user.email || `${user.username}@technocorner.local`;
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Servir les fichiers statiques pour la PWA
  app.use('/manifest.json', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/manifest.json'));
  });
  
  app.use('/sw.js', (req, res) => {
    res.setHeader('Content-Type', 'application/javascript');
    res.sendFile(path.join(__dirname, '../public/sw.js'));
  });
  
  app.use('/icon-192.svg', (req, res) => {
    res.setHeader('Content-Type', 'image/svg+xml');
    res.sendFile(path.join(__dirname, '../public/icon-192.svg'));
  });
  
  app.use('/icon-512.svg', (req, res) => {
    res.setHeader('Content-Type', 'image/svg+xml');
    res.sendFile(path.join(__dirname, '../public/icon-512.svg'));
  });



  // Simple in-memory session storage - aucune connexion automatique
  let currentUserId: number | null = null;

  // Check current authentication status
  app.get("/api/auth/current", async (req, res) => {
    try {
      // Utiliser AuthManager comme source de vérité
      const userId = authManager.getCurrentUser();
      
      if (!userId) {
        return res.status(401).json({ message: "Non authentifié" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        console.log("Aucun utilisateur trouvé, réinitialisation de l'authentification");
        authManager.clearAuth();
        currentUserId = null;
        globalCurrentUserId = null;
        return res.status(401).json({ message: "Utilisateur non trouvé" });
      }
      
      // Synchroniser toutes les variables
      currentUserId = userId;
      globalCurrentUserId = userId;
      
      // Remove password from response and add organizerEmail
      const { password, ...userWithoutPassword } = user;
      res.json({
        ...userWithoutPassword,
        organizerEmail: getOrganizerEmail(user)
      });
    } catch (error) {
      console.error("Erreur lors de la vérification d'authentification:", error);
      res.status(500).json({ message: "Erreur lors de la vérification de l'authentification" });
    }
  });

  // Test email avec QR code complet
  app.post("/api/test-email-qr", async (req, res) => {
    try {
      const QRCode = await import('qrcode');
      
      // Générer un QR code de test
      const testQrData = {
        ticketId: 999,
        eventId: 83,
        buyerName: "Test QR User",
        buyerEmail: "growthfabriqueparis@gmail.com",
        purchaseDate: new Date().toISOString(),
        eventTitle: "Test Event QR",
        venue: "Test Venue",
        date: "2025-06-07",
        price: "Gratuit",
        ticketCode: "TEST-QR-123",
        type: "test",
        verification: Buffer.from("test-verification").toString('base64')
      };
      
      const qrCodeDataUrl = await QRCode.toDataURL(JSON.stringify(testQrData), {
        width: 300,
        margin: 2,
        color: { dark: '#000000', light: '#ffffff' }
      });
      
      console.log('QR Code généré, taille:', qrCodeDataUrl.length);
      console.log('QR Code preview:', qrCodeDataUrl.substring(0, 100) + '...');
      
      const { sendTicketEmail } = await import('./email-service');
      
      const testData = {
        buyerName: "Test QR User",
        buyerEmail: "growthfabriqueparis@gmail.com",
        eventTitle: "Test Event avec QR Code",
        eventDate: "2025-06-07",
        venue: "Test Venue",
        location: "Paris, France",
        ticketCode: "TEST-QR-123",
        qrCodeDataUrl,
        price: "Gratuit"
      };
      
      const success = await sendTicketEmail(testData);
      res.json({ 
        success, 
        message: success ? "Email avec QR code envoyé" : "Échec envoi email",
        qrCodeLength: qrCodeDataUrl.length,
        qrCodePreview: qrCodeDataUrl.substring(0, 100)
      });
    } catch (error) {
      console.error("Erreur test email QR:", error);
      res.status(500).json({ success: false, error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Sync Eventbrite events
  app.post("/api/sync-eventbrite", async (req, res) => {
    try {
      console.log("🔄 Début de la synchronisation Eventbrite...");
      const count = await eventbriteService.syncElectronicMusicEvents();
      console.log(`✅ Synchronisation terminée: ${count} événements importés`);
      res.json({ 
        success: true, 
        message: `${count} événements Eventbrite synchronisés`,
        count 
      });
    } catch (error) {
      console.error("Erreur lors de la synchronisation Eventbrite:", error);
      res.status(500).json({ 
        success: false, 
        message: "Erreur lors de la synchronisation", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Get all events
  app.get("/api/events", async (req, res) => {
    try {
      const { category, search, sortBy } = req.query;
      
      let events;
      if (search && typeof search === 'string') {
        events = await storage.searchEvents(search);
      } else if (category && typeof category === 'string' && category !== 'all') {
        events = await storage.getEventsByCategory(category);
      } else {
        events = await storage.getAllEvents();
      }
      
      // Apply sorting
      if (sortBy && typeof sortBy === 'string') {
        events = events.sort((a, b) => {
          switch (sortBy) {
            case 'date':
              return new Date(b.date).getTime() - new Date(a.date).getTime();
            case 'popularity':
              return (b.ticketsSold || 0) - (a.ticketsSold || 0);
            case 'price-asc':
              const priceA = a.enableTicketing === 'false' ? 0 : parseFloat(a.price.replace(/[€\s]/g, '').replace(',', '.')) || 0;
              const priceB = b.enableTicketing === 'false' ? 0 : parseFloat(b.price.replace(/[€\s]/g, '').replace(',', '.')) || 0;
              return priceA - priceB;
            case 'price-desc':
              const priceADesc = a.enableTicketing === 'false' ? 0 : parseFloat(a.price.replace(/[€\s]/g, '').replace(',', '.')) || 0;
              const priceBDesc = b.enableTicketing === 'false' ? 0 : parseFloat(b.price.replace(/[€\s]/g, '').replace(',', '.')) || 0;
              return priceBDesc - priceADesc;
            default:
              return 0;
          }
        });
      }
      
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // Get single event
  app.get("/api/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }

      const event = await storage.getEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      res.json(event);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch event" });
    }
  });

  // Create new event
  app.post("/api/events", async (req, res) => {
    // Vérifier si l'utilisateur est connecté
    if (!currentUserId) {
      return res.status(401).json({ 
        message: "Vous devez être connecté pour créer un événement" 
      });
    }

    try {
      console.log("Données reçues pour création d'événement:", JSON.stringify(req.body, null, 2));
      console.log("Type de req.body:", typeof req.body);
      console.log("Headers:", req.headers);
      
      // Récupérer l'utilisateur connecté pour définir l'organisateur
      const user = await storage.getUser(currentUserId);
      if (!user) {
        return res.status(401).json({ message: "Utilisateur non trouvé" });
      }

      const organizerEmail = getOrganizerEmail(user);
      
      // Ajouter la date de création et l'email de l'organisateur
      const eventData = {
        ...req.body,
        organizerEmail,
        createdAt: new Date().toISOString()
      };
      
      console.log("Données avec createdAt et organizerEmail:", JSON.stringify(eventData, null, 2));
      const validatedData = insertEventSchema.parse(eventData);
      console.log("Données validées:", validatedData);
      const event = await storage.createEvent(validatedData);
      res.status(201).json(event);
    } catch (error) {
      console.error("Erreur lors de la création d'événement:", error);
      if (error instanceof z.ZodError) {
        console.error("Erreurs de validation:", error.errors);
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create event" });
    }
  });

  // Delete event (by organizer or admin)
  app.delete("/api/events/:id", async (req, res) => {
    try {
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const eventId = parseInt(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }

      // Récupérer l'utilisateur connecté
      const user = await storage.getUser(currentUserId);
      if (!user) {
        return res.status(401).json({ message: "Utilisateur non trouvé" });
      }

      // Vérifier les droits de suppression - utiliser le username car les utilisateurs n'ont pas d'email
      const userEmail = getOrganizerEmail(user);
      const isOrganizer = event.organizerEmail === userEmail;
      const isAdminMode = req.body?.organizerEmail === "admin@technocorner.local";
      
      if (!isOrganizer && !isAdminMode) {
        console.log(`Suppression refusée: event.organizerEmail=${event.organizerEmail}, userEmail=${userEmail}`);
        return res.status(403).json({ message: "Vous n'êtes pas autorisé à supprimer cet événement" });
      }

      console.log(`Suppression événement ${eventId} par ${isAdminMode ? 'ADMIN' : 'organisateur'} (utilisateur: ${user.username})`);

      // Supprimer d'abord les tickets associés
      await db.execute(sql`DELETE FROM tickets WHERE event_id = ${eventId}`);
      
      // Puis supprimer l'événement
      await db.execute(sql`DELETE FROM events WHERE id = ${eventId}`);

      res.json({ 
        message: "Événement supprimé avec succès",
        deletedBy: isAdminMode ? "admin" : "organizer"
      });
    } catch (error) {
      console.error("Erreur suppression événement:", error);
      res.status(500).json({ message: "Erreur lors de la suppression de l'événement" });
    }
  });

  // Get event statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const events = await storage.getAllEvents();
      const uniqueDjs = new Set();
      const uniqueVenues = new Set();
      
      events.forEach(event => {
        event.djs.forEach(dj => uniqueDjs.add(dj));
        uniqueVenues.add(event.venue);
      });

      res.json({
        events: events.length,
        djs: uniqueDjs.size,
        venues: uniqueVenues.size
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // User registration
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Ce nom d'utilisateur est déjà pris" });
      }

      const user = await storage.createUser(validatedData);
      res.status(201).json({ id: user.id, username: user.username });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Données invalides", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Erreur lors de la création du compte" });
    }
  });

  // User login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Nom d'utilisateur et mot de passe requis" });
      }

      const user = await storage.getUserByUsername(username);
      console.log("Tentative de connexion pour:", username);
      
      if (!user) {
        console.log("Utilisateur non trouvé:", username);
        return res.status(401).json({ message: "Nom d'utilisateur ou mot de passe incorrect" });
      }
      
      if (user.password !== password) {
        console.log("Mot de passe incorrect pour:", username);
        return res.status(401).json({ message: "Nom d'utilisateur ou mot de passe incorrect" });
      }

      // Store user in session
      if (req.session) {
        (req.session as any).user = { id: user.id, username: user.username };
      }
      currentUserId = user.id;
      globalCurrentUserId = user.id;
      authManager.setCurrentUser(user.id);
      console.log("Connexion réussie pour:", username, "ID:", user.id);
      
      res.json({ 
        id: user.id, 
        username: user.username, 
        email: user.email || "", 
        firstName: user.firstName || "", 
        lastName: user.lastName || "",
        organizerEmail: getOrganizerEmail(user)
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la connexion" });
    }
  });

  // User logout
  app.post("/api/auth/logout", async (req, res) => {
    try {
      console.log("Déconnexion demandée, utilisateur actuel:", currentUserId);
      currentUserId = null;
      globalCurrentUserId = null;
      authManager.clearAuth();
      console.log("Déconnexion effectuée, currentUserId maintenant:", currentUserId);
      res.json({ message: "Déconnexion réussie" });
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error);
      res.status(500).json({ message: "Erreur lors de la déconnexion" });
    }
  });

  // Get user profile
  app.get("/api/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      // Remove password from response
      const { password, ...userProfile } = user;
      res.json(userProfile);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération du profil" });
    }
  });

  // Update user profile
  app.put("/api/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      console.log("=== UPDATE PROFILE DEBUG ===");
      console.log("Requested userId:", userId);
      console.log("Current authenticated userId:", currentUserId);
      console.log("AuthManager current user:", authManager.getCurrentUser());
      
      // Utiliser l'AuthManager pour vérifier l'authentification
      const authenticatedUserId = authManager.getCurrentUser();
      
      // Vérifier que l'utilisateur modifie son propre profil
      if (!authenticatedUserId || authenticatedUserId !== userId) {
        console.log("Authorization failed - User not authenticated or wrong user");
        return res.status(403).json({ message: "Non autorisé" });
      }
      
      console.log("Données reçues:", req.body);
      const validatedData = updateUserProfileSchema.parse(req.body);
      console.log("Données validées:", validatedData);
      
      const updatedUser = await storage.updateUserProfile(userId, validatedData);
      
      // Remove password from response
      const { password, ...userProfile } = updatedUser;
      res.json(userProfile);
    } catch (error) {
      console.error("Erreur mise à jour profil complète:", error);
      console.error("Type d'erreur:", error.constructor.name);
      console.error("Message d'erreur:", error.message);
      if (error instanceof z.ZodError) {
        console.error("Erreurs de validation:", error.errors);
        return res.status(400).json({ 
          message: "Données invalides", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Erreur lors de la mise à jour du profil" });
    }
  });

  // ==============================================
  // API POUR ORGANISATEURS EXTERNES
  // ==============================================
  
  // Endpoint pour créer une intention de paiement depuis un site externe
  app.post("/api/external/create-payment-intent", async (req, res) => {
    try {
      const { eventId, organizerApiKey, buyerInfo } = req.body;
      
      if (!eventId || !buyerInfo) {
        return res.status(400).json({ message: "Event ID et informations acheteur requis" });
      }
      
      // Vérifier la clé API de l'organisateur
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }
      
      if (event.organizerApiKey && event.organizerApiKey !== organizerApiKey) {
        return res.status(401).json({ message: "Clé API invalide" });
      }
      
      // Vérifier la disponibilité des billets
      const ticketsSold = event.ticketsSold || 0;
      const ticketsAvailable = event.ticketsAvailable || 0;
      
      if (ticketsSold >= ticketsAvailable) {
        return res.status(400).json({ message: "Événement complet" });
      }
      
      // Nettoyer et convertir le prix
      const cleanPrice = event.price.replace(/[€\s]/g, '').replace(',', '.');
      const ticketPrice = parseFloat(cleanPrice);
      
      if (isNaN(ticketPrice) || ticketPrice <= 0) {
        return res.status(400).json({ message: "Prix du billet invalide" });
      }
      
      // Créer l'intention de paiement Stripe
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(ticketPrice * 100),
        currency: "eur",
        metadata: {
          eventId: eventId.toString(),
          eventTitle: event.title,
          buyerName: buyerInfo.name,
          buyerEmail: buyerInfo.email,
          source: "external"
        }
      });
      
      res.json({ 
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id,
        price: ticketPrice
      });
    } catch (error: any) {
      console.error("Erreur création payment intent externe:", error);
      res.status(500).json({ message: "Erreur lors de la création du paiement: " + error.message });
    }
  });

  // Endpoint pour vérifier la disponibilité des billets en temps réel
  app.get("/api/external/ticket-availability/:eventId", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const { organizerApiKey } = req.query;
      
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }
      
      if (event.organizerApiKey && event.organizerApiKey !== organizerApiKey) {
        return res.status(401).json({ message: "Clé API invalide" });
      }
      
      const available = event.ticketsAvailable ? event.ticketsAvailable - (event.ticketsSold || 0) : null;
      
      res.json({
        eventId,
        eventTitle: event.title,
        ticketsAvailable: event.ticketsAvailable,
        ticketsSold: event.ticketsSold || 0,
        ticketsRemaining: available,
        isAvailable: available === null || available > 0,
        price: event.price
      });
    } catch (error: any) {
      console.error("Erreur vérification disponibilité:", error);
      res.status(500).json({ message: "Erreur lors de la vérification" });
    }
  });

  // Endpoint pour finaliser l'achat depuis un site externe
  app.post("/api/external/confirm-purchase", async (req, res) => {
    try {
      const { paymentIntentId, organizerApiKey } = req.body;
      
      // Vérifier le paiement Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      if (paymentIntent.status !== 'succeeded') {
        return res.status(400).json({ message: "Paiement non confirmé" });
      }

      const metadata = paymentIntent.metadata;
      const eventId = parseInt(metadata.eventId);
      
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }

      if (event.organizerApiKey && event.organizerApiKey !== organizerApiKey) {
        return res.status(401).json({ message: "Clé API invalide" });
      }

      // Créer le billet
      const ticketCode = `${eventId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      const ticketData = {
        eventId,
        userId: 1, // Utilisateur système pour achats externes
        ticketCode,
        price: event.price,
        buyerName: metadata.buyerName,
        buyerEmail: metadata.buyerEmail,
        stripePaymentIntentId: paymentIntentId,
        status: "valid"
      };

      const ticket = await storage.purchaseTicket(ticketData);
      
      res.json({
        success: true,
        ticket: {
          id: ticket.id,
          code: ticket.ticketCode,
          eventTitle: event.title,
          buyerName: ticket.buyerName,
          buyerEmail: ticket.buyerEmail,
          qrCode: ticket.qrCodeData
        }
      });
    } catch (error: any) {
      console.error("Erreur confirmation achat externe:", error);
      res.status(500).json({ message: "Erreur lors de la confirmation: " + error.message });
    }
  });

  // Automatic ticket creation after successful payment
  app.post("/api/complete-purchase", async (req, res) => {
    try {
      const { paymentIntentId } = req.body;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: "Payment Intent ID requis" });
      }

      console.log("=== COMPLETION ACHAT ===");
      console.log("PaymentIntent ID:", paymentIntentId);

      // Vérifier le paiement avec Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status !== 'succeeded') {
        return res.status(400).json({ message: "Paiement non confirmé" });
      }

      console.log("Paiement confirmé, métadonnées:", paymentIntent.metadata);

      // Récupérer les informations depuis les métadonnées Stripe
      const metadata = paymentIntent.metadata;
      const eventId = parseInt(metadata.eventId);
      
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }

      // Générer un code unique pour le billet
      const ticketCode = `TICKET-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

      // Créer les données du QR code
      const qrData = {
        ticketCode,
        eventId,
        eventTitle: event.title,
        buyerName: metadata.buyerName,
        buyerEmail: metadata.buyerEmail,
        eventDate: event.date,
        venue: event.venue,
        location: event.location,
        paymentIntentId,
        generatedAt: new Date().toISOString(),
        verification: Buffer.from(`${ticketCode}-${eventId}-${paymentIntentId}`).toString('base64')
      };

      console.log("Génération QR code pour:", qrData);

      // Générer le QR code
      const qrCodeDataUrl = await QRCode.toDataURL(JSON.stringify(qrData));

      // Créer le billet en base de données
      const ticketData = {
        eventId,
        userId: globalCurrentUserId || 1,
        ticketCode,
        price: event.price,
        buyerName: metadata.buyerName,
        buyerEmail: metadata.buyerEmail,
        qrCodeData: qrCodeDataUrl,
        stripePaymentIntentId: paymentIntentId,
        stripeFee: metadata.stripeFee,
        platformFee: metadata.platformFee,
        organizerAmount: metadata.organizerAmount,
        status: "valid"
      };

      const ticket = await storage.purchaseTicket(ticketData);
      
      console.log("Billet créé avec succès:", ticket.ticketCode);

      // Envoyer le billet par email
      try {
        const emailSent = await sendTicketEmail({
          buyerName: ticket.buyerName,
          buyerEmail: ticket.buyerEmail,
          eventTitle: event.title,
          eventDate: event.date,
          venue: event.venue,
          location: event.location,
          ticketCode: ticket.ticketCode,
          qrCodeDataUrl: qrCodeDataUrl,
          price: ticket.price
        });
        
        if (emailSent) {
          console.log("Email de billet envoyé avec succès");
        } else {
          console.log("Échec de l'envoi d'email");
        }
      } catch (emailError) {
        console.error("Erreur envoi email:", emailError);
      }

      res.json({
        success: true,
        ticket: {
          id: ticket.id,
          code: ticket.ticketCode,
          eventTitle: event.title,
          eventDate: event.date,
          venue: event.venue,
          location: event.location,
          buyerName: ticket.buyerName,
          buyerEmail: ticket.buyerEmail,
          qrCode: qrCodeDataUrl,
          price: ticket.price
        },
        message: "Billet généré avec succès et envoyé par email"
      });
    } catch (error: any) {
      console.error("Erreur completion achat:", error);
      res.status(500).json({ message: "Erreur lors de la génération du billet: " + error.message });
    }
  });

  // Create payment intent for ticket purchase (interne)
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      console.log("=== CREATION PAYMENT INTENT ===");
      console.log("Body reçu:", req.body);
      
      const { eventId, buyerInfo } = req.body;
      
      if (!eventId || !buyerInfo) {
        console.log("Données manquantes:", { eventId, buyerInfo });
        return res.status(400).json({ message: "Event ID et informations acheteur requis" });
      }

      console.log("Recherche événement ID:", eventId);
      const event = await storage.getEvent(eventId);
      if (!event) {
        console.log("Événement non trouvé pour ID:", eventId);
        return res.status(404).json({ message: "Événement non trouvé" });
      }

      console.log("Événement trouvé:", event.title, "Prix:", event.price);

      // Vérifier la disponibilité des billets
      const ticketsSold = event.ticketsSold || 0;
      const ticketsAvailable = event.ticketsAvailable || 0;
      
      console.log("Tickets vendus/disponibles:", ticketsSold, "/", ticketsAvailable);
      
      if (ticketsAvailable > 0 && ticketsSold >= ticketsAvailable) {
        return res.status(400).json({ message: "Plus de billets disponibles" });
      }

      // Nettoyer et convertir le prix
      const cleanPrice = event.price.replace(/[€\s]/g, '').replace(',', '.');
      const ticketPrice = parseFloat(cleanPrice);
      
      console.log("Prix nettoyé:", cleanPrice, "Prix numérique:", ticketPrice);
      
      if (isNaN(ticketPrice) || ticketPrice <= 0) {
        console.log("Prix invalide:", ticketPrice);
        return res.status(400).json({ message: "Prix du billet invalide" });
      }

      const platformFeeRate = 0.025; // 2.5% de commission plateforme
      const stripeFeeRate = 0.029; // 2.9% + 0.30€ commission Stripe standard
      const stripeFeeFixed = 0.30;
      
      const stripeFee = (ticketPrice * stripeFeeRate) + stripeFeeFixed;
      const platformFee = ticketPrice * platformFeeRate;
      const organizerAmount = ticketPrice - stripeFee - platformFee;

      console.log("Calculs financiers:", {
        ticketPrice,
        stripeFee: stripeFee.toFixed(2),
        platformFee: platformFee.toFixed(2),
        organizerAmount: organizerAmount.toFixed(2)
      });

      const paymentIntentData = {
        amount: Math.round(ticketPrice * 100), // Convertir en centimes
        currency: "eur",
        automatic_payment_methods: {
          enabled: true,
        },
        metadata: {
          eventId: eventId.toString(),
          eventTitle: event.title,
          buyerName: buyerInfo.name,
          buyerEmail: buyerInfo.email,
          stripeFee: stripeFee.toFixed(2),
          platformFee: platformFee.toFixed(2),
          organizerAmount: organizerAmount.toFixed(2),
          source: "internal"
        },
      };

      console.log("Création PaymentIntent avec:", paymentIntentData);
      const paymentIntent = await stripe.paymentIntents.create(paymentIntentData);
      console.log("PaymentIntent créé:", paymentIntent.id);

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        breakdown: {
          ticketPrice: ticketPrice.toFixed(2),
          stripeFee: stripeFee.toFixed(2),
          platformFee: platformFee.toFixed(2),
          organizerAmount: organizerAmount.toFixed(2)
        }
      });
    } catch (error: any) {
      console.error("Erreur création payment intent:", error);
      console.error("Stack trace:", error.stack);
      res.status(500).json({ 
        message: "Erreur lors de la création du paiement: " + error.message 
      });
    }
  });

  // Create free ticket with QR code (for 0€ events)
  app.post("/api/free-ticket", async (req, res) => {
    try {
      const { eventId, buyerName, buyerEmail } = req.body;
      
      if (!eventId || !buyerName || !buyerEmail) {
        return res.status(400).json({ message: "Tous les champs sont requis" });
      }

      console.log("=== CRÉATION BILLET GRATUIT ===");
      console.log("Event ID:", eventId, "Buyer:", buyerName, "Email:", buyerEmail);

      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }

      // Vérifier que l'événement est bien gratuit
      const cleanPrice = event.price?.toString().replace(/[^\d.,]/g, '') || '0';
      const numericPrice = parseFloat(cleanPrice.replace(',', '.'));
      
      if (numericPrice !== 0) {
        return res.status(400).json({ message: "Cet événement n'est pas gratuit" });
      }

      if (event.enableTicketing !== "true") {
        return res.status(400).json({ message: "Billetterie non activée pour cet événement" });
      }

      // Vérifier la disponibilité des billets
      const ticketsSold = event.ticketsSold || 0;
      const ticketsAvailable = event.ticketsAvailable || 0;
      
      if (ticketsAvailable > 0 && ticketsSold >= ticketsAvailable) {
        return res.status(400).json({ message: "Événement complet, plus de billets disponibles" });
      }

      // Créer le billet gratuit
      const ticketCode = `FREE-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      
      const ticketData = {
        eventId,
        userId: 1, // Utilisateur système pour billets gratuits
        ticketCode,
        price: "0€",
        buyerName,
        buyerEmail,
        status: "valid"
      };

      const ticket = await storage.purchaseTicket(ticketData);

      // Générer le QR code avec signature cryptographique
      const qrData = {
        ticketId: ticket.id,
        eventId: ticket.eventId,
        buyerName: ticket.buyerName,
        buyerEmail: ticket.buyerEmail,
        purchaseDate: ticket.purchaseDate,
        eventTitle: event.title,
        venue: event.venue,
        date: event.date,
        price: "Gratuit",
        ticketCode: ticket.ticketCode,
        type: "free",
        verification: Buffer.from(`${ticket.id}-${ticket.eventId}-${ticket.ticketCode}-free`).toString('base64')
      };

      const QRCode = await import('qrcode');
      const qrCodeDataUrl = await QRCode.toDataURL(JSON.stringify(qrData), {
        width: 300,
        margin: 2,
        color: { dark: '#000000', light: '#ffffff' }
      });

      console.log('QR Code généré - Taille:', qrCodeDataUrl.length);
      console.log('QR Code début:', qrCodeDataUrl.substring(0, 50));

      // Envoyer le billet par email
      let emailSent = false;
      try {
        const { sendTicketEmail } = await import('./email-service');
        
        const ticketEmailData = {
          buyerName,
          buyerEmail,
          eventTitle: event.title,
          eventDate: event.date,
          venue: event.venue,
          location: event.location,
          ticketCode: ticket.ticketCode,
          qrCodeDataUrl: null, // On utilise maintenant l'URL hébergée
          price: "Gratuit"
        };
        
        console.log('Données email préparées - Code billet:', ticketEmailData.ticketCode);
        
        emailSent = await sendTicketEmail(ticketEmailData);
        if (emailSent) {
          console.log(`Billet gratuit envoyé par email à ${buyerEmail}`);
        } else {
          console.error(`Échec de l'envoi d'email pour le billet gratuit à ${buyerEmail}`);
        }
      } catch (emailError) {
        console.error("Erreur envoi email billet gratuit:", emailError);
        emailSent = false;
      }

      // Stocker temporairement le billet pour affichage immédiat
      const ticketDisplayData = {
        id: ticket.id,
        code: ticket.ticketCode,
        eventTitle: event.title,
        eventDate: event.date,
        venue: event.venue,
        location: event.location,
        buyerName: ticket.buyerName,
        buyerEmail: ticket.buyerEmail,
        qrCode: qrCodeDataUrl,
        price: "Gratuit",
        type: "free",
        downloadUrl: `/api/tickets/${ticket.id}/download`
      };

      const responseMessage = emailSent 
        ? "Billet gratuit généré avec succès et envoyé par email"
        : "Billet gratuit généré avec succès. Votre billet est disponible ci-dessous.";

      res.json({
        success: true,
        ticket: ticketDisplayData,
        message: responseMessage,
        emailSent,
        showTicket: true // Indique à l'interface d'afficher le billet
      });
    } catch (error: any) {
      console.error("Erreur création billet gratuit:", error);
      res.status(500).json({ message: "Erreur lors de la génération du billet gratuit: " + error.message });
    }
  });

  // Purchase ticket (after payment confirmation)
  app.post("/api/purchase-ticket", async (req, res) => {
    try {
      const { paymentIntentId, ...ticketData } = req.body;
      
      // Vérifier le paiement Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      if (paymentIntent.status !== 'succeeded') {
        return res.status(400).json({ message: "Paiement non confirmé" });
      }

      // Récupérer les informations depuis les métadonnées Stripe
      const metadata = paymentIntent.metadata;
      const eventId = parseInt(metadata.eventId);
      
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }

      if (event.enableTicketing !== "true") {
        return res.status(400).json({ message: "Billetterie non activée pour cet événement" });
      }

      const ticketsSold = event.ticketsSold || 0;
      const ticketsAvailable = event.ticketsAvailable || 0;
      
      if (ticketsSold >= ticketsAvailable) {
        return res.status(400).json({ message: "Événement complet, plus de billets disponibles" });
      }

      // Créer le billet avec les informations financières
      const ticketWithFinancials = {
        ...ticketData,
        eventId,
        buyerName: metadata.buyerName,
        buyerEmail: metadata.buyerEmail,
        stripePaymentIntentId: paymentIntentId,
        stripeFee: metadata.stripeFee,
        platformFee: metadata.platformFee,
        organizerAmount: metadata.organizerAmount,
      };

      const ticket = await storage.purchaseTicket(ticketWithFinancials);
      
      // Générer le QR code avec signature cryptographique
      const qrData = {
        ticketId: ticket.id,
        eventId: ticket.eventId,
        buyerName: ticket.buyerName,
        buyerEmail: ticket.buyerEmail,
        purchaseDate: ticket.purchaseDate,
        eventTitle: event.title,
        venue: event.venue,
        date: event.date,
        price: ticket.price,
        ticketCode: ticket.ticketCode,
        // Ajouter un hash pour la sécurité
        verification: Buffer.from(`${ticket.id}-${ticket.eventId}-${ticket.ticketCode}`).toString('base64')
      };
      
      const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(qrData), {
        width: 400,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });

      // Créer l'entrée de payout pour l'organisateur (en attente)
      const organizerPayout = {
        eventId: eventId,
        organizerEmail: event.organizerEmail,
        totalAmount: metadata.organizerAmount,
        status: 'pending' as const
      };
      
      await storage.createOrganizerPayout(organizerPayout);
      
      res.status(201).json({
        ...ticket,
        qrCode: qrCodeDataURL,
        paymentBreakdown: {
          totalPaid: ticket.price,
          stripeFee: metadata.stripeFee,
          platformFee: metadata.platformFee,
          organizerAmount: metadata.organizerAmount
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Données invalides", 
          errors: error.errors 
        });
      }
      console.error("Erreur achat billet:", error);
      res.status(500).json({ message: "Erreur lors de l'achat du billet" });
    }
  });

  // Get user tickets
  app.get("/api/user/:userId/tickets", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const tickets = await storage.getUserTickets(userId);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des billets" });
    }
  });

  // Get event tickets (for organizers)
  app.get("/api/event/:eventId/tickets", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const tickets = await storage.getEventTickets(eventId);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des billets" });
    }
  });

  // Verify ticket by code
  app.get("/api/ticket/:ticketCode", async (req, res) => {
    try {
      const ticket = await storage.getTicketByCode(req.params.ticketCode);
      if (!ticket) {
        return res.status(404).json({ message: "Billet non trouvé" });
      }
      res.json(ticket);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la vérification du billet" });
    }
  });

  // Générer un QR code pour un billet existant
  app.get("/api/tickets/:id/qrcode", async (req, res) => {
    try {
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getTicketByCode(ticketId.toString());
      
      if (!ticket) {
        return res.status(404).json({ message: "Billet non trouvé" });
      }

      const qrData = {
        ticketId: ticket.id,
        eventId: ticket.eventId,
        buyerName: ticket.buyerName,
        buyerEmail: ticket.buyerEmail,
        purchaseDate: ticket.purchaseDate,
        status: ticket.status
      };
      
      const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(qrData));
      
      res.json({ qrCode: qrCodeDataURL });
    } catch (error) {
      console.error("Error generating QR code:", error);
      res.status(500).json({ message: "Erreur lors de la génération du QR code" });
    }
  });

  // Test endpoint pour vérifier l'accessibilité
  app.get("/api/test-access", (req, res) => {
    res.json({ 
      message: "API accessible",
      domain: process.env.REPLIT_DEV_DOMAIN,
      timestamp: new Date().toISOString()
    });
  });

  // Page de diagnostic simple pour tester les liens de billets
  app.get("/api/test-ticket-links", async (req, res) => {
    try {
      const domain = process.env.REPLIT_DEV_DOMAIN || 'localhost:5000';
      
      // Billets de test connus
      const testTickets = [
        'TECHNO-1749298053553-6XENCMOGS',
        'TECHNO-1749294969366-P8SIFHVEY'
      ];

      const html = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Test des liens de billets - TechnoCorner</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            .ticket-test { border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px; }
            .link { display: inline-block; margin: 5px 10px 5px 0; padding: 8px 15px; background: #0066cc; color: white; text-decoration: none; border-radius: 3px; }
            .info { background: #f0f8ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
            .success { background: #e8f5e8; border: 1px solid #4caf50; }
            .warning { background: #fff3cd; border: 1px solid #ffc107; }
          </style>
        </head>
        <body>
          <h1>Test des liens de billets PDF</h1>
          
          <div class="info">
            <strong>Domaine actuel:</strong> ${domain}<br>
            <strong>Mode:</strong> ${process.env.NODE_ENV || 'development'}<br>
            <strong>Test effectué le:</strong> ${new Date().toLocaleString('fr-FR')}
          </div>

          <div class="info success">
            <h3>Fonctionnalité PDF implémentée</h3>
            <p>✅ Page de billet imprimable créée</p>
            <p>✅ QR codes intégrés dans les billets</p>
            <p>✅ Sauvegarde PDF via navigateur (Ctrl+P)</p>
            <p>✅ Liens externes pour emails configurés</p>
          </div>

          <h2>Test des billets récents:</h2>
          
          ${testTickets.map(ticketCode => `
            <div class="ticket-test">
              <h3>Code: ${ticketCode}</h3>
              <div>
                <a href="https://${domain}/api/ticket/${ticketCode}/print" target="_blank" class="link">📄 Lien externe (email)</a>
                <a href="http://localhost:5000/api/ticket/${ticketCode}/print" target="_blank" class="link">🔧 Lien local (test)</a>
              </div>
            </div>
          `).join('')}

          <div class="info warning">
            <h3>Instructions de test:</h3>
            <ul>
              <li><strong>Lien externe:</strong> Utilise le domaine Replit pour simuler l'accès depuis un email</li>
              <li><strong>Lien local:</strong> Accès direct en développement</li>
              <li><strong>Sauvegarde PDF:</strong> Sur la page du billet, Ctrl+P → "Enregistrer au format PDF"</li>
              <li><strong>QR Code:</strong> Vérifiez que le code QR s'affiche correctement</li>
            </ul>
          </div>

          <div class="info">
            <h3>Résolution du problème PDF:</h3>
            <p>Les emails contiennent maintenant un bouton "Ouvrir le billet imprimable" qui mène vers une page optimisée pour l'impression et la sauvegarde PDF via le navigateur. Cette solution évite les dépendances serveur complexes et fonctionne de manière fiable.</p>
          </div>
        </body>
        </html>
      `;

      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(html);

    } catch (error) {
      console.error("Erreur test ticket links:", error);
      res.status(500).send(`
        <html>
          <body style="font-family: Arial, sans-serif; padding: 20px;">
            <h1>Erreur</h1>
            <p>Impossible de charger la page de test: ${error}</p>
          </body>
        </html>
      `);
    }
  });

  // Page de billet imprimable
  app.get("/api/ticket/:ticketCode/print", async (req, res) => {
    try {
      const { ticketCode } = req.params;
      
      const ticket = await storage.getTicketByCode(ticketCode);
      if (!ticket) {
        return res.status(404).send(`
          <html>
            <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
              <h1>Billet non trouvé</h1>
              <p>Le code de billet ${ticketCode} n'existe pas.</p>
            </body>
          </html>
        `);
      }

      const event = await storage.getEvent(ticket.eventId);
      if (!event) {
        return res.status(404).send(`
          <html>
            <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
              <h1>Événement non trouvé</h1>
              <p>L'événement associé à ce billet n'existe plus.</p>
            </body>
          </html>
        `);
      }

      // Générer le QR code
      const qrData = {
        ticketId: ticket.id,
        eventId: ticket.eventId,
        buyerName: ticket.buyerName,
        buyerEmail: ticket.buyerEmail,
        purchaseDate: ticket.purchaseDate,
        status: ticket.status
      };
      
      const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(qrData), {
        width: 200,
        margin: 2
      });

      // Créer la page HTML imprimable
      const ticketHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Billet ${ticketCode} - TechnoCorner</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 0; 
              padding: 20px;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              min-height: 100vh;
            }
            .ticket {
              background: white;
              border-radius: 15px;
              padding: 30px;
              max-width: 600px;
              margin: 0 auto;
              box-shadow: 0 20px 40px rgba(0,0,0,0.1);
              border: 2px dashed #667eea;
            }
            .header {
              text-align: center;
              border-bottom: 2px solid #667eea;
              padding-bottom: 20px;
              margin-bottom: 20px;
            }
            .title {
              font-size: 28px;
              font-weight: bold;
              color: #667eea;
              margin: 0;
            }
            .subtitle {
              color: #666;
              margin: 5px 0 0 0;
            }
            .event-info {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 20px;
              margin: 20px 0;
            }
            .info-group {
              border-left: 3px solid #667eea;
              padding-left: 15px;
            }
            .label {
              font-weight: bold;
              color: #333;
              text-transform: uppercase;
              font-size: 12px;
              letter-spacing: 1px;
            }
            .value {
              color: #555;
              font-size: 16px;
              margin-top: 5px;
            }
            .qr-section {
              text-align: center;
              margin: 30px 0;
              padding: 20px;
              background: #f8f9fa;
              border-radius: 10px;
            }
            .qr-code {
              margin: 10px 0;
            }
            .ticket-code {
              font-size: 18px;
              font-weight: bold;
              color: #667eea;
              letter-spacing: 2px;
              margin-top: 10px;
            }
            .footer {
              text-align: center;
              margin-top: 30px;
              padding-top: 20px;
              border-top: 1px solid #eee;
              color: #666;
              font-size: 14px;
            }
            .important-note {
              background: #fff3cd;
              border: 1px solid #ffeaa7;
              border-radius: 5px;
              padding: 15px;
              margin: 20px 0;
              text-align: center;
            }
            .print-instructions {
              background: #e3f2fd;
              border: 1px solid #2196f3;
              border-radius: 5px;
              padding: 15px;
              margin: 20px 0;
              text-align: center;
            }
            .no-print {
              display: block;
            }
            @media print {
              body {
                background: white !important;
                padding: 0 !important;
              }
              .ticket {
                box-shadow: none !important;
                border: 2px solid #667eea !important;
                margin: 0 !important;
                page-break-inside: avoid;
              }
              .no-print {
                display: none !important;
              }
            }
          </style>
        </head>
        <body>
          <div class="print-instructions no-print">
            <h3>Instructions d'impression</h3>
            <p><strong>Pour sauvegarder en PDF :</strong> Utilisez Ctrl+P (ou Cmd+P sur Mac) puis sélectionnez "Enregistrer au format PDF"</p>
            <p><strong>Pour imprimer :</strong> Utilisez Ctrl+P et sélectionnez votre imprimante</p>
          </div>
          
          <div class="ticket">
            <div class="header">
              <h1 class="title">🎵 TechnoCorner</h1>
              <p class="subtitle">Billet d'entrée officiel</p>
            </div>
            
            <div class="event-info">
              <div class="info-group">
                <div class="label">Événement</div>
                <div class="value">${event.title}</div>
              </div>
              <div class="info-group">
                <div class="label">Date</div>
                <div class="value">${event.date} à ${event.time}</div>
              </div>
              <div class="info-group">
                <div class="label">Lieu</div>
                <div class="value">${event.venue}</div>
              </div>
              <div class="info-group">
                <div class="label">Adresse</div>
                <div class="value">${event.location}</div>
              </div>
              <div class="info-group">
                <div class="label">Titulaire</div>
                <div class="value">${ticket.buyerName}</div>
              </div>
              <div class="info-group">
                <div class="label">Prix</div>
                <div class="value">${ticket.price}</div>
              </div>
            </div>

            <div class="qr-section">
              <div class="label">Code QR de validation</div>
              <div class="qr-code">
                <img src="${qrCodeDataURL}" alt="QR Code" style="width: 200px; height: 200px;">
              </div>
              <div class="ticket-code">${ticket.ticketCode}</div>
            </div>

            <div class="important-note">
              <strong>Important :</strong> Présentez ce QR code à l'entrée de l'événement. 
              Gardez ce billet sur votre téléphone ou imprimez-le.
            </div>

            <div class="footer">
              <p>Billet généré le ${new Date().toLocaleDateString('fr-FR')}</p>
              <p>TechnoCorner - Votre plateforme événementielle de confiance</p>
            </div>
          </div>
        </body>
        </html>
      `;

      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(ticketHtml);

    } catch (error) {
      console.error("Erreur génération page billet:", error);
      res.status(500).send(`
        <html>
          <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
            <h1>Erreur</h1>
            <p>Impossible de générer le billet. Veuillez réessayer plus tard.</p>
          </body>
        </html>
      `);
    }
  });



  // Génération simplifiée de clé API pour les organisateurs
  app.post("/api/organizers/generate-api-key", async (req, res) => {
    try {
      const { organizerName, organizerEmail } = req.body;
      
      // Générer une clé simple pour les tests
      const keyId = `SCANNER-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      res.json({
        success: true,
        apiKey: keyId,
        message: "Clé API générée avec succès pour tests"
      });
    } catch (error) {
      console.error("Erreur génération clé API:", error);
      res.status(500).json({ message: "Erreur lors de la génération de la clé API" });
    }
  });

  // Vérifier un QR code de billet (lecture seule) - accès libre pour tests
  app.post("/api/verify-ticket", async (req, res) => {
    try {
      const { qrData } = req.body;
      
      if (!qrData) {
        return res.status(400).json({ 
          valid: false, 
          message: "QR code manquant" 
        });
      }

      let ticketCode;
      
      // Try to parse as JSON first (for structured QR codes)
      try {
        const ticketInfo = JSON.parse(qrData);
        ticketCode = ticketInfo.ticketCode || ticketInfo.ticketId?.toString();
      } catch {
        // If not JSON, treat as plain text ticket code
        ticketCode = qrData.trim();
      }
      
      const ticket = await storage.getTicketByCode(ticketCode);
      
      if (!ticket) {
        return res.status(404).json({ 
          valid: false, 
          message: "Billet non trouvé" 
        });
      }

      if (ticket.status === "used") {
        return res.status(400).json({ 
          valid: false, 
          message: "Billet déjà utilisé",
          usedAt: ticket.usedAt,
          ticket: ticket
        });
      }

      if (ticket.status !== "valid") {
        return res.status(400).json({ 
          valid: false, 
          message: "Billet non valide" 
        });
      }

      const event = await storage.getEvent(ticket.eventId);
      
      res.json({
        valid: true,
        ticket: ticket,
        event: event,
        message: "Billet valide"
      });
    } catch (error) {
      console.error("Error verifying ticket:", error);
      res.status(400).json({ 
        valid: false, 
        message: "QR code invalide" 
      });
    }
  });

  // Scanner API endpoint for validation
  app.post("/api/scanner/validate", async (req, res) => {
    try {
      const { qrData, scannerId, location } = req.body;
      
      if (!qrData) {
        return res.status(400).json({ 
          valid: false, 
          message: "QR code manquant" 
        });
      }

      let ticketCode;
      
      // Try to parse as JSON first (for structured QR codes)
      try {
        const ticketInfo = JSON.parse(qrData);
        ticketCode = ticketInfo.ticketCode || ticketInfo.ticketId?.toString();
      } catch {
        // If not JSON, treat as plain text ticket code
        ticketCode = qrData.trim();
      }
      
      const ticket = await storage.getTicketByCode(ticketCode);
      
      if (!ticket) {
        return res.status(404).json({ 
          valid: false, 
          message: "Billet non trouvé" 
        });
      }

      if (ticket.status === "used") {
        return res.status(400).json({ 
          valid: false, 
          message: "Billet déjà utilisé",
          alreadyUsed: true,
          usedAt: ticket.usedAt,
          ticket: ticket
        });
      }

      if (ticket.status !== "valid") {
        return res.status(400).json({ 
          valid: false, 
          message: "Billet non valide" 
        });
      }

      // Mark ticket as used
      await storage.updateTicketStatus(ticket.id, "used");
      
      const event = await storage.getEvent(ticket.eventId);
      
      res.json({
        valid: true,
        validated: true,
        ticket: ticket,
        event: event,
        message: "Billet validé avec succès"
      });
    } catch (error) {
      console.error("Error validating ticket:", error);
      res.status(400).json({ 
        valid: false, 
        message: "Erreur de validation" 
      });
    }
  });

  // Valider un billet à l'entrée (marque comme utilisé) - accès libre pour tests
  app.post("/api/validate-ticket", async (req, res) => {
    try {
      const { qrData, validatorId, location } = req.body;
      const ticketInfo = JSON.parse(qrData);
      
      const ticket = await storage.getTicketByCode(ticketInfo.ticketCode || ticketInfo.ticketId?.toString());
      
      if (!ticket) {
        return res.status(404).json({ 
          valid: false, 
          message: "Billet non trouvé" 
        });
      }

      // Vérifier si déjà utilisé
      if (ticket.status === "used") {
        const usedAt = ticket.usedAt ? new Date(ticket.usedAt).toLocaleString('fr-FR') : 'Date inconnue';
        return res.status(400).json({ 
          valid: false, 
          message: `Billet déjà utilisé le ${usedAt}`,
          alreadyUsed: true,
          usedAt: ticket.usedAt,
          ticket: ticket
        });
      }

      // Vérifier si valide
      if (ticket.status !== "valid") {
        return res.status(400).json({ 
          valid: false, 
          message: "Billet non valide" 
        });
      }

      // Marquer comme utilisé
      const updatedTicket = await storage.updateTicketStatus(ticket.id, "used");
      
      // Mettre à jour la date d'utilisation
      await db.execute(sql`
        UPDATE tickets 
        SET used_at = NOW(), validator_id = ${validatorId || 'system'}
        WHERE id = ${ticket.id}
      `);

      const event = await storage.getEvent(ticket.eventId);
      
      res.json({
        valid: true,
        validated: true,
        ticket: {
          ...updatedTicket,
          usedAt: new Date().toISOString(),
          validatorId: validatorId || 'system'
        },
        event: event,
        message: "Billet validé avec succès"
      });
    } catch (error) {
      console.error("Error validating ticket:", error);
      res.status(500).json({ 
        valid: false, 
        message: "Erreur lors de la validation" 
      });
    }
  });

  // Community/Feed routes
  
  // Get recommended posts (engagement-based feed)
  app.get("/api/posts/recommended", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      
      if (currentUserId) {
        // Pour les utilisateurs authentifiés, utiliser l'algorithme de recommandation
        console.log(`=== Getting recommendations for user ${currentUserId} ===`);
        
        // Récupérer les posts recommandés avec l'algorithme simplifié
        const recommendedPostsResult = await db.execute(sql`
          SELECT 
            p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
            u.username, u.profile_image_url,
            COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked,
            (p.likes_count * 2 + p.comments_count * 3 + 
             CASE WHEN p.created_at >= NOW() - INTERVAL '24 hours' THEN 10 ELSE 0 END) as engagement_score
          FROM posts p 
          LEFT JOIN users u ON p.user_id = u.id 
          LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${currentUserId}
          WHERE p.user_id != ${currentUserId}
          ORDER BY engagement_score DESC, p.created_at DESC
          LIMIT ${limit}
        `);

        // Récupérer tous les commentaires comme dans l'API posts normale
        const allCommentsResult = await db.execute(sql`
          SELECT 
            c.id, c.content, c.created_at, c.user_id, c.post_id,
            u.username, u.profile_image_url
          FROM post_comments c
          LEFT JOIN users u ON c.user_id = u.id
          ORDER BY c.created_at ASC
        `);
        
        // Grouper les commentaires par post
        const commentsByPost: Record<number, any[]> = {};
        allCommentsResult.rows.forEach((comment: any) => {
          if (!commentsByPost[comment.post_id]) {
            commentsByPost[comment.post_id] = [];
          }
          commentsByPost[comment.post_id].push({
            id: comment.id,
            content: comment.content,
            createdAt: comment.created_at,
            userId: comment.user_id,
            postId: comment.post_id,
            author: {
              id: comment.user_id,
              username: comment.username || "Utilisateur",
              profileImageUrl: comment.profile_image_url || null
            }
          });
        });

        const formattedPosts = recommendedPostsResult.rows.map((row: any) => {
          const comments = commentsByPost[row.id] || [];
          console.log(`Post ${row.id} has ${comments.length} comments`);

          return {
            id: row.id,
            content: row.content,
            imageUrl: row.image_url || null,
            type: row.type || 'text',
            likesCount: row.likes_count || 0,
            commentsCount: row.comments_count || 0,
            createdAt: row.created_at,
            userId: row.user_id,
            author: {
              id: row.user_id,
              username: row.username || "Utilisateur",
              profileImageUrl: row.profile_image_url || null
            },
            isLiked: row.is_liked,
            comments: comments,
            recommendationScore: row.engagement_score || 10,
            recommendationReasons: ["Contenu populaire", "Algorithme de recommandation"]
          };
        });
        
        console.log(`Found ${formattedPosts.length} recommendations`);
        res.json(formattedPosts);
      } else {
        // Pour les utilisateurs non authentifiés, afficher les posts triés par engagement
        const engagementBasedPosts = await db.execute(sql`
          SELECT 
            p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
            u.username, u.profile_image_url,
            false as is_liked,
            (COALESCE(p.likes_count, 0) * 2 + COALESCE(p.comments_count, 0) * 3 + 
             CASE WHEN p.created_at >= NOW() - INTERVAL '24 hours' THEN 10 ELSE 0 END) as engagement_score
          FROM posts p 
          LEFT JOIN users u ON p.user_id = u.id 
          ORDER BY engagement_score DESC, p.created_at DESC
          LIMIT ${limit}
        `);

        // Récupérer tous les commentaires
        const allCommentsResult = await db.execute(sql`
          SELECT 
            c.id, c.content, c.created_at, c.user_id, c.post_id,
            u.username, u.profile_image_url
          FROM post_comments c
          LEFT JOIN users u ON c.user_id = u.id
          ORDER BY c.created_at ASC
        `);
        
        // Grouper les commentaires par post
        const commentsByPost: Record<number, any[]> = {};
        allCommentsResult.rows.forEach((comment: any) => {
          if (!commentsByPost[comment.post_id]) {
            commentsByPost[comment.post_id] = [];
          }
          commentsByPost[comment.post_id].push({
            id: comment.id,
            content: comment.content,
            createdAt: comment.created_at,
            userId: comment.user_id,
            postId: comment.post_id,
            author: {
              id: comment.user_id,
              username: comment.username || "Utilisateur",
              profileImageUrl: comment.profile_image_url || null
            }
          });
        });

        const formattedPosts = engagementBasedPosts.rows.map((row: any) => ({
          id: row.id,
          content: row.content,
          imageUrl: row.image_url,
          type: row.type,
          likesCount: row.likes_count || 0,
          commentsCount: row.comments_count || 0,
          createdAt: row.created_at,
          userId: row.user_id,
          author: {
            id: row.user_id,
            username: row.username || "Utilisateur",
            profileImageUrl: row.profile_image_url
          },
          isLiked: false,
          comments: commentsByPost[row.id] || []
        }));

        res.json(formattedPosts);
      }
    } catch (error) {
      console.error("Error getting recommendations:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des recommandations" });
    }
  });

  // Record user interaction for recommendation learning
  app.post("/api/posts/:postId/interaction", async (req, res) => {
    if (!currentUserId) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const postId = parseInt(req.params.postId);
      const { type, value = 1.0 } = req.body;
      
      console.log(`Recording interaction: user ${currentUserId}, post ${postId}, type ${type}`);
      
      await recommendationService.recordInteraction(currentUserId, postId, type, value);
      res.json({ success: true });
    } catch (error) {
      console.error("Error recording interaction:", error);
      res.status(500).json({ message: "Erreur lors de l'enregistrement de l'interaction" });
    }
  });
  
  // Get all posts for feed
  app.get("/api/posts", async (req, res) => {
    try {
      console.log("=== GET /api/posts called ===");
      
      // Requête directe pour récupérer les posts avec leurs auteurs
      const result = await db.execute(sql`
        SELECT 
          p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
          u.username, u.profile_image_url
        FROM posts p 
        LEFT JOIN users u ON p.user_id = u.id 
        ORDER BY p.created_at DESC
      `);
      
      console.log("Raw SQL results:", result.rows);
      
      // D'abord récupérer tous les commentaires
      const allCommentsResult = await db.execute(sql`
        SELECT 
          c.id, c.content, c.created_at, c.user_id, c.post_id,
          u.username, u.profile_image_url
        FROM post_comments c
        LEFT JOIN users u ON c.user_id = u.id
        ORDER BY c.created_at ASC
      `);
      
      console.log("All comments:", allCommentsResult.rows);
      
      // Grouper les commentaires par post
      const commentsByPost: Record<number, any[]> = {};
      allCommentsResult.rows.forEach((comment: any) => {
        if (!commentsByPost[comment.post_id]) {
          commentsByPost[comment.post_id] = [];
        }
        commentsByPost[comment.post_id].push({
          id: comment.id,
          content: comment.content,
          createdAt: comment.created_at,
          userId: comment.user_id,
          postId: comment.post_id,
          author: {
            id: comment.user_id,
            username: comment.username || "Utilisateur",
            profileImageUrl: comment.profile_image_url || null
          }
        });
      });

      const formattedPosts = result.rows.map((row: any) => {
        const comments = commentsByPost[row.id] || [];
        console.log(`Post ${row.id} has ${comments.length} comments`);
        
        if (row.id === 1 && comments.length > 0) {
          console.log("Post 1 comments detail:", JSON.stringify(comments, null, 2));
        }

        return {
          id: row.id,
          content: row.content,
          imageUrl: row.image_url || null,
          type: row.type || 'text',
          likesCount: row.likes_count || 0,
          commentsCount: row.comments_count || 0,
          createdAt: row.created_at,
          userId: row.user_id,
          author: {
            id: row.user_id,
            username: row.username || "Utilisateur",
            profileImageUrl: row.profile_image_url || null
          },
          isLiked: false,
          comments: comments
        };
      });
      
      // Test JSON serialization of post 1
      const post1 = formattedPosts.find(p => p.id === 1);
      if (post1) {
        console.log("Post 1 JSON test:", JSON.stringify(post1, null, 2));
      }
      
      res.json(formattedPosts);
    } catch (error) {
      console.error("Error in GET /api/posts:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des posts" });
    }
  });

  // Get posts by user ID
  app.get("/api/posts/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      console.log(`=== Fetching posts for user ${userId} ===`);
      
      const posts = await storage.getUserPosts(userId);
      console.log("User posts from storage (final):", posts);

      res.json(posts);
    } catch (error) {
      console.error("Error fetching user posts:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des posts" });
    }
  });

  // Create a new post
  app.post("/api/posts", async (req, res) => {
    if (!currentUserId) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const { content, imageUrl, mediaFiles, type = 'text' } = req.body;
      
      // Allow posts with either content or media files
      if (!content?.trim() && !imageUrl && (!mediaFiles || mediaFiles.length === 0)) {
        return res.status(400).json({ message: "Le contenu ou des fichiers médias sont requis" });
      }

      // If we have media files, use the first one as imageUrl for now
      let finalImageUrl = imageUrl;
      let mediaType = 'text';
      
      if (mediaFiles && mediaFiles.length > 0) {
        finalImageUrl = mediaFiles[0]; // Store as base64 for now
        
        // Détecter le type de média basé sur le préfixe base64
        if (finalImageUrl.startsWith('data:video/')) {
          mediaType = 'video';
        } else if (finalImageUrl.startsWith('data:image/')) {
          mediaType = 'image';
        } else {
          mediaType = 'image'; // Par défaut pour les autres médias
        }
      } else if (finalImageUrl) {
        mediaType = 'image';
      }

      console.log(`Creating post with type: ${mediaType}, hasMedia: ${!!finalImageUrl}`);

      const post = await storage.createPost({
        content: content?.trim() || '', // Allow empty content if there are media files
        imageUrl: finalImageUrl || null,
        type: mediaType,
        userId: currentUserId,
      });

      res.status(201).json(post);
    } catch (error) {
      console.error("Error creating post:", error);
      res.status(500).json({ message: "Erreur lors de la création du post" });
    }
  });

  // Delete a post (only by the author)
  app.delete("/api/posts/:id", async (req, res) => {
    if (!currentUserId) {
      console.log("DELETE POST: User not authenticated");
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const postId = parseInt(req.params.id);
      console.log(`DELETE POST: Attempting to delete post ${postId} by user ${currentUserId}`);
      
      // Vérifier que l'utilisateur est propriétaire du post
      const postCheck = await db.execute(sql`
        SELECT id FROM posts 
        WHERE id = ${postId} AND user_id = ${currentUserId}
      `);
      
      console.log(`DELETE POST: Post check result:`, postCheck.rows);
      
      if (postCheck.rows.length === 0) {
        console.log(`DELETE POST: Post ${postId} not found or access denied for user ${currentUserId}`);
        return res.status(403).json({ message: "Post non trouvé ou accès non autorisé" });
      }
      
      // Supprimer les likes, commentaires et le post
      await db.execute(sql`DELETE FROM post_likes WHERE post_id = ${postId}`);
      await db.execute(sql`DELETE FROM post_comments WHERE post_id = ${postId}`);
      await db.execute(sql`DELETE FROM posts WHERE id = ${postId}`);
      
      console.log(`DELETE POST: Successfully deleted post ${postId}`);
      res.json({ message: "Post supprimé avec succès" });
    } catch (error) {
      console.error("Error deleting post:", error);
      res.status(500).json({ message: "Erreur lors de la suppression du post" });
    }
  });

  // Like a post
  app.post("/api/posts/:id/like", async (req, res) => {
    if (!currentUserId) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const postId = parseInt(req.params.id);
      
      // Check if already liked with direct SQL
      const existingLike = await db.execute(sql`
        SELECT id FROM post_likes 
        WHERE post_id = ${postId} AND user_id = ${currentUserId}
      `);
      
      if (existingLike.rows.length > 0) {
        // Unlike - remove like and decrease count
        await db.execute(sql`
          DELETE FROM post_likes 
          WHERE post_id = ${postId} AND user_id = ${currentUserId}
        `);
        await db.execute(sql`
          UPDATE posts 
          SET likes_count = likes_count - 1 
          WHERE id = ${postId}
        `);
        res.json({ message: "Post unliké" });
      } else {
        // Like - add like and increase count
        await db.execute(sql`
          INSERT INTO post_likes (post_id, user_id) 
          VALUES (${postId}, ${currentUserId})
        `);
        await db.execute(sql`
          UPDATE posts 
          SET likes_count = likes_count + 1 
          WHERE id = ${postId}
        `);
        res.json({ message: "Post liké" });
      }
    } catch (error) {
      console.error("Error liking/unliking post:", error);
      res.status(500).json({ message: "Erreur lors du like/unlike" });
    }
  });

  // Get comments for a post
  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      console.log(`=== Getting comments for post ${postId} ===`);
      
      const result = await db.execute(sql`
        SELECT 
          c.id, c.content, c.created_at, c.user_id,
          u.username, u.profile_image_url
        FROM post_comments c 
        LEFT JOIN users u ON c.user_id = u.id 
        WHERE c.post_id = ${postId}
        ORDER BY c.created_at ASC
      `);
      
      const formattedComments = result.rows.map((row: any) => ({
        id: row.id,
        content: row.content,
        createdAt: row.created_at,
        userId: row.user_id,
        author: {
          id: row.user_id,
          username: row.username || 'Utilisateur',
          profileImageUrl: row.profile_image_url
        }
      }));
      
      console.log(`Found ${formattedComments.length} comments for post ${postId}:`, formattedComments);
      res.json(formattedComments);
    } catch (error) {
      console.error("Error getting comments:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des commentaires" });
    }
  });

  // Add comment to a post
  app.post("/api/posts/:id/comments", async (req, res) => {
    if (!currentUserId) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const postId = parseInt(req.params.id);
      const { content } = req.body;
      
      if (!content?.trim()) {
        return res.status(400).json({ message: "Le contenu du commentaire est requis" });
      }

      const comment = await storage.addComment({
        postId,
        content: content.trim(),
        userId: currentUserId,
      });

      res.status(201).json(comment);
    } catch (error) {
      console.error("Error adding comment:", error);
      res.status(500).json({ message: "Erreur lors de l'ajout du commentaire" });
    }
  });

  // Delete a comment (only by the author)
  app.delete("/api/comments/:id", async (req, res) => {
    if (!currentUserId) {
      console.log("DELETE COMMENT: User not authenticated");
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const commentId = parseInt(req.params.id);
      console.log(`DELETE COMMENT: Attempting to delete comment ${commentId} by user ${currentUserId}`);
      
      // Récupérer les informations du commentaire pour mettre à jour le compteur du post
      const commentInfo = await db.execute(sql`
        SELECT id, post_id FROM post_comments 
        WHERE id = ${commentId} AND user_id = ${currentUserId}
      `);
      
      console.log(`DELETE COMMENT: Comment check result:`, commentInfo.rows);
      
      if (commentInfo.rows.length === 0) {
        console.log(`DELETE COMMENT: Comment ${commentId} not found or access denied for user ${currentUserId}`);
        return res.status(403).json({ message: "Commentaire non trouvé ou accès non autorisé" });
      }
      
      const postId = commentInfo.rows[0].post_id;
      
      // Supprimer le commentaire
      await db.execute(sql`DELETE FROM post_comments WHERE id = ${commentId}`);
      
      // Mettre à jour le compteur de commentaires du post
      await db.execute(sql`
        UPDATE posts 
        SET comments_count = (
          SELECT COUNT(*) FROM post_comments WHERE post_id = ${postId}
        )
        WHERE id = ${postId}
      `);
      
      console.log(`DELETE COMMENT: Successfully deleted comment ${commentId} and updated post ${postId} comment count`);
      res.json({ message: "Commentaire supprimé avec succès" });
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ message: "Erreur lors de la suppression du commentaire" });
    }
  });

  // Analytics pour organisateurs - Dashboard en temps réel
  app.get("/api/analytics/organizer/:organizerEmail", async (req, res) => {
    try {
      const { organizerEmail } = req.params;
      
      // Récupérer tous les événements de cet organisateur
      const organizerEvents = await db.execute(sql`
        SELECT * FROM events 
        WHERE organizer_email = ${organizerEmail}
        ORDER BY created_at DESC
      `);

      // Calculer les KPIs globaux
      let totalRevenue = 0;
      let totalTicketsSold = 0;
      let totalEvents = organizerEvents.rows.length;
      let upcomingEvents = 0;
      let pastEvents = 0;

      const eventAnalytics = [];
      const now = new Date();

      for (const event of organizerEvents.rows) {
        const eventDate = new Date(event.date);
        const isUpcoming = eventDate > now;
        
        if (isUpcoming) upcomingEvents++;
        else pastEvents++;

        // Calculer revenus pour cet événement
        const ticketsSold = event.tickets_sold || 0;
        totalTicketsSold += ticketsSold;
        
        // Parse price pour calculer revenus
        const priceStr = event.price || "0";
        const price = parseFloat(priceStr.replace(/[€\s]/g, '')) || 0;
        const eventRevenue = ticketsSold * price;
        totalRevenue += eventRevenue;

        // Calculer taux de conversion
        const conversionRate = event.tickets_available > 0 
          ? (ticketsSold / event.tickets_available) * 100 
          : 0;

        eventAnalytics.push({
          id: event.id,
          title: event.title,
          date: event.date,
          venue: event.venue,
          ticketsSold: ticketsSold,
          ticketsAvailable: event.tickets_available,
          revenue: eventRevenue,
          conversionRate: Math.round(conversionRate),
          status: isUpcoming ? 'upcoming' : 'past'
        });
      }

      // Ventes par mois (12 derniers mois)
      const salesByMonth = await db.execute(sql`
        SELECT 
          DATE_TRUNC('month', purchase_date) as month,
          COUNT(*) as ticket_count,
          SUM(CAST(REPLACE(REPLACE(price, '€', ''), ' ', '') AS DECIMAL)) as revenue
        FROM tickets t
        JOIN events e ON t.event_id = e.id
        WHERE e.organizer_email = ${organizerEmail}
          AND t.purchase_date >= NOW() - INTERVAL '12 months'
        GROUP BY DATE_TRUNC('month', purchase_date)
        ORDER BY month
      `);

      res.json({
        globalKPIs: {
          totalRevenue: Math.round(totalRevenue),
          totalTicketsSold,
          totalEvents,
          upcomingEvents,
          pastEvents,
          averageTicketsPerEvent: totalEvents > 0 ? Math.round(totalTicketsSold / totalEvents) : 0
        },
        eventAnalytics,
        salesByMonth: salesByMonth.rows.map(row => ({
          month: row.month,
          ticketCount: parseInt(row.ticket_count),
          revenue: parseFloat(row.revenue) || 0
        }))
      });
    } catch (error) {
      console.error("Erreur analytics:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des analytics" });
    }
  });

  // Analytics détaillées pour un événement spécifique
  app.get("/api/analytics/event/:eventId", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      
      // Vérifier que l'utilisateur est bien l'organisateur
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const [event] = await db.execute(sql`
        SELECT * FROM events WHERE id = ${eventId}
      `);

      if (!event.rows.length) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }

      // Ventes par jour pour cet événement
      const salesPerDay = await db.execute(sql`
        SELECT 
          DATE(purchase_date) as date,
          COUNT(*) as tickets_sold,
          SUM(CAST(REPLACE(REPLACE(price, '€', ''), ' ', '') AS DECIMAL)) as daily_revenue
        FROM tickets 
        WHERE event_id = ${eventId}
        GROUP BY DATE(purchase_date)
        ORDER BY date
      `);

      // Top hours des ventes
      const salesByHour = await db.execute(sql`
        SELECT 
          EXTRACT(HOUR FROM purchase_date) as hour,
          COUNT(*) as tickets_sold
        FROM tickets 
        WHERE event_id = ${eventId}
        GROUP BY EXTRACT(HOUR FROM purchase_date)
        ORDER BY tickets_sold DESC
        LIMIT 5
      `);

      res.json({
        event: event.rows[0],
        salesPerDay: salesPerDay.rows,
        topSalesHours: salesByHour.rows
      });
    } catch (error) {
      console.error("Erreur analytics événement:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des analytics" });
    }
  });

  // Routes pour le feed communautaire (legacy)
  app.get("/api/feed", async (req, res) => {
    try {
      // Pour l'instant retourner un feed vide en attendant l'implémentation complète
      res.json([]);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération du feed" });
    }
  });

  app.post("/api/posts", async (req, res) => {
    try {
      // Simulation de création de post pour l'instant
      const post = {
        id: Date.now(),
        ...req.body,
        likesCount: 0,
        repostsCount: 0,
        commentsCount: 0,
        createdAt: new Date().toISOString(),
      };
      res.status(201).json(post);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la création du post" });
    }
  });

  // Routes pour la gestion des paiements aux organisateurs
  
  // Récupérer les paiements en attente pour un organisateur
  app.get("/api/organizer/payouts/:organizerEmail", async (req, res) => {
    try {
      const organizerEmail = req.params.organizerEmail;
      const payouts = await storage.getOrganizerPayouts(organizerEmail);
      res.json(payouts);
    } catch (error) {
      console.error("Erreur récupération payouts:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des paiements" });
    }
  });

  // Traiter un paiement à un organisateur (admin uniquement)
  app.post("/api/admin/process-payout", async (req, res) => {
    try {
      const { payoutId, organizerEmail, amount } = req.body;
      
      // Dans un vrai système, ici on ferait un transfert Stripe Connect
      // Pour l'instant, on marque simplement comme traité
      const payout = await storage.updatePayoutStatus(
        payoutId, 
        'completed',
        `simulated_transfer_${Date.now()}`
      );
      
      res.json({
        success: true,
        payout,
        message: `Paiement de ${amount}€ traité pour ${organizerEmail}`
      });
    } catch (error) {
      console.error("Erreur traitement payout:", error);
      res.status(500).json({ message: "Erreur lors du traitement du paiement" });
    }
  });

  // Obtenir tous les paiements en attente (admin uniquement)
  app.get("/api/admin/pending-payouts", async (req, res) => {
    try {
      const pendingPayouts = await storage.getPendingPayouts();
      res.json(pendingPayouts);
    } catch (error) {
      console.error("Erreur récupération payouts en attente:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des paiements en attente" });
    }
  });

  // Webhook Stripe pour traiter automatiquement les paiements réussis
  app.post("/api/stripe/webhook", async (req, res) => {
    try {
      const event = req.body;
      
      // Vérifier la signature Stripe en production
      if (event.type === 'payment_intent.succeeded') {
        const paymentIntent = event.data.object;
        const metadata = paymentIntent.metadata;
        
        // Le payout a déjà été créé lors de l'achat du billet
        // Ici on pourrait ajouter d'autres logiques si nécessaire
        console.log(`Paiement réussi pour l'événement ${metadata.eventId}`);
      }
      
      res.json({ received: true });
    } catch (error) {
      console.error("Erreur webhook Stripe:", error);
      res.status(400).json({ message: "Erreur webhook" });
    }
  });

  // **Routes pour les messages privés**

  // Récupérer les conversations de l'utilisateur connecté
  app.get("/api/messages/conversations", async (req, res) => {
    if (!req.session?.user?.id) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const conversations = await storage.getConversations(req.session.user.id);
      res.json(conversations);
    } catch (error) {
      console.error("Erreur récupération conversations:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des conversations" });
    }
  });

  // Route supprimée - remplacée par la nouvelle version plus bas

  // Marquer les messages comme lus
  app.patch("/api/messages/conversation/:otherUserId/read", async (req, res) => {
    if (!req.session?.user?.id) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    try {
      const otherUserId = parseInt(req.params.otherUserId);
      await storage.markMessagesAsRead(req.session.user.id, otherUserId);
      res.json({ success: true });
    } catch (error) {
      console.error("Erreur marquage messages lus:", error);
      res.status(500).json({ message: "Erreur lors du marquage des messages" });
    }
  });

  // Routes pour le système de follow/unfollow
  app.post("/api/users/:userId/follow", async (req, res) => {
    try {
      const currentUserId = authManager.getCurrentUser();
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const targetUserId = parseInt(req.params.userId);
      if (currentUserId === targetUserId) {
        return res.status(400).json({ message: "Vous ne pouvez pas vous suivre vous-même" });
      }

      // Vérifier si l'utilisateur cible existe
      const targetUser = await storage.getUser(targetUserId);
      if (!targetUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      // Vérifier si on suit déjà cet utilisateur
      const isAlreadyFollowing = await storage.isFollowing(currentUserId, targetUserId);
      if (isAlreadyFollowing) {
        return res.status(400).json({ message: "Vous suivez déjà cet utilisateur" });
      }

      const follow = await storage.followUser(currentUserId, targetUserId);
      res.json(follow);
    } catch (error) {
      console.error("Erreur lors du follow:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.delete("/api/users/:userId/follow", async (req, res) => {
    try {
      const currentUserId = authManager.getCurrentUser();
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const targetUserId = parseInt(req.params.userId);
      
      // Vérifier si on suit cet utilisateur
      const isFollowing = await storage.isFollowing(currentUserId, targetUserId);
      if (!isFollowing) {
        return res.status(400).json({ message: "Vous ne suivez pas cet utilisateur" });
      }

      await storage.unfollowUser(currentUserId, targetUserId);
      res.json({ success: true });
    } catch (error) {
      console.error("Erreur lors de l'unfollow:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/users/:userId/follow-status", async (req, res) => {
    try {
      const currentUserId = authManager.getCurrentUser();
      const targetUserId = parseInt(req.params.userId);
      
      const [isFollowing, followersCount, followingCount] = await Promise.all([
        currentUserId ? storage.isFollowing(currentUserId, targetUserId) : false,
        storage.getFollowersCount(targetUserId),
        storage.getFollowingCount(targetUserId)
      ]);

      res.json({
        isFollowing,
        followersCount,
        followingCount
      });
    } catch (error) {
      console.error("Erreur lors de la récupération du statut de follow:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/users/:userId/followers", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const followers = await storage.getFollowers(userId);
      res.json(followers);
    } catch (error) {
      console.error("Erreur lors de la récupération des abonnés:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/users/:userId/following", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const following = await storage.getFollowing(userId);
      res.json(following);
    } catch (error) {
      console.error("Erreur lors de la récupération des abonnements:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  const httpServer = createServer(app);
  // Route pour récupérer la liste des utilisateurs
  app.get("/api/users", async (req, res) => {
    try {
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const result = await db.execute(sql`
        SELECT id, username, email, first_name, last_name 
        FROM users 
        ORDER BY username
      `);

      res.json(result.rows);
    } catch (error: any) {
      console.error("Erreur récupération utilisateurs:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Routes pour la messagerie privée
  app.get("/api/messages/conversations", async (req, res) => {
    try {
      console.log("=== API CONVERSATIONS APPELÉE ===");
      
      // Vérifier l'authentification via session Express d'abord
      const sessionUserId = (req.session as any)?.user?.id;
      const finalUserId = sessionUserId || currentUserId || authManager.getCurrentUser();
      
      console.log("Session user ID:", sessionUserId);
      console.log("currentUserId:", currentUserId);
      console.log("AuthManager:", authManager.getCurrentUser());
      console.log("Final user ID:", finalUserId);
      
      if (!finalUserId) {
        console.log("Utilisateur non authentifié");
        return res.status(401).json({ message: "Non authentifié" });
      }

      console.log(`Récupération des conversations pour l'utilisateur ${finalUserId}`);
      const conversations = await storage.getConversations(finalUserId);
      console.log(`${conversations.length} conversations trouvées`);
      res.json(conversations);
    } catch (error: any) {
      console.error("Erreur récupération conversations:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.get("/api/messages/:otherUserId", async (req, res) => {
    try {
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const otherUserId = parseInt(req.params.otherUserId);
      const messages = await storage.getConversationMessages(currentUserId, otherUserId);
      res.json(messages);
    } catch (error: any) {
      console.error("Erreur récupération messages:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    console.log("=== ROUTE DE MESSAGERIE ===");
    try {
      let { receiverId, content } = req.body;
      
      // Obtenir l'utilisateur connecté depuis la session
      const sessionUserId = (req.session as any)?.user?.id;
      const senderId = sessionUserId || currentUserId || authManager.getCurrentUser();
      
      console.log("Session user ID:", sessionUserId);
      console.log("currentUserId:", currentUserId);
      console.log("AuthManager:", authManager.getCurrentUser());
      console.log("Utilisateur expéditeur final:", senderId);
      
      if (!senderId) {
        console.log("Aucun utilisateur authentifié trouvé");
        return res.status(401).json({ message: "Non authentifié" });
      }
      
      console.log("Données reçues:", { senderId, receiverId, content });
      
      if (!receiverId || !content?.trim()) {
        console.log("Données manquantes:", { senderId, receiverId, content });
        return res.status(400).json({ message: "Destinataire et contenu requis" });
      }

      // Vérifier que le destinataire existe
      const receiver = await storage.getUser(parseInt(receiverId));
      if (!receiver) {
        console.log("Destinataire non trouvé:", receiverId);
        return res.status(404).json({ message: "Destinataire non trouvé" });
      }

      console.log(`Envoi de message de l'utilisateur ${senderId} vers ${receiverId}`);

      const messageData = {
        senderId: parseInt(senderId),
        receiverId: parseInt(receiverId),
        content: content.trim()
      };

      const message = await storage.sendMessage(messageData);
      console.log("Message envoyé avec succès:", message.id);
      res.json(message);
    } catch (error: any) {
      console.error("Erreur envoi message:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Envoyer un message
  app.post("/api/messages/send", async (req, res) => {
    try {
      const currentUserId = authManager.getCurrentUser();
      
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }
      
      const { receiverId, content } = req.body;
      
      if (!receiverId || !content?.trim()) {
        return res.status(400).json({ message: "Destinataire et contenu requis" });
      }
      
      console.log(`Envoi de message de ${currentUserId} vers ${receiverId}: "${content}"`);
      
      const messageData = {
        senderId: currentUserId,
        receiverId: parseInt(receiverId),
        content: content.trim()
      };
      
      const message = await storage.sendMessage(messageData);
      console.log("Message envoyé avec succès:", message.id);
      
      res.json(message);
    } catch (error) {
      console.error("Erreur envoi message:", error);
      res.status(500).json({ message: "Erreur lors de l'envoi du message" });
    }
  });

  // Récupérer les messages d'une conversation
  app.get("/api/messages/conversation/:otherUserId", async (req, res) => {
    try {
      const otherUserId = parseInt(req.params.otherUserId);
      const currentUserId = authManager.getCurrentUser();
      
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }
      
      console.log(`Récupération de la conversation entre ${currentUserId} et ${otherUserId}`);
      
      const messages = await storage.getConversationMessages(currentUserId, otherUserId);
      console.log(`${messages.length} messages trouvés`);
      
      res.json(messages);
    } catch (error) {
      console.error("Erreur récupération conversation:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des messages" });
    }
  });

  app.post("/api/messages/mark-read", async (req, res) => {
    try {
      if (!currentUserId) {
        return res.status(401).json({ message: "Non authentifié" });
      }

      const { otherUserId } = req.body;
      
      if (!otherUserId) {
        return res.status(400).json({ message: "ID utilisateur requis" });
      }

      await storage.markMessagesAsRead(currentUserId, parseInt(otherUserId));
      res.json({ success: true });
    } catch (error: any) {
      console.error("Erreur marquage lu:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // ===== ENDPOINTS ORGANISATEUR =====
  
  // Supprimer un événement (organisateur seulement)
  app.delete("/api/events/:eventId", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const { organizerEmail } = req.body;
      
      if (!eventId || !organizerEmail) {
        return res.status(400).json({ message: "ID événement et email organisateur requis" });
      }

      console.log(`=== SUPPRESSION ÉVÉNEMENT ${eventId} par ${organizerEmail} ===`);

      await storage.deleteEvent(eventId, organizerEmail);
      
      console.log(`Événement ${eventId} supprimé avec succès`);
      res.json({ success: true, message: "Événement supprimé avec succès" });
    } catch (error: any) {
      console.error("Erreur suppression événement:", error);
      res.status(500).json({ message: error.message || "Erreur lors de la suppression de l'événement" });
    }
  });
  
  // Récupérer les événements d'un organisateur
  app.get("/api/organizer/events/:email", async (req, res) => {
    try {
      const { email } = req.params;
      
      if (!email) {
        return res.status(400).json({ message: "Email organisateur requis" });
      }

      console.log(`Récupération des événements pour l'organisateur: ${email}`);

      const events = await storage.getEventsByOrganizer(email);
      console.log(`${events.length} événements trouvés pour ${email}`);
      
      // Enrichir avec les statistiques de vente
      const enrichedEvents = await Promise.all(events.map(async (event) => {
        const tickets = await storage.getEventTickets(event.id);
        const ticketsSold = tickets.length;
        
        // Calculer le revenu total en gérant différents formats de prix
        let priceValue = 0;
        if (event.price && event.price !== "Gratuit") {
          const priceStr = event.price.toString().replace(/[€$,\s]/g, '');
          priceValue = parseFloat(priceStr) || 0;
        }
        const totalRevenue = ticketsSold * priceValue;
        
        // Déterminer le statut de l'événement
        const eventDate = new Date(event.date);
        const now = new Date();
        const status = eventDate > now ? 'upcoming' : 'past';
        
        return {
          ...event,
          ticketsSold,
          totalRevenue: Number(totalRevenue.toFixed(2)),
          status,
          ticketsAvailable: event.ticketsAvailable || 100 // Valeur par défaut si non définie
        };
      }));

      console.log(`Événements enrichis:`, enrichedEvents.map(e => ({ 
        id: e.id, 
        title: e.title, 
        ticketsSold: e.ticketsSold, 
        totalRevenue: e.totalRevenue,
        status: e.status 
      })));

      res.json(enrichedEvents);
    } catch (error: any) {
      console.error("Erreur récupération événements organisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });



  // Route pour télécharger un billet PDF avec QR code
  app.get("/api/tickets/:ticketCode/pdf", async (req, res) => {
    try {
      const ticketCode = req.params.ticketCode;
      
      // Récupérer le billet depuis la base de données
      const tickets = await db.execute(sql`
        SELECT t.*, e.title as event_title, e.date as event_date, e.venue, e.location 
        FROM tickets t 
        JOIN events e ON t.event_id = e.id 
        WHERE t.ticket_code = ${ticketCode}
      `);
      
      if (!tickets.rows.length) {
        return res.status(404).send("Billet non trouvé");
      }
      
      const ticket = tickets.rows[0];
      
      // Générer le QR code
      const qrData = {
        ticketId: ticket.id,
        eventId: ticket.event_id,
        buyerName: ticket.buyer_name,
        buyerEmail: ticket.buyer_email,
        purchaseDate: ticket.purchase_date,
        eventTitle: ticket.event_title,
        venue: ticket.venue,
        date: ticket.event_date,
        price: ticket.price,
        ticketCode: ticket.ticket_code,
        type: ticket.price === "Gratuit" ? "free" : "paid",
        verification: Buffer.from(`${ticket.id}-${ticket.event_id}-${ticket.ticket_code}-verified`).toString('base64')
      };
      
      const QRCode = await import('qrcode');
      const qrCodeDataUrl = await QRCode.toDataURL(JSON.stringify(qrData), {
        width: 400,
        margin: 3,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
      
      // Template HTML pour le PDF
      const pdfHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <style>
            body {
              font-family: Arial, sans-serif;
              margin: 0;
              padding: 20px;
              background: white;
              color: #333;
            }
            .ticket {
              max-width: 600px;
              margin: 0 auto;
              border: 3px solid #667eea;
              border-radius: 15px;
              padding: 30px;
              background: linear-gradient(135deg, #f8f9ff 0%, #e3f2fd 100%);
            }
            .header {
              text-align: center;
              margin-bottom: 30px;
              border-bottom: 2px dashed #667eea;
              padding-bottom: 20px;
            }
            .header h1 {
              color: #667eea;
              font-size: 28px;
              margin: 0 0 10px 0;
            }
            .header h2 {
              color: #764ba2;
              font-size: 20px;
              margin: 0;
              font-weight: normal;
            }
            .event-info {
              display: flex;
              justify-content: space-between;
              margin: 20px 0;
              flex-wrap: wrap;
            }
            .event-details {
              flex: 1;
              min-width: 250px;
              margin-right: 20px;
            }
            .event-details h3 {
              color: #667eea;
              font-size: 24px;
              margin: 0 0 15px 0;
            }
            .detail-row {
              margin: 8px 0;
              font-size: 16px;
            }
            .detail-label {
              font-weight: bold;
              color: #555;
              display: inline-block;
              width: 100px;
            }
            .qr-section {
              text-align: center;
              min-width: 200px;
            }
            .qr-code img {
              border: 3px solid #667eea;
              border-radius: 10px;
              background: white;
              padding: 10px;
            }
            .ticket-code {
              background: #667eea;
              color: white;
              padding: 10px 20px;
              border-radius: 8px;
              font-size: 18px;
              font-weight: bold;
              margin: 20px 0;
              letter-spacing: 2px;
            }
            .instructions {
              background: #fff3cd;
              border: 2px solid #ffeaa7;
              border-radius: 8px;
              padding: 20px;
              margin-top: 30px;
            }
            .instructions h4 {
              color: #d4930f;
              margin-top: 0;
            }
            .footer {
              text-align: center;
              margin-top: 30px;
              color: #666;
              font-size: 14px;
              border-top: 1px solid #ddd;
              padding-top: 20px;
            }
            @media print {
              body { margin: 0; }
              .ticket { margin: 10px; }
            }
          </style>
        </head>
        <body>
          <div class="ticket">
            <div class="header">
              <h1>🎵 TechnoCorner</h1>
              <h2>Billet Électronique</h2>
            </div>
            
            <div class="event-info">
              <div class="event-details">
                <h3>${ticket.event_title}</h3>
                <div class="detail-row">
                  <span class="detail-label">📅 Date:</span>
                  ${new Date(ticket.event_date).toLocaleDateString('fr-FR', { 
                    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
                  })}
                </div>
                <div class="detail-row">
                  <span class="detail-label">📍 Lieu:</span>
                  ${ticket.venue}
                </div>
                <div class="detail-row">
                  <span class="detail-label">🏙️ Ville:</span>
                  ${ticket.location}
                </div>
                <div class="detail-row">
                  <span class="detail-label">👤 Nom:</span>
                  ${ticket.buyer_name}
                </div>
                <div class="detail-row">
                  <span class="detail-label">💰 Prix:</span>
                  ${ticket.price}
                </div>
              </div>
              
              <div class="qr-section">
                <div class="qr-code">
                  <img src="${qrCodeDataUrl}" alt="QR Code" width="200" height="200" />
                </div>
                <div class="ticket-code">
                  ${ticket.ticket_code}
                </div>
              </div>
            </div>
            
            <div class="instructions">
              <h4>⚠️ Instructions d'entrée:</h4>
              <ul style="text-align: left; margin: 10px 0;">
                <li>Présentez ce billet (QR code ou code) à l'entrée</li>
                <li>Arrivez 30 minutes avant le début de l'événement</li>
                <li>Une pièce d'identité pourra vous être demandée</li>
                <li>Ce billet est personnel et non transférable</li>
              </ul>
            </div>
            
            <div class="footer">
              <p><strong>TechnoCorner</strong> - La plateforme de référence pour les événements électroniques</p>
              <p>Billet généré le ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}</p>
            </div>
          </div>
        </body>
        </html>
      `;
      
      // Servir le HTML stylé pour impression
      // L'utilisateur peut utiliser "Imprimer en PDF" de son navigateur
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Content-Disposition', `inline; filename="Billet-${String(ticket.event_title).replace(/[^a-zA-Z0-9]/g, '-')}-${ticket.ticket_code}.html"`);
      res.send(pdfHtml);
      
    } catch (error: any) {
      console.error("Erreur génération billet:", error);
      res.status(500).send("Erreur lors de la génération du billet");
    }
  });

  // Route pour télécharger un billet avec QR code (JSON)
  app.get("/api/tickets/:ticketId/download", async (req, res) => {
    try {
      const ticketId = parseInt(req.params.ticketId);
      
      // Récupérer le billet depuis la base de données
      const tickets = await db.execute(sql`
        SELECT t.*, e.title as event_title, e.date as event_date, e.venue, e.location 
        FROM tickets t 
        JOIN events e ON t.event_id = e.id 
        WHERE t.id = ${ticketId}
      `);
      
      if (!tickets.rows.length) {
        return res.status(404).json({ message: "Billet non trouvé" });
      }
      
      const ticket = tickets.rows[0];
      
      // Générer le QR code
      const qrData = {
        ticketId: ticket.id,
        eventId: ticket.event_id,
        buyerName: ticket.buyer_name,
        buyerEmail: ticket.buyer_email,
        purchaseDate: ticket.purchase_date,
        eventTitle: ticket.event_title,
        venue: ticket.venue,
        date: ticket.event_date,
        price: ticket.price,
        ticketCode: ticket.ticket_code,
        type: "standard",
        verification: Buffer.from(`${ticket.id}-${ticket.event_id}-${ticket.ticket_code}-standard`).toString('base64')
      };
      
      const QRCode = await import('qrcode');
      const qrCodeDataUrl = await QRCode.toDataURL(JSON.stringify(qrData), {
        width: 256,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
      
      res.json({
        success: true,
        ticket: {
          id: ticket.id,
          code: ticket.ticket_code,
          eventTitle: ticket.event_title,
          eventDate: ticket.event_date,
          venue: ticket.venue,
          location: ticket.location,
          buyerName: ticket.buyer_name,
          buyerEmail: ticket.buyer_email,
          qrCode: qrCodeDataUrl,
          price: ticket.price,
          status: ticket.status
        }
      });
    } catch (error: any) {
      console.error("Erreur téléchargement billet:", error);
      res.status(500).json({ message: "Erreur lors du téléchargement du billet" });
    }
  });

  // Recherche d'utilisateurs par nom ou email
  app.get("/api/search/users", async (req, res) => {
    try {
      const { q, limit = 20 } = req.query;
      
      if (!q || typeof q !== 'string' || q.trim().length < 2) {
        return res.status(400).json({ 
          message: "Requête de recherche requise (minimum 2 caractères)" 
        });
      }
      
      const searchTerm = `%${q.trim().toLowerCase()}%`;
      
      // Rechercher dans les utilisateurs enregistrés
      const users = await db.execute(sql`
        SELECT id, username, email, first_name, last_name, created_at
        FROM users 
        WHERE LOWER(username) LIKE ${searchTerm} 
           OR LOWER(email) LIKE ${searchTerm}
           OR LOWER(first_name) LIKE ${searchTerm}
           OR LOWER(last_name) LIKE ${searchTerm}
        ORDER BY created_at DESC
        LIMIT ${parseInt(limit as string)}
      `);
      
      // Rechercher aussi dans les acheteurs de billets (même non enregistrés)
      const ticketBuyers = await db.execute(sql`
        SELECT DISTINCT buyer_name, buyer_email, 
               COUNT(*) as ticket_count,
               MAX(purchase_date) as last_purchase
        FROM tickets 
        WHERE LOWER(buyer_name) LIKE ${searchTerm} 
           OR LOWER(buyer_email) LIKE ${searchTerm}
        GROUP BY buyer_name, buyer_email
        ORDER BY last_purchase DESC
        LIMIT ${parseInt(limit as string)}
      `);
      
      res.json({
        success: true,
        results: {
          registered_users: users.rows,
          ticket_buyers: ticketBuyers.rows
        }
      });
    } catch (error: any) {
      console.error("Erreur recherche utilisateurs:", error);
      res.status(500).json({ message: "Erreur lors de la recherche" });
    }
  });

  // Obtenir les détails complets d'un utilisateur et ses billets
  app.get("/api/user/profile/:identifier", async (req, res) => {
    try {
      const { identifier } = req.params;
      const { type = 'email' } = req.query; // 'email', 'username', ou 'id'
      
      let userQuery;
      if (type === 'id') {
        userQuery = sql`SELECT * FROM users WHERE id = ${parseInt(identifier)}`;
      } else if (type === 'username') {
        userQuery = sql`SELECT * FROM users WHERE username = ${identifier}`;
      } else {
        userQuery = sql`SELECT * FROM users WHERE email = ${identifier}`;
      }
      
      const users = await db.execute(userQuery);
      const user = users.rows[0];
      
      // Rechercher tous les billets associés à cet email
      const tickets = await db.execute(sql`
        SELECT t.*, e.title as event_title, e.date as event_date, 
               e.venue, e.location, e.price as event_price
        FROM tickets t
        JOIN events e ON t.event_id = e.id
        WHERE t.buyer_email = ${identifier}
        ORDER BY t.purchase_date DESC
      `);
      
      // Statistiques de l'utilisateur
      const stats = await db.execute(sql`
        SELECT 
          COUNT(*) as total_tickets,
          COUNT(CASE WHEN t.status = 'active' THEN 1 END) as active_tickets,
          COUNT(CASE WHEN t.status = 'used' THEN 1 END) as used_tickets,
          MIN(t.purchase_date) as first_purchase,
          MAX(t.purchase_date) as last_purchase
        FROM tickets t
        WHERE t.buyer_email = ${identifier}
      `);
      
      // Événements auxquels l'utilisateur a participé
      const events = await db.execute(sql`
        SELECT DISTINCT e.*, COUNT(t.id) as ticket_count
        FROM events e
        JOIN tickets t ON e.id = t.event_id
        WHERE t.buyer_email = ${identifier}
        GROUP BY e.id, e.title, e.description, e.date, e.venue, e.location, e.price, e.organizer_email, e.max_tickets, e.category, e.image_url
        ORDER BY e.date DESC
      `);
      
      res.json({
        success: true,
        user: user || null,
        tickets: tickets.rows,
        events: events.rows,
        stats: stats.rows[0] || {
          total_tickets: 0,
          active_tickets: 0,
          used_tickets: 0,
          first_purchase: null,
          last_purchase: null
        }
      });
    } catch (error: any) {
      console.error("Erreur profil utilisateur:", error);
      res.status(500).json({ message: "Erreur lors de la récupération du profil" });
    }
  });

  // Recherche de billets par critères multiples
  app.get("/api/search/tickets", async (req, res) => {
    try {
      const { 
        q, 
        email, 
        event_id, 
        status, 
        date_from, 
        date_to, 
        limit = 50 
      } = req.query;
      
      let whereConditions = [];
      let params = [];
      
      if (q && typeof q === 'string' && q.trim().length >= 2) {
        const searchTerm = `%${q.trim().toLowerCase()}%`;
        whereConditions.push(`(
          LOWER(t.buyer_name) LIKE '${searchTerm}' OR 
          LOWER(t.buyer_email) LIKE '${searchTerm}' OR 
          LOWER(t.ticket_code) LIKE '${searchTerm}' OR
          LOWER(e.title) LIKE '${searchTerm}'
        )`);
      }
      
      if (email) {
        whereConditions.push(`t.buyer_email = ?`);
        params.push(email);
      }
      
      if (event_id) {
        whereConditions.push(`t.event_id = ?`);
        params.push(parseInt(event_id as string));
      }
      
      if (status) {
        whereConditions.push(`t.status = ?`);
        params.push(status);
      }
      
      if (date_from) {
        whereConditions.push(`t.purchase_date >= ?`);
        params.push(date_from);
      }
      
      if (date_to) {
        whereConditions.push(`t.purchase_date <= ?`);
        params.push(date_to);
      }
      
      // Build the final query with proper parameter binding
      let finalQuery = `
        SELECT t.*, e.title as event_title, e.date as event_date, 
               e.venue, e.location, e.organizer_email
        FROM tickets t
        JOIN events e ON t.event_id = e.id
      `;
      
      if (whereConditions.length > 0) {
        finalQuery += ` WHERE ${whereConditions.join(' AND ')}`;
      }
      
      finalQuery += ` ORDER BY t.purchase_date DESC LIMIT ${parseInt(limit as string)}`;
      
      const tickets = await db.execute(sql.raw(finalQuery, params));
      
      res.json({
        success: true,
        tickets: tickets.rows,
        count: tickets.rows.length
      });
    } catch (error: any) {
      console.error("Erreur recherche billets:", error);
      res.status(500).json({ message: "Erreur lors de la recherche de billets" });
    }
  });

  // Récupérer les billets vendus pour un organisateur
  app.get("/api/organizer/tickets/:email", async (req, res) => {
    try {
      const { email } = req.params;
      
      if (!email) {
        return res.status(400).json({ message: "Email organisateur requis" });
      }

      // Récupérer tous les événements de cet organisateur
      const events = await storage.getEventsByOrganizer(email);
      
      // Récupérer tous les billets pour ces événements
      const allTickets = [];
      for (const event of events) {
        const eventTickets = await storage.getEventTickets(event.id);
        const enrichedTickets = eventTickets.map(ticket => ({
          ...ticket,
          eventTitle: event.title,
          purchaseDate: ticket.purchaseDate || new Date().toISOString(),
          code: ticket.ticketCode
        }));
        allTickets.push(...enrichedTickets);
      }

      // Trier par date d'achat (plus récent en premier)
      allTickets.sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());

      res.json(allTickets);
    } catch (error: any) {
      console.error("Erreur récupération billets organisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Récupérer les paiements pour un organisateur
  app.get("/api/organizer/payouts/:email", async (req, res) => {
    try {
      const { email } = req.params;
      
      if (!email) {
        return res.status(400).json({ message: "Email organisateur requis" });
      }

      const payouts = await storage.getOrganizerPayouts(email);
      res.json(payouts);
    } catch (error: any) {
      console.error("Erreur récupération paiements organisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Récupérer les KPI globaux pour un organisateur
  app.get("/api/organizer/analytics/:email", async (req, res) => {
    try {
      const { email } = req.params;
      
      if (!email) {
        return res.status(400).json({ message: "Email organisateur requis" });
      }

      console.log(`Récupération des analytics pour l'organisateur: ${email}`);

      // Récupérer tous les événements de l'organisateur
      const events = await storage.getEventsByOrganizer(email);
      
      // Calculer les KPIs globaux
      let totalRevenue = 0;
      let totalTicketsSold = 0;
      let upcomingEvents = 0;
      let pastEvents = 0;
      const now = new Date();

      for (const event of events) {
        const tickets = await storage.getEventTickets(event.id);
        const ticketsSold = tickets.length;
        
        // Calculer le revenu pour cet événement
        let priceValue = 0;
        if (event.price && event.price !== "Gratuit") {
          const priceStr = event.price.toString().replace(/[€$,\s]/g, '');
          priceValue = parseFloat(priceStr) || 0;
        }
        const eventRevenue = ticketsSold * priceValue;
        
        totalRevenue += eventRevenue;
        totalTicketsSold += ticketsSold;
        
        // Compter les événements à venir vs passés
        const eventDate = new Date(event.date);
        if (eventDate > now) {
          upcomingEvents++;
        } else {
          pastEvents++;
        }
      }

      // Récupérer les paiements en attente
      const payouts = await storage.getOrganizerPayouts(email);
      const pendingPayouts = payouts.filter(p => p.status === 'pending').length;

      const analytics = {
        totalRevenue: Number(totalRevenue.toFixed(2)),
        totalTicketsSold,
        totalEvents: events.length,
        upcomingEvents,
        pastEvents,
        pendingPayouts
      };

      console.log(`Analytics pour ${email}:`, analytics);
      res.json(analytics);
    } catch (error: any) {
      console.error("Erreur récupération analytics organisateur:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // Exporter les données d'un événement
  app.get("/api/organizer/events/:eventId/export", async (req, res) => {
    try {
      const { eventId } = req.params;
      
      const event = await storage.getEvent(parseInt(eventId));
      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" });
      }

      const tickets = await storage.getEventTickets(parseInt(eventId));
      
      // Préparer les données d'export
      const exportData = {
        event: {
          id: event.id,
          title: event.title,
          date: event.date,
          venue: event.venue,
          location: event.location,
          price: event.price,
          organizerEmail: event.organizerEmail
        },
        statistics: {
          ticketsSold: tickets.length,
          totalRevenue: tickets.length * parseFloat(event.price.replace('€', '').trim()),
          ticketsAvailable: event.ticketsAvailable
        },
        tickets: tickets.map(ticket => ({
          code: ticket.ticketCode,
          buyerName: ticket.buyerName,
          buyerEmail: ticket.buyerEmail,
          purchaseDate: ticket.purchaseDate,
          status: ticket.status
        }))
      };

      res.json(exportData);
    } catch (error: any) {
      console.error("Erreur export données événement:", error);
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  // ===== API EXTERNE POUR BILLETTERIES TIERCES =====
  
  // Middleware d'authentification API
  const authenticateApiKey = async (req: any, res: any, next: any) => {
    const startTime = Date.now();
    
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        await externalApiService.logApiRequest({
          endpoint: req.path,
          method: req.method,
          statusCode: 401,
          responseTime: Date.now() - startTime,
          ipAddress: req.ip,
          userAgent: req.headers['user-agent'],
          errorMessage: 'Missing or invalid authorization header'
        });
        return res.status(401).json({ error: 'Missing or invalid authorization header' });
      }
      
      const token = authHeader.substring(7); // Remove 'Bearer '
      const [keyId, keySecret] = token.split(':');
      
      if (!keyId || !keySecret) {
        await externalApiService.logApiRequest({
          endpoint: req.path,
          method: req.method,
          statusCode: 401,
          responseTime: Date.now() - startTime,
          ipAddress: req.ip,
          userAgent: req.headers['user-agent'],
          errorMessage: 'Invalid token format'
        });
        return res.status(401).json({ error: 'Invalid token format. Use keyId:keySecret' });
      }
      
      const apiKey = await externalApiService.authenticateApiKey(keyId, keySecret);
      if (!apiKey) {
        await externalApiService.logApiRequest({
          endpoint: req.path,
          method: req.method,
          statusCode: 401,
          responseTime: Date.now() - startTime,
          ipAddress: req.ip,
          userAgent: req.headers['user-agent'],
          errorMessage: 'Invalid API key'
        });
        return res.status(401).json({ error: 'Invalid API key' });
      }
      
      req.apiKey = apiKey;
      req.startTime = startTime;
      next();
    } catch (error: any) {
      await externalApiService.logApiRequest({
        endpoint: req.path,
        method: req.method,
        statusCode: 500,
        responseTime: Date.now() - startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        errorMessage: error.message
      });
      
      if (error.message === 'Rate limit exceeded') {
        return res.status(429).json({ error: 'Rate limit exceeded' });
      }
      
      res.status(500).json({ error: 'Internal server error' });
    }
  };
  
  // Endpoint pour créer un événement via l'API externe
  app.post("/api/external/events", authenticateApiKey, async (req: any, res: any) => {
    try {
      if (!externalApiService.hasPermission(req.apiKey, 'events:create')) {
        return res.status(403).json({ error: 'Insufficient permissions for event creation' });
      }
      
      const {
        externalEventId,
        title,
        description,
        date,
        time,
        venue,
        location,
        maxTickets
      } = req.body;
      
      // Validation des données
      if (!externalEventId || !title || !date || !venue) {
        return res.status(400).json({ 
          error: 'Missing required fields: externalEventId, title, date, venue' 
        });
      }
      
      // Vérifier si l'événement existe déjà
      const existingEvent = await storage.getExternalEventByExternalId(req.apiKey.id, externalEventId);
      if (existingEvent) {
        return res.status(409).json({ 
          error: 'Event with this external ID already exists' 
        });
      }
      
      // Créer l'événement
      const eventData = {
        apiKeyId: req.apiKey.id,
        externalEventId,
        title,
        description: description || '',
        date,
        time: time || '20:00',
        venue,
        location,
        organizerName: req.apiKey.organizerName,
        organizerEmail: req.apiKey.organizerEmail,
        maxTickets: maxTickets || 0,
        status: 'active'
      };
      
      const event = await storage.createExternalEvent(eventData);
      
      // Log de l'audit
      await externalApiService.logApiRequest({
        apiKeyId: req.apiKey.id,
        endpoint: req.path,
        method: req.method,
        statusCode: 201,
        responseTime: Date.now() - req.startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        requestData: JSON.stringify(req.body)
      });
      
      res.status(201).json({
        success: true,
        event: {
          id: event.id,
          externalEventId: event.externalEventId,
          title: event.title,
          status: event.status,
          createdAt: event.createdAt
        }
      });
    } catch (error: any) {
      console.error('Error creating external event:', error);
      await externalApiService.logApiRequest({
        apiKeyId: req.apiKey?.id,
        endpoint: req.path,
        method: req.method,
        statusCode: 500,
        responseTime: Date.now() - req.startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        errorMessage: error.message
      });
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
  // Endpoint pour générer un QR code de billet
  app.post("/api/external/tickets/generate", authenticateApiKey, async (req: any, res: any) => {
    try {
      if (!externalApiService.hasPermission(req.apiKey, 'tickets:generate')) {
        return res.status(403).json({ error: 'Insufficient permissions for ticket generation' });
      }
      
      const {
        externalEventId,
        externalTicketId,
        buyerName,
        buyerEmail,
        ticketType,
        price
      } = req.body;
      
      // Validation
      if (!externalEventId || !externalTicketId || !buyerName || !buyerEmail) {
        return res.status(400).json({ 
          error: 'Missing required fields: externalEventId, externalTicketId, buyerName, buyerEmail' 
        });
      }
      
      // Vérifier que l'événement existe
      const event = await storage.getExternalEventByExternalId(req.apiKey.id, externalEventId);
      if (!event) {
        return res.status(404).json({ error: 'Event not found' });
      }
      
      // Générer le QR code unique
      const qrCode = await externalApiService.generateTicketQRCode({
        eventId: externalEventId,
        ticketId: externalTicketId,
        buyerEmail
      });
      
      // Créer le billet
      const ticketData = {
        externalEventId: event.id,
        externalTicketId,
        qrCode,
        buyerName,
        buyerEmail,
        ticketType: ticketType || 'regular',
        price: price || '0€',
        status: 'valid'
      };
      
      const ticket = await storage.createExternalTicket(ticketData);
      
      // Générer l'image QR code
      const qrCodeImage = await externalApiService.generateQRCodeImage(qrCode);
      
      // Envoyer le billet par email automatiquement
      try {
        const { sendTicketEmail } = await import('./email-service');
        
        const ticketEmailData = {
          buyerName,
          buyerEmail,
          eventTitle: event.title,
          eventDate: `${event.date} ${event.time || ''}`.trim(),
          venue: event.venue || 'Lieu à confirmer',
          location: event.location || 'Localisation à confirmer',
          ticketCode: qrCode,
          qrCodeDataUrl: qrCodeImage,
          price: price || '0€',
          isExternal: true,
          organizerName: req.apiKey.organizerName
        };
        
        const emailSent = await sendTicketEmail(ticketEmailData);
        if (emailSent) {
          console.log(`Billet externe envoyé par email à ${buyerEmail} pour l'événement ${event.title}`);
        } else {
          console.error(`Échec de l'envoi d'email pour le billet externe à ${buyerEmail}`);
        }
      } catch (emailError) {
        console.error("Erreur envoi email billet externe:", emailError);
      }
      
      // Envoyer un webhook si configuré
      if (req.apiKey.webhookUrl) {
        await externalApiService.sendWebhook(req.apiKey.webhookUrl, 'ticket.generated', {
          ticket: {
            id: ticket.id,
            externalTicketId,
            qrCode,
            buyerEmail,
            eventTitle: event.title,
            emailSent: true
          }
        });
      }
      
      // Log de l'audit
      await externalApiService.logApiRequest({
        apiKeyId: req.apiKey.id,
        endpoint: req.path,
        method: req.method,
        statusCode: 201,
        responseTime: Date.now() - req.startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        requestData: JSON.stringify({ ...req.body, buyerEmail: '[REDACTED]' })
      });
      
      res.status(201).json({
        success: true,
        ticket: {
          id: ticket.id,
          qrCode: ticket.qrCode,
          qrCodeImage,
          status: ticket.status,
          createdAt: ticket.createdAt
        }
      });
    } catch (error: any) {
      console.error('Error generating ticket:', error);
      await externalApiService.logApiRequest({
        apiKeyId: req.apiKey?.id,
        endpoint: req.path,
        method: req.method,
        statusCode: 500,
        responseTime: Date.now() - req.startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        errorMessage: error.message
      });
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
  // Endpoint pour valider un QR code
  app.post("/api/external/tickets/validate", authenticateApiKey, async (req: any, res: any) => {
    try {
      if (!externalApiService.hasPermission(req.apiKey, 'tickets:validate')) {
        return res.status(403).json({ error: 'Insufficient permissions for ticket validation' });
      }
      
      const { qrCode } = req.body;
      
      if (!qrCode) {
        return res.status(400).json({ error: 'QR code is required' });
      }
      
      // Récupérer le billet
      const ticket = await storage.getExternalTicketByQrCode(qrCode);
      if (!ticket) {
        return res.status(404).json({ 
          valid: false,
          error: 'Ticket not found' 
        });
      }
      
      // Récupérer l'événement
      const event = await storage.getExternalEvent(ticket.externalEventId);
      if (!event) {
        return res.status(404).json({ 
          valid: false,
          error: 'Event not found' 
        });
      }
      
      // Vérifier que le billet appartient à la même API key
      if (event.apiKeyId !== req.apiKey.id) {
        return res.status(403).json({ 
          valid: false,
          error: 'Ticket belongs to different organizer' 
        });
      }
      
      if (ticket.status === 'used') {
        return res.status(200).json({
          valid: false,
          error: 'Ticket already used',
          ticket: {
            buyerName: ticket.buyerName,
            usedAt: ticket.usedAt
          }
        });
      }
      
      if (ticket.status === 'cancelled') {
        return res.status(200).json({
          valid: false,
          error: 'Ticket cancelled'
        });
      }
      
      // Marquer comme utilisé
      const updatedTicket = await storage.markExternalTicketAsUsed(qrCode);
      
      // Envoyer un webhook si configuré
      if (req.apiKey.webhookUrl) {
        await externalApiService.sendWebhook(req.apiKey.webhookUrl, 'ticket.validated', {
          ticket: {
            id: updatedTicket.id,
            qrCode,
            buyerName: updatedTicket.buyerName,
            eventTitle: event.title,
            validatedAt: updatedTicket.usedAt
          }
        });
      }
      
      // Log de l'audit
      await externalApiService.logApiRequest({
        apiKeyId: req.apiKey.id,
        endpoint: req.path,
        method: req.method,
        statusCode: 200,
        responseTime: Date.now() - req.startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent']
      });
      
      res.status(200).json({
        valid: true,
        ticket: {
          buyerName: updatedTicket.buyerName,
          buyerEmail: updatedTicket.buyerEmail,
          ticketType: updatedTicket.ticketType,
          eventTitle: event.title,
          venue: event.venue,
          validatedAt: updatedTicket.usedAt
        }
      });
    } catch (error: any) {
      console.error('Error validating ticket:', error);
      await externalApiService.logApiRequest({
        apiKeyId: req.apiKey?.id,
        endpoint: req.path,
        method: req.method,
        statusCode: 500,
        responseTime: Date.now() - req.startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        errorMessage: error.message
      });
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
  // Endpoint pour obtenir les statistiques d'un événement
  app.get("/api/external/events/:externalEventId/stats", authenticateApiKey, async (req: any, res: any) => {
    try {
      const { externalEventId } = req.params;
      
      const event = await storage.getExternalEventByExternalId(req.apiKey.id, externalEventId);
      if (!event) {
        return res.status(404).json({ error: 'Event not found' });
      }
      
      const tickets = await storage.getExternalTicketsByEvent(event.id);
      const validTickets = tickets.filter(t => t.status === 'valid');
      const usedTickets = tickets.filter(t => t.status === 'used');
      const cancelledTickets = tickets.filter(t => t.status === 'cancelled');
      
      await externalApiService.logApiRequest({
        apiKeyId: req.apiKey.id,
        endpoint: req.path,
        method: req.method,
        statusCode: 200,
        responseTime: Date.now() - req.startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent']
      });
      
      res.status(200).json({
        event: {
          title: event.title,
          venue: event.venue,
          date: event.date,
          maxTickets: event.maxTickets
        },
        stats: {
          totalTickets: tickets.length,
          validTickets: validTickets.length,
          usedTickets: usedTickets.length,
          cancelledTickets: cancelledTickets.length,
          availableTickets: Math.max(0, event.maxTickets - tickets.length)
        }
      });
    } catch (error: any) {
      console.error('Error getting event stats:', error);
      await externalApiService.logApiRequest({
        apiKeyId: req.apiKey?.id,
        endpoint: req.path,
        method: req.method,
        statusCode: 500,
        responseTime: Date.now() - req.startTime,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        errorMessage: error.message
      });
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // ===== ENDPOINT ADMIN POUR GÉNÉRATION DE CLÉS API =====
  
  // Endpoint temporaire pour générer des clés API (à sécuriser en production)
  app.post("/api/admin/generate-api-key", async (req, res) => {
    try {
      const {
        organizerName,
        organizerEmail,
        organizerWebsite,
        webhookUrl,
        permissions
      } = req.body;
      
      if (!organizerName || !organizerEmail) {
        return res.status(400).json({ 
          error: 'organizerName and organizerEmail are required' 
        });
      }
      
      const result = await externalApiService.generateApiKey({
        organizerName,
        organizerEmail,
        organizerWebsite,
        webhookUrl,
        permissions: permissions || ['events:create', 'tickets:generate', 'tickets:validate']
      });
      
      res.status(201).json({
        success: true,
        keyId: result.keyId,
        keySecret: result.keySecret,
        token: `${result.keyId}:${result.keySecret}`,
        message: 'API key generated successfully. Store these credentials securely.'
      });
    } catch (error: any) {
      console.error('Error generating API key:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Servir la démo de billetterie externe
  app.get("/external-demo", (req, res) => {
    res.sendFile(path.join(process.cwd(), 'external-ticketing-demo.html'));
  });

  // Routes Eventbrite
  app.post("/api/eventbrite/sync", async (req, res) => {
    try {
      const { location } = req.body;
      console.log("🔄 Démarrage de la synchronisation Eventbrite...");
      
      const importedCount = await eventbriteService.syncElectronicMusicEvents(location);
      
      res.json({
        success: true,
        message: `Synchronisation terminée avec succès`,
        eventsImported: importedCount
      });
    } catch (error: any) {
      console.error("Erreur lors de la synchronisation Eventbrite:", error);
      res.status(500).json({
        success: false,
        error: "Erreur lors de la synchronisation",
        message: error.message
      });
    }
  });

  app.get("/api/eventbrite/search", async (req, res) => {
    try {
      const { query = "electronic music", location, limit = "20" } = req.query;
      
      const events = await eventbriteService.searchEvents(
        query as string, 
        location as string, 
        parseInt(limit as string)
      );
      
      res.json({
        success: true,
        events: events,
        count: events.length
      });
    } catch (error: any) {
      console.error("Erreur lors de la recherche Eventbrite:", error);
      res.status(500).json({
        success: false,
        error: "Erreur lors de la recherche",
        message: error.message
      });
    }
  });

  return httpServer;
}
