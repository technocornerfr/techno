import { db } from "./db";
import { sql } from "drizzle-orm";

interface PostScore {
  postId: number;
  score: number;
  reasons: string[];
}

interface UserPreferences {
  preferredGenres: string[];
  preferredContentTypes: string[];
  followedUsers: number[];
  interactionHistory: {
    likedPosts: number[];
    commentedPosts: number[];
    viewedEvents: number[];
  };
}

export class RecommendationService {
  
  // Analyser les préférences utilisateur
  async analyzeUserPreferences(userId: number): Promise<UserPreferences> {
    try {
      // Récupérer les utilisateurs suivis
      const followedUsersResult = await db.execute(sql`
        SELECT following_id 
        FROM user_follows 
        WHERE follower_id = ${userId}
      `);
      
      // Récupérer les posts likés récents
      const likedPostsResult = await db.execute(sql`
        SELECT post_id 
        FROM post_likes 
        WHERE user_id = ${userId}
        LIMIT 50
      `);
      
      // Récupérer les posts commentés récents
      const commentedPostsResult = await db.execute(sql`
        SELECT post_id 
        FROM post_comments 
        WHERE user_id = ${userId}
        LIMIT 25
      `);

      return {
        preferredGenres: ['techno', 'house'],
        preferredContentTypes: ['text', 'image', 'video', 'music'],
        followedUsers: followedUsersResult.rows.map(row => row.following_id as number),
        interactionHistory: {
          likedPosts: likedPostsResult.rows.map(row => row.post_id as number),
          commentedPosts: commentedPostsResult.rows.map(row => row.post_id as number),
          viewedEvents: []
        }
      };
    } catch (error) {
      console.log("Error in analyzeUserPreferences:", error);
      return {
        preferredGenres: ['techno', 'house'],
        preferredContentTypes: ['text', 'image', 'video'],
        followedUsers: [],
        interactionHistory: {
          likedPosts: [],
          commentedPosts: [],
          viewedEvents: []
        }
      };
    }
  }

  // Obtenir les recommandations pour un utilisateur
  async getRecommendations(userId: number, limit: number = 20): Promise<any[]> {
    try {
      // Récupérer tous les posts avec scoring d'engagement
      const postsResult = await db.execute(sql`
        SELECT 
          p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
          u.username, u.profile_image_url,
          COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked,
          (COALESCE(p.likes_count, 0) * 2 + COALESCE(p.comments_count, 0) * 3 + 
           CASE WHEN p.created_at >= NOW() - INTERVAL '24 hours' THEN 10 ELSE 0 END) as engagement_score
        FROM posts p 
        LEFT JOIN users u ON p.user_id = u.id 
        LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
        WHERE p.user_id != ${userId}
        ORDER BY engagement_score DESC, p.created_at DESC
        LIMIT ${limit}
      `);

      // Si pas assez de posts, augmenter la limite initiale pour avoir plus de contenu
      if (postsResult.rows.length < limit) {
        const additionalResult = await db.execute(sql`
          SELECT 
            p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
            u.username, u.profile_image_url,
            COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked,
            3 as engagement_score
          FROM posts p 
          LEFT JOIN users u ON p.user_id = u.id 
          LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
          WHERE p.user_id != ${userId}
          ORDER BY p.created_at DESC
          LIMIT ${limit * 2}
        `);
        
        // Combiner et déduplicater les résultats
        const existingIds = new Set(postsResult.rows.map(r => r.id));
        const uniqueAdditional = additionalResult.rows.filter(r => !existingIds.has(r.id));
        postsResult.rows = [...postsResult.rows, ...uniqueAdditional.slice(0, limit - postsResult.rows.length)];
      }

      // Formatter les résultats
      const recommendations = postsResult.rows.map((row: any) => ({
        id: row.id,
        content: row.content,
        imageUrl: row.image_url,
        type: row.type,
        likesCount: row.likes_count || 0,
        commentsCount: row.comments_count || 0,
        createdAt: row.created_at,
        userId: row.user_id,
        author: {
          id: row.user_id,
          username: row.username || "Utilisateur",
          profileImageUrl: row.profile_image_url
        },
        isLiked: row.is_liked,
        comments: [],
        recommendationScore: row.engagement_score || 5,
        recommendationReasons: ["Contenu populaire", "Algorithme de recommandation"]
      }));

      return recommendations;
    } catch (error) {
      console.error("Error in getRecommendations:", error);
      return await this.getFallbackRecommendations(userId, limit);
    }
  }

  // Recommandations de fallback
  async getFallbackRecommendations(userId: number, limit: number): Promise<any[]> {
    try {
      const fallbackResult = await db.execute(sql`
        SELECT 
          p.id, p.content, p.image_url, p.type, p.likes_count, p.comments_count, p.created_at, p.user_id,
          u.username, u.profile_image_url,
          COALESCE(user_liked.user_id IS NOT NULL, false) as is_liked
        FROM posts p 
        LEFT JOIN users u ON p.user_id = u.id 
        LEFT JOIN post_likes user_liked ON p.id = user_liked.post_id AND user_liked.user_id = ${userId}
        WHERE p.user_id != ${userId}
        ORDER BY p.created_at DESC
        LIMIT ${limit}
      `);

      return fallbackResult.rows.map((row: any) => ({
        id: row.id,
        content: row.content,
        imageUrl: row.image_url,
        type: row.type,
        likesCount: row.likes_count || 0,
        commentsCount: row.comments_count || 0,
        createdAt: row.created_at,
        userId: row.user_id,
        author: {
          id: row.user_id,
          username: row.username || "Utilisateur",
          profileImageUrl: row.profile_image_url
        },
        isLiked: row.is_liked,
        comments: [],
        recommendationScore: 5,
        recommendationReasons: ["Contenu récent"]
      }));
    } catch (error) {
      console.error("Error in getFallbackRecommendations:", error);
      return [];
    }
  }

  // Enregistrer une interaction utilisateur
  async recordInteraction(userId: number, postId: number, interactionType: string, value: number = 1.0): Promise<void> {
    try {
      await db.execute(sql`
        INSERT INTO user_interactions (user_id, post_id, interaction_type, interaction_value)
        VALUES (${userId}, ${postId}, ${interactionType}, ${value})
      `);
    } catch (error) {
      console.log("Erreur lors de l'enregistrement de l'interaction:", error);
    }
  }
}

export const recommendationService = new RecommendationService();