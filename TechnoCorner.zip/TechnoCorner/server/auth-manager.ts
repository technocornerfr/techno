// Gestionnaire d'authentification global
class AuthManager {
  private currentUserId: number | null = null;

  setCurrentUser(userId: number | null) {
    this.currentUserId = userId;
    console.log("AuthManager: Utilisateur défini:", userId);
  }

  getCurrentUser(): number | null {
    return this.currentUserId;
  }

  isAuthenticated(): boolean {
    return this.currentUserId !== null;
  }

  clearAuth() {
    this.currentUserId = null;
    console.log("AuthManager: Authentification effacée");
  }
}

// Instance globale singleton
export const authManager = new AuthManager();