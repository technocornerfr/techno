import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Add QR code route BEFORE other routes to prevent conflicts
  app.get("/api/qr/:ticketCode", async (req, res) => {
    try {
      const { db } = await import("./db");
      const { sql } = await import("drizzle-orm");
      const ticketCode = req.params.ticketCode;
      
      const tickets = await db.execute(sql`
        SELECT t.*, e.title as event_title, e.date as event_date, e.venue, e.location 
        FROM tickets t 
        JOIN events e ON t.event_id = e.id 
        WHERE t.ticket_code = ${ticketCode}
      `);
      
      if (!tickets.rows.length) {
        return res.status(404).send("Billet non trouvé");
      }
      
      const ticket = tickets.rows[0];
      
      const qrData = {
        ticketId: ticket.id,
        eventId: ticket.event_id,
        buyerName: ticket.buyer_name,
        buyerEmail: ticket.buyer_email,
        purchaseDate: ticket.purchase_date,
        eventTitle: ticket.event_title,
        venue: ticket.venue,
        date: ticket.event_date,
        price: ticket.price,
        ticketCode: ticket.ticket_code,
        type: ticket.price === "Gratuit" ? "free" : "paid",
        verification: Buffer.from(`${ticket.id}-${ticket.event_id}-${ticket.ticket_code}-verified`).toString('base64')
      };
      
      const QRCode = await import('qrcode');
      const qrBuffer = await QRCode.toBuffer(JSON.stringify(qrData), {
        width: 400,
        margin: 3,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
      
      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(qrBuffer);
    } catch (error: any) {
      console.error("Erreur QR:", error);
      res.status(500).send("Erreur QR code");
    }
  });

  // Register API routes FIRST before Vite middleware
  const server = await registerRoutes(app);

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  
  server.listen({
    port,
    host: "0.0.0.0",
  }, () => {
    log(`serving on port ${port}`);
  });
})();
