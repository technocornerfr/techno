import { pgTable, text, serial, integer, timestamp, boolean, unique, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  bio: text("bio"),
  city: text("city"),
  country: text("country"),
  website: text("website"),
  profileImageUrl: text("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  date: text("date").notNull(), // Date de début
  time: text("time").notNull(), // Heure de début
  endTime: text("end_time"), // Heure de fin (optionnelle)
  endDate: text("end_date"), // Date de fin (optionnelle pour événements multi-jours)
  venue: text("venue").notNull(),
  location: text("location").notNull(),
  price: text("price").notNull(),
  pricingTiers: text("pricing_tiers"), // JSON string pour stocker les différents niveaux de prix
  category: text("category").notNull(), // club, festival, underground, workshop, outdoor
  djs: text("djs").array().notNull(),
  imageUrl: text("imageUrl"),
  organizerName: text("organizer_name").notNull(),
  organizerEmail: text("organizer_email").notNull(),
  organizerPhone: text("organizer_phone"),
  organizerWebsite: text("organizer_website"), // URL vers le site de l'organisateur pour redirection
  organizerWebhookUrl: text("organizer_webhook_url"), // URL pour envoyer les données des participants
  organizerApiKey: text("organizer_api_key"), // Clé API pour sécuriser les webhooks
  // Billetterie
  ticketsAvailable: integer("tickets_available").default(0),
  ticketsSold: integer("tickets_sold").default(0),
  enableTicketing: text("enable_ticketing").default("false"), // "true" or "false"
  createdAt: text("created_at").notNull(),
});

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  ticketCode: text("ticket_code").notNull().unique(),
  purchaseDate: timestamp("purchase_date").defaultNow(),
  status: text("status").default("valid"), // "valid", "used", "cancelled"
  price: text("price").notNull(),
  buyerName: text("buyer_name").notNull(),
  buyerEmail: text("buyer_email").notNull(),
  qrCodeData: text("qr_code_data"), // Données encodées dans le QR code
  stripePaymentIntentId: text("stripe_payment_intent_id"), // ID du paiement Stripe
  stripeFee: text("stripe_fee"), // Commission Stripe
  platformFee: text("platform_fee"), // Commission plateforme (2-3%)
  organizerAmount: text("organizer_amount"), // Montant pour l'organisateur
  usedAt: timestamp("used_at"), // Date/heure d'utilisation du billet
  validatorId: text("validator_id"), // ID de la personne/système qui a validé le billet
});

// Table pour gérer les paiements aux organisateurs
export const organizerPayouts = pgTable("organizer_payouts", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id).notNull(),
  organizerEmail: text("organizer_email").notNull(),
  totalAmount: text("total_amount").notNull(), // Montant total à verser
  stripeTransferId: text("stripe_transfer_id"), // ID du transfer Stripe
  status: text("status").default("pending"), // "pending", "completed", "failed"
  payoutDate: timestamp("payout_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Table pour gérer les webhooks vers les organisateurs
export const organizerWebhooks = pgTable("organizer_webhooks", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id).notNull(),
  ticketId: integer("ticket_id").references(() => tickets.id).notNull(),
  webhookUrl: text("webhook_url").notNull(),
  payload: text("payload").notNull(), // JSON des données du participant
  status: text("status").default("pending"), // "pending", "sent", "failed"
  attempts: integer("attempts").default(0),
  lastAttempt: timestamp("last_attempt"),
  responseStatus: integer("response_status"), // Code de réponse HTTP
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Posts pour le feed communautaire
export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
  musicUrl: text("music_url"), // Pour partager des tracks
  type: text("type").default("text"), // "text", "image", "video", "music", "event_share"
  eventId: integer("event_id").references(() => events.id), // Si c'est un partage d'événement
  isRepost: text("is_repost").default("false"),
  originalPostId: integer("original_post_id"),
  likesCount: integer("likes_count").default(0),
  repostsCount: integer("reposts_count").default(0),
  commentsCount: integer("comments_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Likes sur les posts
export const postLikes = pgTable("post_likes", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").references(() => posts.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Commentaires sur les posts
export const postComments = pgTable("post_comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").references(() => posts.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Messages privés
export const privateMessages = pgTable("private_messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").references(() => users.id).notNull(),
  receiverId: integer("receiver_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  isRead: integer("is_read").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Table pour le système de follow/unfollow
export const userFollows = pgTable("user_follows", {
  id: serial("id").primaryKey(),
  followerId: integer("follower_id").references(() => users.id).notNull(),
  followingId: integer("following_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Table pour stocker les interactions utilisateur (pour l'algorithme de recommandation)
export const userInteractions = pgTable("user_interactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  postId: integer("post_id").references(() => posts.id).notNull(),
  interactionType: text("interaction_type").notNull(), // "view", "like", "comment", "share", "dwell_time"
  interactionValue: real("interaction_value").default(1.0), // Score d'interaction (temps passé, etc.)
  createdAt: timestamp("created_at").defaultNow(),
});

// Table pour stocker les préférences de contenu déduites
export const userContentPreferences = pgTable("user_content_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  contentType: text("content_type").notNull(), // "music", "event", "text", "image", "video"
  genre: text("genre"), // "techno", "house", "trance", etc.
  tag: text("tag"), // hashtags ou mots-clés préférés
  preferenceScore: real("preference_score").default(1.0),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Table pour les tags/hashtags dans les posts
export const postTags = pgTable("post_tags", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").references(() => posts.id).notNull(),
  tag: text("tag").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Table pour les clés API des organisateurs externes
export const externalApiKeys = pgTable("external_api_keys", {
  id: serial("id").primaryKey(),
  keyId: text("key_id").notNull().unique(), // ID public de la clé
  keySecret: text("key_secret").notNull(), // Secret hash
  organizerName: text("organizer_name").notNull(),
  organizerEmail: text("organizer_email").notNull(),
  organizerWebsite: text("organizer_website"),
  webhookUrl: text("webhook_url"), // URL pour recevoir les notifications
  permissions: text("permissions").array().default([]), // ["events:create", "tickets:generate", etc.]
  isActive: boolean("is_active").default(true),
  rateLimit: integer("rate_limit").default(1000), // Requêtes par heure
  lastUsed: timestamp("last_used"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Table pour les événements créés via API externe
export const externalEvents = pgTable("external_events", {
  id: serial("id").primaryKey(),
  apiKeyId: integer("api_key_id").references(() => externalApiKeys.id).notNull(),
  externalEventId: text("external_event_id").notNull(), // ID de l'événement dans le système externe
  title: text("title").notNull(),
  description: text("description").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  venue: text("venue").notNull(),
  location: text("location").notNull(),
  organizerName: text("organizer_name").notNull(),
  organizerEmail: text("organizer_email").notNull(),
  maxTickets: integer("max_tickets").default(0),
  ticketsSold: integer("tickets_sold").default(0),
  status: text("status").default("active"), // "active", "cancelled", "sold_out"
  createdAt: timestamp("created_at").defaultNow(),
});

// Table pour les billets générés via API externe
export const externalTickets = pgTable("external_tickets", {
  id: serial("id").primaryKey(),
  externalEventId: integer("external_event_id").references(() => externalEvents.id).notNull(),
  externalTicketId: text("external_ticket_id").notNull(), // ID du billet dans le système externe
  qrCode: text("qr_code").notNull().unique(), // Code QR généré par la plateforme
  buyerName: text("buyer_name").notNull(),
  buyerEmail: text("buyer_email").notNull(),
  ticketType: text("ticket_type"), // "regular", "vip", etc.
  price: text("price"),
  status: text("status").default("valid"), // "valid", "used", "cancelled"
  purchaseDate: timestamp("purchase_date").defaultNow(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Table pour l'audit des requêtes API
export const apiAuditLog = pgTable("api_audit_log", {
  id: serial("id").primaryKey(),
  apiKeyId: integer("api_key_id").references(() => externalApiKeys.id),
  endpoint: text("endpoint").notNull(),
  method: text("method").notNull(),
  statusCode: integer("status_code").notNull(),
  responseTime: integer("response_time"), // en millisecondes
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  requestData: text("request_data"), // JSON stringifié
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateUserProfileSchema = createInsertSchema(users).omit({
  id: true,
  username: true,
  password: true,
  createdAt: true,
  updatedAt: true,
}).transform((data) => ({
  ...data,
  email: data.email || "",
  firstName: data.firstName || "",
  lastName: data.lastName || "",
  bio: data.bio || "",
  city: data.city || "",
  country: data.country || "",
  website: data.website || "",
  profileImageUrl: data.profileImageUrl || "",
}));

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  createdAt: true,
  ticketsSold: true,
}).extend({
  time: z.string().min(1, "L'heure de début est obligatoire"),
  endTime: z.string().optional(),
  endDate: z.string().optional(),
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
  purchaseDate: true,
  ticketCode: true,
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
  likesCount: true,
  repostsCount: true,
  commentsCount: true,
});

export const insertPostLikeSchema = createInsertSchema(postLikes).omit({
  id: true,
  createdAt: true,
});

export const insertPostCommentSchema = createInsertSchema(postComments).omit({
  id: true,
  createdAt: true,
});

export const insertOrganizerPayoutSchema = createInsertSchema(organizerPayouts).omit({
  id: true,
  createdAt: true,
  payoutDate: true,
});

export const insertOrganizerWebhookSchema = createInsertSchema(organizerWebhooks).omit({
  id: true,
  createdAt: true,
  lastAttempt: true,
});

export const insertPrivateMessageSchema = createInsertSchema(privateMessages).omit({
  id: true,
  createdAt: true,
});

export const insertUserFollowSchema = createInsertSchema(userFollows).omit({
  id: true,
  createdAt: true,
});

export const insertExternalApiKeySchema = createInsertSchema(externalApiKeys).omit({
  id: true,
  createdAt: true,
  lastUsed: true,
});

export const insertExternalEventSchema = createInsertSchema(externalEvents).omit({
  id: true,
  createdAt: true,
});

export const insertExternalTicketSchema = createInsertSchema(externalTickets).omit({
  id: true,
  createdAt: true,
  usedAt: true,
});

export const insertApiAuditLogSchema = createInsertSchema(apiAuditLog).omit({
  id: true,
  createdAt: true,
});

export const insertUserInteractionSchema = createInsertSchema(userInteractions).omit({
  id: true,
  createdAt: true,
});

export const insertUserContentPreferenceSchema = createInsertSchema(userContentPreferences).omit({
  id: true,
  updatedAt: true,
});

export const insertPostTagSchema = createInsertSchema(postTags).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateUserProfile = z.infer<typeof updateUserProfileSchema>;
export type User = typeof users.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;
export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertPostLike = z.infer<typeof insertPostLikeSchema>;
export type PostLike = typeof postLikes.$inferSelect;
export type InsertPostComment = z.infer<typeof insertPostCommentSchema>;
export type PostComment = typeof postComments.$inferSelect;
export type InsertOrganizerPayout = z.infer<typeof insertOrganizerPayoutSchema>;
export type OrganizerPayout = typeof organizerPayouts.$inferSelect;
export type InsertOrganizerWebhook = z.infer<typeof insertOrganizerWebhookSchema>;
export type OrganizerWebhook = typeof organizerWebhooks.$inferSelect;
export type InsertPrivateMessage = z.infer<typeof insertPrivateMessageSchema>;
export type PrivateMessage = typeof privateMessages.$inferSelect;
export type InsertUserFollow = z.infer<typeof insertUserFollowSchema>;
export type UserFollow = typeof userFollows.$inferSelect;
export type InsertExternalApiKey = z.infer<typeof insertExternalApiKeySchema>;
export type ExternalApiKey = typeof externalApiKeys.$inferSelect;
export type InsertExternalEvent = z.infer<typeof insertExternalEventSchema>;
export type ExternalEvent = typeof externalEvents.$inferSelect;
export type InsertExternalTicket = z.infer<typeof insertExternalTicketSchema>;
export type ExternalTicket = typeof externalTickets.$inferSelect;
export type InsertApiAuditLog = z.infer<typeof insertApiAuditLogSchema>;
export type ApiAuditLog = typeof apiAuditLog.$inferSelect;
