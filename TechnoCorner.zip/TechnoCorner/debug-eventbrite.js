#!/usr/bin/env node

import { eventbriteService } from './server/eventbrite-service.js';
import { storage } from './server/storage.js';

async function debugEventbrite() {
  console.log('🔍 Diagnostic des événements Eventbrite...\n');
  
  try {
    // 1. Vérifier les événements actuels dans la base
    const allEvents = await storage.getAllEvents();
    const eventbriteEvents = allEvents.filter(e => e.organizerEmail === 'eventbrite@technocorner.local');
    
    console.log(`📊 Événements totaux en base: ${allEvents.length}`);
    console.log(`🎪 Événements Eventbrite en base: ${eventbriteEvents.length}`);
    
    if (eventbriteEvents.length > 0) {
      console.log('\n📋 Événements Eventbrite existants:');
      eventbriteEvents.forEach((event, index) => {
        console.log(`  ${index + 1}. ${event.title} (${event.date} ${event.time})`);
      });
    }
    
    // 2. Tester la recherche d'événements via l'API
    console.log('\n🔄 Test de recherche d\'événements...');
    const searchResults = await eventbriteService.searchEvents("electronic music");
    console.log(`🎵 Événements trouvés via API: ${searchResults.length}`);
    
    if (searchResults.length > 0) {
      console.log('\n📋 Événements trouvés:');
      searchResults.forEach((event, index) => {
        console.log(`  ${index + 1}. ${event.name.text}`);
      });
    }
    
    // 3. Forcer une nouvelle synchronisation
    console.log('\n🔄 Lancement d\'une nouvelle synchronisation...');
    const syncResult = await eventbriteService.syncElectronicMusicEvents();
    console.log(`✅ Synchronisation terminée. Événements ajoutés: ${syncResult}`);
    
    // 4. Vérifier les événements après synchronisation
    const updatedEvents = await storage.getAllEvents();
    const updatedEventbriteEvents = updatedEvents.filter(e => e.organizerEmail === 'eventbrite@technocorner.local');
    
    console.log(`\n📊 Événements Eventbrite après sync: ${updatedEventbriteEvents.length}`);
    
  } catch (error) {
    console.error('❌ Erreur lors du diagnostic:', error.message);
    console.error('Stack:', error.stack);
  }
}

debugEventbrite();