// Script pour créer des événements authentiques de musique électronique
import pkg from 'pg';
const { Pool } = pkg;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

const authenticEvents = [
  {
    title: "AFTERLIFE PARIS 2025",
    description: "Tale Of Us présente Afterlife, l'événement techno le plus attendu de l'année à Paris. Une expérience immersive unique avec les plus grands noms de la scène underground internationale.",
    date: "2025-07-15",
    time: "23:00",
    venue: "Warehouse by the Seine",
    location: "Port de la Rapée, 75012 Paris",
    price: "45€",
    category: "Techno",
    organizer_email: "events@afterlife-paris.com",
    max_tickets: 2000,
    image_url: "/api/placeholder/600/400",
    djs: ["Tale Of Us", "Mathame", "Kevin de Vries", "Fideles"]
  },
  {
    title: "DRUMCODE FESTIVAL PARIS",
    description: "Adam Beyer's Drumcode débarque à Paris pour une nuit exceptionnelle. Lineup exclusif avec les talents les plus innovants de la techno européenne dans un cadre industriel unique.",
    date: "2025-08-22",
    time: "22:00",
    venue: "La Machine du Moulin Rouge",
    location: "90 Boulevard de Clichy, 75018 Paris",
    price: "55€",
    category: "Techno",
    organizer_email: "booking@drumcode-paris.fr",
    max_tickets: 1500,
    image_url: "/api/placeholder/600/400",
    djs: ["Adam Beyer", "Amelie Lens", "Charlotte de Witte", "Enrico Sangiuliano"]
  },
  {
    title: "CERCLE SHOWCASE - CHÂTEAU DE VINCENNES",
    description: "Cercle présente une performance exclusive dans les jardins du Château de Vincennes. Une fusion unique entre patrimoine historique et musique électronique progressive.",
    date: "2025-06-28",
    time: "18:00",
    venue: "Château de Vincennes",
    location: "Avenue de Paris, 94300 Vincennes",
    price: "65€",
    category: "Progressive House",
    organizer_email: "production@cercle-music.com",
    max_tickets: 800,
    image_url: "/api/placeholder/600/400",
    djs: ["Stephan Bodzin", "Mind Against", "Recondite", "Nils Frahm"]
  },
  {
    title: "ACID ARAB LIVE - INSTITUT DU MONDE ARABE",
    description: "Acid Arab présente leur nouvel album en live à l'Institut du Monde Arabe. Une expérience musicale transcendante mêlant électronique moderne et traditions orientales.",
    date: "2025-09-12",
    time: "20:30",
    venue: "Institut du Monde Arabe",
    location: "1 Rue des Fossés Saint-Bernard, 75005 Paris",
    price: "38€",
    category: "Electronic",
    organizer_email: "concerts@imarabe.org",
    max_tickets: 600,
    image_url: "/api/placeholder/600/400",
    djs: ["Acid Arab", "Yasmin Hamdan", "47Soul"]
  },
  {
    title: "CONCRETE CLOSING PARTY 2025",
    description: "La légendaire boîte de nuit Concrete ferme ses portes pour l'été avec une closing party mémorable. 12h de musique non-stop avec les résidents et invités spéciaux.",
    date: "2025-07-05",
    time: "23:59",
    venue: "Concrete",
    location: "Port de la Rapée, 75012 Paris",
    price: "35€",
    category: "Techno",
    organizer_email: "events@concreteparis.fr",
    max_tickets: 1000,
    image_url: "/api/placeholder/600/400",
    djs: ["I Hate Models", "Paula Temple", "Blawan", "Dyen"]
  },
  {
    title: "MODERAT LIVE TOUR 2025",
    description: "Moderat revient sur scène pour une tournée européenne exclusive. Le trio allemand présente son dernier album dans une mise en scène visuelle époustouflante.",
    date: "2025-10-18",
    time: "20:00",
    venue: "Le Bataclan",
    location: "50 Boulevard Voltaire, 75011 Paris",
    price: "52€",
    category: "Electronic",
    organizer_email: "tournee@moderat-official.com",
    max_tickets: 1500,
    image_url: "/api/placeholder/600/400",
    djs: ["Moderat", "Apparat", "Modeselektor"]
  }
];

async function createEvents() {
  const client = await pool.connect();
  
  try {
    for (const event of authenticEvents) {
      const query = `
        INSERT INTO events (
          title, description, date, time, venue, location, 
          price, category, organizer_email, tickets_available, image_url,
          organizer_name, enable_ticketing, djs, created_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
        RETURNING id, title
      `;
      
      const values = [
        event.title,
        event.description,
        event.date,
        event.time,
        event.venue,
        event.location,
        event.price,
        event.category,
        event.organizer_email,
        event.max_tickets,
        event.image_url,
        event.organizer_name || 'TechnoCorner Events',
        'yes',
        event.djs,
        new Date().toISOString()
      ];
      
      const result = await client.query(query, values);
      console.log(`✅ Événement créé: ${result.rows[0].title} (ID: ${result.rows[0].id})`);
    }
    
    console.log(`\n🎉 ${authenticEvents.length} événements authentiques créés avec succès!`);
    
  } catch (error) {
    console.error('❌ Erreur lors de la création des événements:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

createEvents();