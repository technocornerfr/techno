/**
 * Script de test pour valider l'envoi automatique de billets par email
 * pour les organisateurs externes via l'API TechnoCorner
 */

const API_BASE = 'http://localhost:5000/api/external';

// Configuration de test
const TEST_CONFIG = {
  // Ces valeurs doivent être remplacées par de vraies clés API générées
  apiKeyId: 'test_key_123',
  apiSecret: 'test_secret_456',
  testEvent: {
    externalEventId: 'festival_techno_2024',
    title: 'Festival Techno Underground 2024',
    date: '2024-12-15',
    time: '20:00',
    venue: 'Warehouse 404',
    location: 'Berlin, Allemagne'
  },
  testTicket: {
    externalTicketId: 'ticket_001',
    buyerName: 'Jean Dupont',
    buyerEmail: 'jean.dupont@test.com',
    ticketType: 'VIP',
    price: '45€'
  }
};

async function makeApiRequest(endpoint, data) {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': TEST_CONFIG.apiKeyId,
      'X-API-Secret': TEST_CONFIG.apiSecret
    },
    body: JSON.stringify(data)
  });

  const result = await response.json();
  
  console.log(`\n=== ${endpoint} ===`);
  console.log('Status:', response.status);
  console.log('Response:', JSON.stringify(result, null, 2));
  
  return { status: response.status, data: result };
}

async function testExternalTicketEmail() {
  console.log('🎫 Test d\'envoi automatique de billets par email pour organisateurs externes');
  console.log('📧 Email de test:', TEST_CONFIG.testTicket.buyerEmail);
  
  try {
    // 1. Créer un événement externe
    console.log('\n📅 Étape 1: Création d\'un événement externe');
    const eventResponse = await makeApiRequest('/events/create', TEST_CONFIG.testEvent);
    
    if (eventResponse.status !== 201) {
      console.error('❌ Échec de création d\'événement:', eventResponse.data);
      return;
    }
    
    // 2. Générer un billet (ceci devrait déclencher l'envoi d'email automatique)
    console.log('\n🎟️ Étape 2: Génération de billet (avec envoi email automatique)');
    const ticketData = {
      ...TEST_CONFIG.testTicket,
      externalEventId: TEST_CONFIG.testEvent.externalEventId
    };
    
    const ticketResponse = await makeApiRequest('/tickets/generate', ticketData);
    
    if (ticketResponse.status === 201) {
      console.log('✅ Billet généré avec succès!');
      console.log('📧 Email automatique envoyé à:', TEST_CONFIG.testTicket.buyerEmail);
      console.log('🔍 QR Code généré pour validation à l\'entrée');
      
      // 3. Tester la validation du QR code
      if (ticketResponse.data.ticket?.qrCode) {
        console.log('\n🎯 Étape 3: Test de validation du QR code');
        const validateResponse = await makeApiRequest('/tickets/validate', {
          qrCode: ticketResponse.data.ticket.qrCode
        });
        
        if (validateResponse.status === 200 && validateResponse.data.valid) {
          console.log('✅ QR code validé avec succès!');
        } else {
          console.log('⚠️ Validation QR code:', validateResponse.data);
        }
      }
    } else {
      console.error('❌ Échec de génération de billet:', ticketResponse.data);
    }
    
  } catch (error) {
    console.error('🚫 Erreur lors du test:', error.message);
    console.log('\n💡 Actions à vérifier:');
    console.log('1. Le serveur TechnoCorner est-il démarré sur le port 5000?');
    console.log('2. Les clés API de test sont-elles configurées?');
    console.log('3. SendGrid est-il configuré avec une clé API valide?');
  }
}

async function testWithRealApiKey() {
  console.log('\n🔑 Pour tester avec de vraies clés API:');
  console.log('1. Générez une clé API via l\'endpoint /api/admin/generate-api-key');
  console.log('2. Remplacez TEST_CONFIG.apiKeyId et TEST_CONFIG.apiSecret');
  console.log('3. Utilisez une vraie adresse email dans TEST_CONFIG.testTicket.buyerEmail');
  console.log('4. Relancez ce script');
}

// Exécution du test
if (typeof window === 'undefined') {
  // Environnement Node.js
  testExternalTicketEmail()
    .then(() => testWithRealApiKey())
    .catch(console.error);
} else {
  // Environnement navigateur
  console.log('Ce script doit être exécuté avec Node.js');
  console.log('Commande: node test-external-ticket-email.js');
}