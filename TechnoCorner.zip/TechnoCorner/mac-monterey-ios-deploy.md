# Fix Xcode - TechnoCorner ne s'affiche pas

## Problème courant : Écran blanc dans Xcode

### Solution 1 : Vérifier la structure des fichiers

**Dans Terminal :**
```bash
cd ~/technocorner

# Vérifier que le fichier index.html existe
ls -la www/
cat www/index.html
```

Si le fichier est vide ou n'existe pas, le recréer :

```bash
cat > www/index.html << 'EOF'
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechnoCorner</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            max-width: 400px;
            text-align: center;
            background: rgba(255,255,255,0.1);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
        }
        h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .subtitle {
            font-size: 1.1em;
            opacity: 0.9;
            margin-bottom: 30px;
            line-height: 1.4;
        }
        .features {
            margin: 30px 0;
        }
        .feature {
            background: rgba(255,255,255,0.1);
            padding: 20px;
            margin: 15px 0;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .feature h3 {
            font-size: 1.2em;
            margin-bottom: 8px;
        }
        .feature p {
            font-size: 0.9em;
            opacity: 0.8;
        }
        .btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 12px 24px;
            border: 2px solid rgba(255,255,255,0.3);
            border-radius: 25px;
            font-size: 1em;
            font-weight: bold;
            margin-top: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }
        .status {
            position: fixed;
            top: 20px;
            left: 20px;
            background: rgba(0,255,0,0.2);
            padding: 10px;
            border-radius: 5px;
            font-size: 0.8em;
        }
    </style>
</head>
<body>
    <div class="status">✓ App chargée</div>
    
    <div class="container">
        <h1>🎧 TechnoCorner</h1>
        <p class="subtitle">Découvrez la scène techno, connectez-vous avec la communauté électronique</p>
        
        <div class="features">
            <div class="feature">
                <h3>🎵 Événements</h3>
                <p>Trouvez les soirées et festivals techno</p>
            </div>
            
            <div class="feature">
                <h3>👥 Communauté</h3>
                <p>Partagez avec d'autres passionnés</p>
            </div>
            
            <div class="feature">
                <h3>🎫 Scanner</h3>
                <p>Validez vos billets facilement</p>
            </div>
        </div>
        
        <button class="btn" onclick="alert('TechnoCorner fonctionne !')">
            🚀 Tester l'App
        </button>
    </div>

    <script>
        console.log('TechnoCorner app loaded successfully');
        document.addEventListener('DOMContentLoaded', function() {
            console.log('DOM ready');
        });
    </script>
</body>
</html>
EOF
```

### Solution 2 : Resynchroniser avec Capacitor

```bash
# Resynchroniser les fichiers
npx cap sync ios

# Si problème, nettoyer et refaire
rm -rf ios
npx cap add ios
npx cap sync ios
```

### Solution 3 : Vérifier dans Xcode

**Dans Xcode :**

1. **Fermer Xcode complètement**
2. **Rouvrir :**
```bash
npx cap open ios
```

3. **Vérifier le schéma :**
   - En haut : Sélectionner **"App"** au lieu de autre chose
   - Destination : **iPhone 15 Pro Simulator**

4. **Clean Build :**
   - **Product → Clean Build Folder**
   - **Product → Build**

### Solution 4 : Tester dans le simulateur

1. **Lancer le simulateur :**
   - **Product → Run** (ou Cmd+R)
   - Attendre le démarrage du simulateur

2. **Si écran blanc :**
   - Dans le simulateur : **Device → Restart**
   - Relancer : **Product → Run**

### Solution 5 : Debug Console

**Dans Xcode :**
1. **View → Debug Area → Show Debug Area**
2. **Onglet Console** en bas
3. Chercher les messages d'erreur

**Messages typiques :**
- `"Could not load index.html"` → Problème de fichier
- `"Connection refused"` → Problème de serveur
- `"White screen"` → Problème CSS/JS

### Solution 6 : Créer une version encore plus simple

Si rien ne fonctionne, créer une version minimale :

```bash
cat > www/index.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechnoCorner</title>
</head>
<body style="background: #667eea; color: white; font-family: Arial; text-align: center; padding: 50px;">
    <h1 style="font-size: 3em; margin-bottom: 20px;">🎧 TechnoCorner</h1>
    <p style="font-size: 1.5em; margin-bottom: 30px;">Application iOS Test</p>
    <div style="background: rgba(255,255,255,0.2); padding: 30px; border-radius: 15px; margin: 20px;">
        <h2>✅ L'app fonctionne !</h2>
        <p>Prête pour l'App Store</p>
    </div>
    <button onclick="alert('TechnoCorner OK!')" style="padding: 15px 30px; font-size: 1.2em; background: white; color: #667eea; border: none; border-radius: 25px; font-weight: bold;">
        Tester
    </button>
</body>
</html>
EOF
```

### Commandes de Debug

```bash
# Vérifier la structure Capacitor
npx cap doctor

# Voir les logs détaillés
npx cap sync ios --verbose

# Nettoyer complètement
rm -rf node_modules ios
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```

### Étapes dans l'ordre si rien ne marche

1. **Fermer Xcode**
2. **Exécuter :**
```bash
cd ~/technocorner
rm -rf ios
npx cap add ios
npx cap sync ios
npx cap open ios
```
3. **Dans Xcode :** Product → Clean Build Folder
4. **Product → Run**
5. **Attendre le simulateur**

Si ces solutions ne fonctionnent pas, le problème peut venir de la version de Xcode ou de la configuration du Mac. Dans ce cas, me dire quelle version de macOS et Xcode vous utilisez.