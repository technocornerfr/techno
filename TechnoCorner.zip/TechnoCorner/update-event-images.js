import pkg from 'pg';
const { Pool } = pkg;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

const eventImages = [
  {
    title: 'AFTERLIFE PARIS 2025',
    image_url: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  },
  {
    title: 'DRUMCODE FESTIVAL PARIS',
    image_url: 'https://images.unsplash.com/photo-1540039155733-5bb30b53aa14?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  },
  {
    title: 'CERCLE SHOWCASE - CHÂTEAU DE VINCENNES',
    image_url: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  },
  {
    title: 'ACID ARAB LIVE - INSTITUT DU MONDE ARABE',
    image_url: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  },
  {
    title: 'CONCRETE CLOSING PARTY 2025',
    image_url: 'https://images.unsplash.com/photo-1571266028243-d220c9f3c46e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  },
  {
    title: 'MODERAT LIVE TOUR 2025',
    image_url: 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  }
];

async function updateImages() {
  const client = await pool.connect();
  
  try {
    for (const event of eventImages) {
      const query = `UPDATE events SET "imageUrl" = $1 WHERE title = $2 RETURNING title`;
      const result = await client.query(query, [event.image_url, event.title]);
      
      if (result.rows.length > 0) {
        console.log(`✅ Image mise à jour pour: ${result.rows[0].title}`);
      }
    }
    
    console.log(`\n🎉 Images mises à jour pour ${eventImages.length} événements!`);
    
  } catch (error) {
    console.error('❌ Erreur lors de la mise à jour des images:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

updateImages();