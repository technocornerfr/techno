# Guide Simple : Publier TechnoCorner sur l'App Store

## Prérequis
- Mac avec Xcode installé
- Apple Developer Account (99$/an)
- Node.js installé

## Étape 1 : Télécharger le projet (2 minutes)

1. **Sur Replit** : Export → Download as ZIP
2. **Sur votre Mac** : Extraire dans `~/technocorner`
3. **Ouvrir Terminal** et aller dans le dossier :
```bash
cd ~/technocorner
```

## Étape 2 : Créer les fichiers de base (5 minutes)

**Créer package.json :**
```bash
cat > package.json << 'EOF'
{
  "name": "technocorner",
  "version": "1.0.0",
  "scripts": {
    "build": "echo 'App built'",
    "start": "echo 'App started'"
  },
  "dependencies": {
    "@capacitor/cli": "latest",
    "@capacitor/core": "latest",
    "@capacitor/ios": "latest"
  }
}
EOF
```

**Installer Capacitor :**
```bash
npm install
```

**Créer le dossier web :**
```bash
mkdir -p www
```

**Créer index.html simple :**
```bash
cat > www/index.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechnoCorner</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            margin: 0;
            padding: 40px 20px;
            min-height: 100vh;
            text-align: center;
        }
        .container { max-width: 600px; margin: 0 auto; }
        h1 { font-size: 3em; margin-bottom: 20px; }
        .subtitle { font-size: 1.2em; opacity: 0.9; margin-bottom: 40px; }
        .feature {
            background: rgba(255,255,255,0.1);
            padding: 30px;
            margin: 20px 0;
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }
        .feature h3 { margin-bottom: 15px; font-size: 1.5em; }
        .btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 15px 30px;
            border: 2px solid rgba(255,255,255,0.3);
            border-radius: 30px;
            font-size: 1em;
            font-weight: bold;
            margin: 20px 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎧 TechnoCorner</h1>
        <p class="subtitle">Découvrez la scène techno, connectez-vous avec la communauté</p>
        
        <div class="feature">
            <h3>🎵 Événements</h3>
            <p>Trouvez les meilleurs événements techno près de chez vous</p>
        </div>
        
        <div class="feature">
            <h3>👥 Communauté</h3>
            <p>Partagez vos moments avec la communauté électronique</p>
        </div>
        
        <div class="feature">
            <h3>🎫 Scanner</h3>
            <p>Scannez et validez vos billets d'événements</p>
        </div>
        
        <button class="btn">🚀 Découvrir TechnoCorner</button>
    </div>
</body>
</html>
EOF
```

## Étape 3 : Configuration Capacitor (3 minutes)

**Initialiser Capacitor :**
```bash
npx cap init TechnoCorner com.technocorner.app --web-dir=www
```

**Ajouter iOS :**
```bash
npx cap add ios
```

**Synchroniser :**
```bash
npx cap sync ios
```

## Étape 4 : Configuration Xcode (10 minutes)

**Ouvrir Xcode :**
```bash
npx cap open ios
```

**Dans Xcode :**

1. **Cliquer sur "App"** (icône bleue en haut à gauche)
2. **Onglet "Signing & Capabilities"**
3. **Team** : Sélectionner votre Apple Developer Account
4. **Bundle Identifier** : Vérifier que c'est `com.technocorner.app`
5. **Display Name** : `TechnoCorner`

**Informations de version :**
- Version : `1.0.0`
- Build : `1`

## Étape 5 : Archive pour App Store (15 minutes)

**Préparer l'archive :**
1. En haut d'Xcode : Sélectionner **"Any iOS Device (arm64)"**
2. Menu **Product → Archive**
3. Attendre 10-15 minutes (compilation)

**Upload vers App Store :**
1. Organizer s'ouvre automatiquement
2. **Distribute App**
3. **App Store Connect**
4. **Upload** (pas Validate)
5. **Next → Upload**
6. Attendre 5-15 minutes

## Étape 6 : App Store Connect (20 minutes)

**Créer l'application :**
1. Aller sur [appstoreconnect.apple.com](https://appstoreconnect.apple.com)
2. **My Apps → + → New App**

**Informations de base :**
- **Platforms** : iOS
- **Name** : TechnoCorner
- **Primary Language** : French
- **Bundle ID** : com.technocorner.app (sélectionner)
- **SKU** : TECHNOCORNER2025

**Métadonnées obligatoires :**

**Nom :** TechnoCorner

**Sous-titre :** Événements Techno & Communauté

**Catégorie :** Music

**Description :**
```
Découvrez la scène techno avec TechnoCorner !

FONCTIONNALITÉS :
• Trouvez les meilleurs événements techno
• Connectez-vous avec la communauté électronique
• Scannez et validez vos billets
• Partagez vos moments et photos

Rejoignez la plus grande communauté techno francophone !
```

**Mots-clés :**
```
techno,événements,musique,électronique,soirée,festival,billets,communauté
```

## Étape 7 : Screenshots (15 minutes)

**Créer le simulateur :**
1. Dans Xcode : **Window → Devices and Simulators**
2. **Simulators → +**
3. **iPhone 15 Pro (iOS 17.x)**

**Lancer l'app :**
1. Sélectionner le simulateur iPhone 15 Pro
2. **Product → Run**
3. L'app s'ouvre dans le simulateur

**Prendre 5 captures :**
1. **Device → Screenshot → Save to Desktop**
2. Prendre plusieurs captures de l'app
3. Uploader dans App Store Connect (section Screenshots)

**Taille requise :** 1290 x 2796 pixels (automatique avec iPhone 15 Pro)

## Étape 8 : Configuration finale (10 minutes)

**Politique de confidentialité :**
Créer une page web simple ou utiliser ce texte :
```
POLITIQUE DE CONFIDENTIALITÉ

TechnoCorner collecte uniquement :
- Nom d'utilisateur et email (inscription)
- Photos partagées (volontaire)

Utilisation : personnalisation et amélioration des services
Contact : privacy@technocorner.app
```

**Prix et disponibilité :**
- **Pricing** : Free
- **Availability** : All countries

**Classification d'âge :**
- **4+** (contenu général)

## Étape 9 : Soumission (5 minutes)

**Sélectionner le build :**
1. **Version 1.0.0 → Build**
2. Sélectionner le build uploadé depuis Xcode
3. Attendre qu'il soit "Ready to Submit"

**Submit for Review :**
1. **Submit for Review**
2. Répondre aux questions :
   - **Contient de la publicité** : Non
   - **Utilise l'IDFA** : Non
3. **Submit**

## Délais et statuts

**Statuts possibles :**
- **Waiting for Review** : 0-48h
- **In Review** : 24-48h  
- **Ready for Sale** : APPROUVÉ !
- **Rejected** : Modifications nécessaires

**Temps total :**
- Configuration : 1h30
- Révision Apple : 24-48h
- Publication : Immédiate

## Résumé des commandes

```bash
# Dans ~/technocorner
npm install
npx cap init TechnoCorner com.technocorner.app --web-dir=www
npx cap add ios
npx cap sync ios
npx cap open ios
```

**Dans Xcode :** Archive → Upload → App Store Connect

**Sur App Store Connect :** Créer app → Métadonnées → Screenshots → Submit

Votre application sera disponible sur l'App Store après approbation d'Apple !