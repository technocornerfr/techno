#!/bin/bash

echo "📱 Configuration locale TechnoCorner"
echo "==================================="

# Créer la structure de base
mkdir -p client/src/pages client/src/components client/src/lib client/src/hooks
mkdir -p server shared public ios

# Package.json principal
cat > package.json << 'EOF'
{
  "name": "technocorner",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "vite build",
    "start": "NODE_ENV=production node dist/index.js"
  },
  "dependencies": {
    "@capacitor/android": "^7.3.0",
    "@capacitor/cli": "^7.3.0",
    "@capacitor/core": "^7.3.0",
    "@capacitor/ios": "^7.3.0",
    "@capacitor/splash-screen": "^7.0.1",
    "@capacitor/status-bar": "^7.0.1",
    "@tanstack/react-query": "^5.0.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "wouter": "^3.0.0",
    "lucide-react": "^0.400.0",
    "vite": "^5.0.0",
    "@vitejs/plugin-react": "^4.0.0",
    "typescript": "^5.0.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0"
  }
}
EOF

# Capacitor config
cat > capacitor.config.ts << 'EOF'
import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.technocorner.app',
  appName: 'TechnoCorner',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#667eea",
      showSpinner: true,
      spinnerColor: "#ffffff"
    },
    StatusBar: {
      style: "dark"
    }
  }
};

export default config;
EOF

# Vite config
cat > vite.config.ts << 'EOF'
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist'
  }
});
EOF

# TypeScript config
cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["client/src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
EOF

# Index.html
cat > client/index.html << 'EOF'
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>TechnoCorner</title>
  <meta name="theme-color" content="#667eea">
  <link rel="manifest" href="/manifest.json">
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/src/main.tsx"></script>
</body>
</html>
EOF

# Main App React
cat > client/src/main.tsx << 'EOF'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
EOF

# App principal
cat > client/src/App.tsx << 'EOF'
import React from 'react';
import { Router, Route, Link } from 'wouter';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Home from './pages/Home';
import Community from './pages/Community';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-indigo-500 to-purple-600">
          <nav className="bg-black/20 backdrop-blur-md p-4">
            <div className="container mx-auto flex justify-between items-center">
              <h1 className="text-2xl font-bold text-white">🎧 TechnoCorner</h1>
              <div className="space-x-4">
                <Link href="/" className="text-white hover:text-purple-200">Accueil</Link>
                <Link href="/community" className="text-white hover:text-purple-200">Communauté</Link>
              </div>
            </div>
          </nav>
          
          <Route path="/" component={Home} />
          <Route path="/community" component={Community} />
        </div>
      </Router>
    </QueryClientProvider>
  );
}

export default App;
EOF

# Page Home
cat > client/src/pages/Home.tsx << 'EOF'
import React from 'react';

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center text-white">
        <h2 className="text-4xl font-bold mb-6">Découvrez la Scène Techno</h2>
        <p className="text-xl mb-8 opacity-90">
          Trouvez les meilleurs événements, connectez-vous avec la communauté
        </p>
        
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
            <h3 className="text-xl font-bold mb-4">🎵 Événements</h3>
            <p>Découvrez les soirées et festivals techno près de chez vous</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
            <h3 className="text-xl font-bold mb-4">👥 Communauté</h3>
            <p>Partagez vos moments et connectez-vous avec d'autres passionnés</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
            <h3 className="text-xl font-bold mb-4">🎫 Scanner</h3>
            <p>Scannez et validez vos billets avec notre système anti-fraude</p>
          </div>
        </div>
      </div>
    </div>
  );
}
EOF

# Page Community
cat > client/src/pages/Community.tsx << 'EOF'
import React from 'react';

export default function Community() {
  const posts = [
    {
      id: 1,
      author: "TechnoFan92",
      content: "Incroyable soirée au Warehouse hier soir ! 🔥",
      likes: 24,
      comments: 8
    },
    {
      id: 2,
      author: "ElectroMix",
      content: "Qui sera au festival Nuit Blanche ce weekend ?",
      likes: 15,
      comments: 12
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <h2 className="text-3xl font-bold text-white mb-8 text-center">Communauté</h2>
        
        <div className="space-y-6">
          {posts.map(post => (
            <div key={post.id} className="bg-white/10 backdrop-blur-md rounded-xl p-6 text-white">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                  {post.author[0]}
                </div>
                <span className="font-bold">{post.author}</span>
              </div>
              
              <p className="mb-4">{post.content}</p>
              
              <div className="flex space-x-4 text-sm opacity-75">
                <span>❤️ {post.likes}</span>
                <span>💬 {post.comments}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
EOF

# CSS minimal
cat > client/src/index.css << 'EOF'
@tailwind base;
@tailwind components;
@tailwind utilities;

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
EOF

# Manifest PWA
cat > public/manifest.json << 'EOF'
{
  "name": "TechnoCorner",
  "short_name": "TechnoCorner",
  "description": "Découvrez la scène techno, connectez-vous avec la communauté",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#667eea",
  "theme_color": "#667eea",
  "icons": [
    {
      "src": "/icon-192.svg",
      "sizes": "192x192",
      "type": "image/svg+xml"
    },
    {
      "src": "/icon-512.svg",
      "sizes": "512x512", 
      "type": "image/svg+xml"
    }
  ]
}
EOF

# Icône SVG simple
cat > public/icon-192.svg << 'EOF'
<svg width="192" height="192" viewBox="0 0 192 192" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="192" height="192" rx="48" fill="#667eea"/>
  <text x="96" y="110" text-anchor="middle" font-size="80" fill="white">🎧</text>
</svg>
EOF

cat > public/icon-512.svg << 'EOF'
<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="512" height="512" rx="128" fill="#667eea"/>
  <text x="256" y="300" text-anchor="middle" font-size="200" fill="white">🎧</text>
</svg>
EOF

echo "✅ Structure de projet créée"
echo ""
echo "🚀 ÉTAPES SUIVANTES :"
echo "1. npm install"
echo "2. npm run build"
echo "3. npx cap add ios"
echo "4. npx cap sync ios"
echo "5. npx cap open ios"
echo ""
echo "📱 Votre projet est prêt pour iOS !"